-- TimescaleDB Recipe Manager Schema

CREATE EXTENSION IF NOT EXISTS timescaledb;

-- ============================================
-- MASTER DATA (Regular Tables)
-- ============================================

CREATE TABLE IF NOT EXISTS products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_code VARCHAR(50) UNIQUE NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS recipes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recipe_code VARCHAR(50) NOT NULL,
    recipe_name VARCHAR(200) NOT NULL,
    product_id UUID REFERENCES products(id),
    version INT DEFAULT 1,
    is_active BOOLEAN DEFAULT true,
    created_by VARCHAR(100),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(recipe_code, version)
);

CREATE TABLE IF NOT EXISTS recipe_parameters (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recipe_id UUID REFERENCES recipes(id) ON DELETE CASCADE,
    param_name VARCHAR(100) NOT NULL,
    param_type VARCHAR(20) CHECK (param_type IN ('INT','REAL','DINT','BOOL','STRING')),
    value_default JSONB,
    value_min NUMERIC,
    value_max NUMERIC,
    plc_tag VARCHAR(200) NOT NULL,
    unit VARCHAR(20),
    sort_order INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS plc_configs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    plc_id VARCHAR(50) UNIQUE NOT NULL,
    host VARCHAR(100) NOT NULL,
    slot INT DEFAULT 0,
    timeout INT DEFAULT 5,
    protocol VARCHAR(20) DEFAULT 'pylogix',
    opcua_endpoint VARCHAR(255),
    description TEXT,
    is_active BOOLEAN DEFAULT true
);

-- ============================================
-- TIME-SERIES (Hypertables)
-- ============================================

CREATE TABLE IF NOT EXISTS plc_tag_values (
    time TIMESTAMPTZ NOT NULL,
    plc_id VARCHAR(50) NOT NULL,
    tag_name VARCHAR(200) NOT NULL,
    tag_value DOUBLE PRECISION,
    tag_quality INT DEFAULT 192,
    recipe_id UUID REFERENCES recipes(id)
);

SELECT create_hypertable('plc_tag_values', 'time', 
    chunk_time_interval => INTERVAL '1 day', 
    if_not_exists => TRUE);

CREATE TABLE IF NOT EXISTS recipe_downloads (
    time TIMESTAMPTZ NOT NULL,
    recipe_id UUID NOT NULL,
    plc_id VARCHAR(50) NOT NULL,
    downloaded_by VARCHAR(100),
    status VARCHAR(20),
    error_message TEXT,
    duration_ms INT,
    plc_ack BOOLEAN DEFAULT false
);

SELECT create_hypertable('recipe_downloads', 'time',
    chunk_time_interval => INTERVAL '7 days',
    if_not_exists => TRUE);

CREATE TABLE IF NOT EXISTS process_events (
    time TIMESTAMPTZ NOT NULL,
    event_type VARCHAR(50),
    plc_id VARCHAR(50),
    recipe_id UUID,
    severity INT CHECK (severity BETWEEN 1 AND 4),
    message TEXT,
    ack_by VARCHAR(100),
    ack_time TIMESTAMPTZ
);

SELECT create_hypertable('process_events', 'time',
    chunk_time_interval => INTERVAL '1 day',
    if_not_exists => TRUE);

-- ============================================
-- CONTINUOUS AGGREGATES
-- ============================================

CREATE MATERIALIZED VIEW IF NOT EXISTS plc_hourly_summary
WITH (timescaledb.continuous) AS
SELECT
    time_bucket('1 hour', time) AS bucket,
    plc_id,
    tag_name,
    AVG(tag_value) AS avg_value,
    MIN(tag_value) AS min_value,
    MAX(tag_value) AS max_value,
    COUNT(*) AS sample_count
FROM plc_tag_values
GROUP BY bucket, plc_id, tag_name
WITH NO DATA;

SELECT add_continuous_aggregate_policy('plc_hourly_summary',
    start_offset => INTERVAL '1 month',
    end_offset => INTERVAL '1 hour',
    schedule_interval => INTERVAL '1 hour',
    if_not_exists => TRUE);

CREATE MATERIALIZED VIEW IF NOT EXISTS plc_daily_summary
WITH (timescaledb.continuous) AS
SELECT
    time_bucket('1 day', time) AS bucket,
    plc_id,
    tag_name,
    AVG(tag_value) AS avg_value,
    MIN(tag_value) AS min_value,
    MAX(tag_value) AS max_value,
    COUNT(*) AS sample_count
FROM plc_tag_values
GROUP BY bucket, plc_id, tag_name
WITH NO DATA;

SELECT add_continuous_aggregate_policy('plc_daily_summary',
    start_offset => INTERVAL '6 months',
    end_offset => INTERVAL '1 day',
    schedule_interval => INTERVAL '1 day',
    if_not_exists => TRUE);

-- ============================================
-- COMPRESSION & RETENTION
-- ============================================

ALTER TABLE plc_tag_values SET (
    timescaledb.compress,
    timescaledb.compress_segmentby = 'plc_id, tag_name'
);

SELECT add_compression_policy('plc_tag_values', INTERVAL '7 days', if_not_exists => TRUE);
SELECT add_retention_policy('plc_tag_values', INTERVAL '2 years', if_not_exists => TRUE);

SELECT add_retention_policy('recipe_downloads', INTERVAL '5 years', if_not_exists => TRUE);
SELECT add_retention_policy('process_events', INTERVAL '5 years', if_not_exists => TRUE);

-- ============================================
-- INDEXES
-- ============================================

CREATE INDEX IF NOT EXISTS idx_tag_values_recipe ON plc_tag_values (recipe_id, time DESC) 
    WHERE recipe_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_tag_values_tag ON plc_tag_values (plc_id, tag_name, time DESC);

CREATE INDEX IF NOT EXISTS idx_downloads_recipe ON recipe_downloads (recipe_id, time DESC);
CREATE INDEX IF NOT EXISTS idx_downloads_plc ON recipe_downloads (plc_id, time DESC);

CREATE INDEX IF NOT EXISTS idx_events_ack ON process_events (ack_by, time DESC) 
    WHERE ack_by IS NULL;


-- ============================================
-- PRODUCTION ORDERS
-- ============================================

CREATE TABLE IF NOT EXISTS production_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    po_number VARCHAR(50) UNIQUE NOT NULL,
    recipe_id UUID NOT NULL REFERENCES recipes(id),
    plc_id VARCHAR(50) NOT NULL,
    quantity INT DEFAULT 1,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'running', 'completed', 'cancelled')),
    operator VARCHAR(100),
    notes TEXT,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_orders_status ON production_orders (status);
CREATE INDEX IF NOT EXISTS idx_orders_po ON production_orders (po_number);
CREATE INDEX IF NOT EXISTS idx_orders_recipe ON production_orders (recipe_id);

-- Order execution log (time-series)
CREATE TABLE IF NOT EXISTS order_executions (
    time TIMESTAMPTZ NOT NULL,
    order_id UUID NOT NULL,
    po_number VARCHAR(50) NOT NULL,
    recipe_id UUID NOT NULL,
    plc_id VARCHAR(50) NOT NULL,
    event_type VARCHAR(50), -- started, downloaded, completed, failed
    tag_name VARCHAR(200),
    tag_value DOUBLE PRECISION,
    message TEXT
);

SELECT create_hypertable('order_executions', 'time',
    chunk_time_interval => INTERVAL '7 days',
    if_not_exists => TRUE);

CREATE INDEX IF NOT EXISTS idx_exec_order ON order_executions (order_id, time DESC);
CREATE INDEX IF NOT EXISTS idx_exec_po ON order_executions (po_number, time DESC);


-- ============================================
-- SAMPLE DATA
-- ============================================

INSERT INTO products (product_code, product_name) VALUES 
    ('PROD-001', 'Premium Bread'),
    ('PROD-002', 'Whole Wheat Loaf')
ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'RCP-001', 'Standard White Bread', id, 1, true, 'admin'
FROM products WHERE product_code = 'PROD-001'
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Mixing_Speed', 'REAL', '120.5', 50, 200, 'Recipe.MixSpeed', 'RPM', 1
FROM recipes r WHERE r.recipe_code = 'RCP-001'
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Baking_Temp', 'REAL', '180.0', 150, 250, 'Recipe.BakeTemp', 'C', 2
FROM recipes r WHERE r.recipe_code = 'RCP-001'
ON CONFLICT DO NOTHING;
