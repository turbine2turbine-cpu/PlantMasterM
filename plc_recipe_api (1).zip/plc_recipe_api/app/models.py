"""Pydantic models for request/response validation."""
from pydantic import BaseModel, Field, field_validator
from typing import List, Optional, Dict, Any, Union
from datetime import datetime
from enum import Enum


class ParamType(str, Enum):
    INT = "INT"
    REAL = "REAL"
    DINT = "DINT"
    BOOL = "BOOL"
    STRING = "STRING"


class RecipeParameter(BaseModel):
    id: Optional[str] = None
    param_name: str = Field(..., min_length=1, max_length=100)
    param_type: ParamType
    value_default: Union[int, float, bool, str, None] = None
    value_min: Optional[float] = None
    value_max: Optional[float] = None
    plc_tag: str = Field(..., min_length=1, max_length=200)
    unit: Optional[str] = None
    sort_order: int = 0


class RecipeCreate(BaseModel):
    recipe_code: str = Field(..., min_length=1, max_length=50)
    recipe_name: str = Field(..., min_length=1, max_length=200)
    product_id: Optional[str] = None
    parameters: List[RecipeParameter] = Field(default_factory=list)
    created_by: Optional[str] = "system"


class RecipeResponse(BaseModel):
    id: str
    recipe_code: str
    recipe_name: str
    product_id: Optional[str]
    version: int
    is_active: bool
    created_by: Optional[str]
    created_at: datetime
    updated_at: datetime
    parameters: List[RecipeParameter] = []


class RecipeUpdate(BaseModel):
    recipe_name: Optional[str] = None
    parameters: Optional[List[RecipeParameter]] = None
    is_active: Optional[bool] = None


class PlcConfig(BaseModel):
    plc_id: str = Field(..., description="Unique PLC identifier (e.g., LINE_A_PLC)")
    host: str
    slot: int = 0
    timeout: int = 5
    description: Optional[str] = None
    is_active: bool = True


class DownloadRequest(BaseModel):
    recipe_id: str
    plc_id: str
    validate: bool = True
    backup_current: bool = True
    user: str = "system"


class DownloadResponse(BaseModel):
    transaction_id: str
    recipe_id: str
    plc_id: str
    status: str  # PENDING, SUCCESS, FAILED
    message: str
    duration_ms: Optional[int] = None
    details: Optional[Dict[str, Any]] = None


class TagValue(BaseModel):
    time: datetime
    plc_id: str
    tag_name: str
    tag_value: Optional[float] = None
    tag_quality: int = 192
    recipe_id: Optional[str] = None


class TagReadRequest(BaseModel):
    plc_id: str
    tag_names: List[str]


class TagWriteRequest(BaseModel):
    plc_id: str
    tags: Dict[str, Union[int, float, bool, str]]  # {tag_name: value}


class TagWriteResponse(BaseModel):
    plc_id: str
    success: Dict[str, Any]
    failed: Dict[str, str]


class EventCreate(BaseModel):
    event_type: str
    plc_id: Optional[str] = None
    recipe_id: Optional[str] = None
    severity: int = Field(default=1, ge=1, le=4)  # 1=Info, 2=Warning, 3=Alarm, 4=Critical
    message: str


class EventAcknowledge(BaseModel):
    event_ids: List[int]
    ack_by: str


class MonitoringQuery(BaseModel):
    plc_id: str
    tag_name: Optional[str] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    bucket: str = "1 minute"  # Time bucket for aggregation


class PlcStatus(BaseModel):
    plc_id: str
    is_online: bool
    last_seen: Optional[datetime]
    active_recipe_id: Optional[str]
    active_recipe_code: Optional[str]
    tag_count: int
    alarm_count: int


# ─── Production Order Models ───

class OrderStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class ProductionOrderCreate(BaseModel):
    po_number: str = Field(..., min_length=1, max_length=50)
    recipe_id: str
    plc_id: str
    quantity: int = Field(default=1, ge=1)
    operator: Optional[str] = "system"
    notes: Optional[str] = None


class ProductionOrderUpdate(BaseModel):
    status: Optional[OrderStatus] = None
    quantity: Optional[int] = Field(default=None, ge=1)
    notes: Optional[str] = None
    operator: Optional[str] = None


class ProductionOrderResponse(BaseModel):
    id: str
    po_number: str
    recipe_id: str
    plc_id: str
    quantity: int
    status: str
    operator: Optional[str]
    notes: Optional[str]
    started_at: Optional[str]
    completed_at: Optional[str]
    created_at: str
    updated_at: str
    recipe_name: Optional[str] = None
    recipe_code: Optional[str] = None


class OrderDownloadRequest(BaseModel):
    order_id: str
    plc_id: str
    validate: bool = True
    backup_current: bool = True
    user: str = "system"


class OrderExecutionLog(BaseModel):
    time: str
    order_id: str
    po_number: str
    event_type: str
    tag_name: Optional[str]
    tag_value: Optional[float]
    message: Optional[str]
