"""TimescaleDB async connection pool and helpers."""
import asyncpg
import json
from datetime import datetime, timezone
from typing import List, Optional, Any, Dict
from contextlib import asynccontextmanager

from app.core.config import settings


class DatabaseManager:
    """Manages asyncpg connection pool for TimescaleDB."""

    def __init__(self):
        self.pool: Optional[asyncpg.Pool] = None

    async def connect(self):
        """Initialize connection pool."""
        self.pool = await asyncpg.create_pool(
            dsn=settings.DATABASE_URL,
            min_size=settings.DB_POOL_MIN_SIZE,
            max_size=settings.DB_POOL_MAX_SIZE,
            command_timeout=settings.DB_COMMAND_TIMEOUT,
            init=self._init_connection
        )

    @staticmethod
    async def _init_connection(conn):
        """Set up connection with JSON encoder/decoder."""
        await conn.set_type_codec(
            'json',
            encoder=json.dumps,
            decoder=json.loads,
            schema='pg_catalog'
        )
        await conn.set_type_codec(
            'jsonb',
            encoder=json.dumps,
            decoder=json.loads,
            schema='pg_catalog'
        )

    async def disconnect(self):
        """Close connection pool."""
        if self.pool:
            await self.pool.close()

    @asynccontextmanager
    async def acquire(self):
        """Acquire connection from pool."""
        async with self.pool.acquire() as conn:
            yield conn

    @asynccontextmanager
    async def transaction(self):
        """Start database transaction."""
        async with self.pool.acquire() as conn:
            async with conn.transaction():
                yield conn


# Global instance
db = DatabaseManager()


# ─── Recipe CRUD Helpers ───

async def get_recipe_by_id(recipe_id: str) -> Optional[Dict[str, Any]]:
    """Get recipe with all parameters by ID."""
    async with db.acquire() as conn:
        recipe = await conn.fetchrow(
            """
            SELECT id, recipe_code, recipe_name, product_id, version, 
                   is_active, created_by, created_at, updated_at
            FROM recipes WHERE id = $1
            """,
            recipe_id
        )
        if not recipe:
            return None

        params = await conn.fetch(
            """
            SELECT id, param_name, param_type, value_default, 
                   value_min, value_max, plc_tag, unit, sort_order
            FROM recipe_parameters WHERE recipe_id = $1
            ORDER BY sort_order, param_name
            """,
            recipe_id
        )

        result = dict(recipe)
        result["parameters"] = [dict(p) for p in params]
        return result


async def get_recipe_by_code(recipe_code: str) -> Optional[Dict[str, Any]]:
    """Get active recipe by code."""
    async with db.acquire() as conn:
        recipe = await conn.fetchrow(
            """
            SELECT id, recipe_code, recipe_name, product_id, version, 
                   is_active, created_by, created_at, updated_at
            FROM recipes 
            WHERE recipe_code = $1 AND is_active = true
            ORDER BY version DESC
            LIMIT 1
            """,
            recipe_code
        )
        if not recipe:
            return None

        params = await conn.fetch(
            """
            SELECT id, param_name, param_type, value_default, 
                   value_min, value_max, plc_tag, unit, sort_order
            FROM recipe_parameters WHERE recipe_id = $1
            ORDER BY sort_order, param_name
            """,
            recipe["id"]
        )

        result = dict(recipe)
        result["parameters"] = [dict(p) for p in params]
        return result


async def list_recipes(product_id: Optional[str] = None, active_only: bool = True) -> List[Dict[str, Any]]:
    """List recipes with optional filtering."""
    async with db.acquire() as conn:
        query = """
            SELECT r.id, r.recipe_code, r.recipe_name, r.product_id, 
                   r.version, r.is_active, r.created_by, r.created_at,
                   p.product_name
            FROM recipes r
            LEFT JOIN products p ON r.product_id = p.id
            WHERE 1=1
        """
        params = []

        if product_id:
            params.append(product_id)
            query += f" AND r.product_id = ${len(params)}"

        if active_only:
            query += " AND r.is_active = true"

        query += " ORDER BY r.recipe_code, r.version DESC"

        rows = await conn.fetch(query, *params)
        return [dict(r) for r in rows]


async def create_recipe_version(recipe_id: str, user: str) -> str:
    """Create new version of existing recipe."""
    async with db.transaction() as conn:
        # Get current recipe
        old = await conn.fetchrow(
            "SELECT * FROM recipes WHERE id = $1", recipe_id
        )
        if not old:
            raise ValueError("Recipe not found")

        # Create new version
        new_id = await conn.fetchval(
            """
            INSERT INTO recipes (recipe_code, recipe_name, product_id, version, 
                                is_active, created_by)
            VALUES ($1, $2, $3, $4, true, $5)
            RETURNING id
            """,
            old["recipe_code"],
            old["recipe_name"],
            old["product_id"],
            old["version"] + 1,
            user
        )

        # Copy parameters
        await conn.execute(
            """
            INSERT INTO recipe_parameters 
                (recipe_id, param_name, param_type, value_default, 
                 value_min, value_max, plc_tag, unit, sort_order)
            SELECT $1, param_name, param_type, value_default,
                   value_min, value_max, plc_tag, unit, sort_order
            FROM recipe_parameters WHERE recipe_id = $2
            """,
            new_id, recipe_id
        )

        # Deactivate old version
        await conn.execute(
            "UPDATE recipes SET is_active = false WHERE id = $1",
            recipe_id
        )

        return new_id


# ─── Time-series Write Helpers ───

async def insert_tag_values_batch(values: List[Dict[str, Any]]):
    """Batch insert PLC tag values into hypertable."""
    if not values:
        return

    async with db.acquire() as conn:
        # Use copy_records_to_table for high-performance bulk insert
        records = [
            (
                v.get("time", datetime.now(timezone.utc)),
                v["plc_id"],
                v["tag_name"],
                v.get("tag_value"),
                v.get("tag_quality", 192),
                v.get("recipe_id")
            )
            for v in values
        ]

        await conn.copy_records_to_table(
            'plc_tag_values',
            records=records,
            columns=['time', 'plc_id', 'tag_name', 'tag_value', 'tag_quality', 'recipe_id']
        )


async def log_recipe_download(
    recipe_id: str,
    plc_id: str,
    downloaded_by: str,
    status: str,
    error_message: Optional[str] = None,
    duration_ms: Optional[int] = None,
    plc_ack: bool = False
):
    """Log recipe download attempt to hypertable."""
    async with db.acquire() as conn:
        await conn.execute(
            """
            INSERT INTO recipe_downloads 
                (time, recipe_id, plc_id, downloaded_by, status, 
                 error_message, duration_ms, plc_ack)
            VALUES (NOW(), $1, $2, $3, $4, $5, $6, $7)
            """,
            recipe_id, plc_id, downloaded_by, status, 
            error_message, duration_ms, plc_ack
        )


async def log_process_event(
    event_type: str,
    plc_id: Optional[str],
    recipe_id: Optional[str],
    severity: int,
    message: str,
    ack_by: Optional[str] = None
):
    """Log process event to hypertable."""
    async with db.acquire() as conn:
        await conn.execute(
            """
            INSERT INTO process_events 
                (time, event_type, plc_id, recipe_id, severity, message, ack_by)
            VALUES (NOW(), $1, $2, $3, $4, $5, $6)
            """,
            event_type, plc_id, recipe_id, severity, message, ack_by
        )


# ─── Time-series Read Helpers (using Continuous Aggregates) ───

async def get_tag_history(
    plc_id: str,
    tag_name: str,
    start_time: datetime,
    end_time: datetime,
    bucket_interval: str = '1 minute'
) -> List[Dict[str, Any]]:
    """Get aggregated tag history using time_bucket."""
    async with db.acquire() as conn:
        rows = await conn.fetch(
            f"""
            SELECT 
                time_bucket($1, time) AS bucket,
                AVG(tag_value) AS avg_value,
                MIN(tag_value) AS min_value,
                MAX(tag_value) AS max_value,
                COUNT(*) AS sample_count
            FROM plc_tag_values
            WHERE plc_id = $2 
              AND tag_name = $3
              AND time >= $4 
              AND time < $5
            GROUP BY bucket
            ORDER BY bucket
            """,
            bucket_interval, plc_id, tag_name, start_time, end_time
        )
        return [dict(r) for r in rows]


async def get_current_tag_values(plc_id: str) -> List[Dict[str, Any]]:
    """Get latest value for each tag using DISTINCT ON + LATERAL."""
    async with db.acquire() as conn:
        rows = await conn.fetch(
            """
            SELECT DISTINCT ON (tag_name) 
                tag_name, tag_value, time, tag_quality
            FROM plc_tag_values
            WHERE plc_id = $1
            ORDER BY tag_name, time DESC
            """,
            plc_id
        )
        return [dict(r) for r in rows]


async def get_download_history(
    recipe_id: Optional[str] = None,
    plc_id: Optional[str] = None,
    hours: int = 24
) -> List[Dict[str, Any]]:
    """Get recipe download history."""
    async with db.acquire() as conn:
        query = """
            SELECT time, recipe_id, plc_id, downloaded_by, status,
                   error_message, duration_ms, plc_ack
            FROM recipe_downloads
            WHERE time > NOW() - INTERVAL '%s hours'
        """ % hours

        params = []
        if recipe_id:
            params.append(recipe_id)
            query += f" AND recipe_id = ${len(params)}"
        if plc_id:
            params.append(plc_id)
            query += f" AND plc_id = ${len(params)}"

        query += " ORDER BY time DESC LIMIT 1000"

        rows = await conn.fetch(query, *params)
        return [dict(r) for r in rows]




# ─── Production Order Helpers ───

async def create_production_order(data: dict) -> str:
    """Create new production order."""
    async with db.transaction() as conn:
        order_id = await conn.fetchval(
            """
            INSERT INTO production_orders (po_number, recipe_id, plc_id, quantity, operator, notes)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING id
            """,
            data["po_number"], data["recipe_id"], data["plc_id"],
            data.get("quantity", 1), data.get("operator", "system"), data.get("notes")
        )
        return order_id


async def get_order_by_id(order_id: str) -> Optional[Dict[str, Any]]:
    """Get order with recipe info."""
    async with db.acquire() as conn:
        row = await conn.fetchrow(
            """
            SELECT o.*, r.recipe_name, r.recipe_code
            FROM production_orders o
            LEFT JOIN recipes r ON o.recipe_id = r.id
            WHERE o.id = $1
            """,
            order_id
        )
        return dict(row) if row else None


async def get_order_by_po(po_number: str) -> Optional[Dict[str, Any]]:
    """Get order by PO number."""
    async with db.acquire() as conn:
        row = await conn.fetchrow(
            """
            SELECT o.*, r.recipe_name, r.recipe_code
            FROM production_orders o
            LEFT JOIN recipes r ON o.recipe_id = r.id
            WHERE o.po_number = $1
            ORDER BY o.created_at DESC
            LIMIT 1
            """,
            po_number
        )
        return dict(row) if row else None


async def list_orders(status: Optional[str] = None, plc_id: Optional[str] = None) -> List[Dict[str, Any]]:
    """List orders with filtering."""
    async with db.acquire() as conn:
        query = """
            SELECT o.*, r.recipe_name, r.recipe_code
            FROM production_orders o
            LEFT JOIN recipes r ON o.recipe_id = r.id
            WHERE 1=1
        """
        params = []
        if status:
            params.append(status)
            query += f" AND o.status = ${len(params)}"
        if plc_id:
            params.append(plc_id)
            query += f" AND o.plc_id = ${len(params)}"
        query += " ORDER BY o.created_at DESC"
        rows = await conn.fetch(query, *params)
        return [dict(r) for r in rows]


async def update_order_status(order_id: str, status: str) -> bool:
    """Update order status."""
    async with db.acquire() as conn:
        result = await conn.execute(
            """
            UPDATE production_orders
            SET status = $1, updated_at = NOW(),
                started_at = CASE WHEN $1 = 'running' AND started_at IS NULL THEN NOW() ELSE started_at END,
                completed_at = CASE WHEN $1 = 'completed' THEN NOW() ELSE completed_at END
            WHERE id = $2
            """,
            status, order_id
        )
        return result == "UPDATE 1"


async def log_order_execution(
    order_id: str,
    po_number: str,
    recipe_id: str,
    plc_id: str,
    event_type: str,
    tag_name: Optional[str] = None,
    tag_value: Optional[float] = None,
    message: Optional[str] = None
):
    """Log order execution event to hypertable."""
    async with db.acquire() as conn:
        await conn.execute(
            """
            INSERT INTO order_executions
                (time, order_id, po_number, recipe_id, plc_id, event_type, tag_name, tag_value, message)
            VALUES (NOW(), $1, $2, $3, $4, $5, $6, $7, $8)
            """,
            order_id, po_number, recipe_id, plc_id, event_type, tag_name, tag_value, message
        )


async def get_unacknowledged_alarms(plc_id: Optional[str] = None) -> List[Dict[str, Any]]:
    """Get unacknowledged alarms using skip scan optimization."""
    async with db.acquire() as conn:
        query = """
            SELECT time, event_type, plc_id, recipe_id, severity, message
            FROM process_events
            WHERE ack_by IS NULL 
              AND severity >= 3
              AND time > NOW() - INTERVAL '7 days'
        """
        params = []
        if plc_id:
            params.append(plc_id)
            query += f" AND plc_id = ${len(params)}"

        query += " ORDER BY time DESC"

        rows = await conn.fetch(query, *params)
        return [dict(r) for r in rows]
