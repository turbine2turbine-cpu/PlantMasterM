"""Rockwell PLC client using PyLogix (EtherNet/IP CIP)."""
import logging
import asyncio
from typing import List, Dict, Any, Optional, Union
from dataclasses import dataclass
from pylogix import PLC as PylogixPLC
from pylogix.eip import Response

from app.core.config import settings

logger = logging.getLogger(__name__)


@dataclass
class PlcTagResult:
    tag_name: str
    value: Any
    status: str  # 'Success', 'Error'
    error: Optional[str] = None


class PyLogixClient:
    """Thread-safe wrapper for PyLogix PLC communication.

    PyLogix is synchronous, so we run it in asyncio thread pool.
    """

    def __init__(self, host: str, slot: int = 0, timeout: int = 5):
        self.host = host
        self.slot = slot
        self.timeout = timeout
        self._plc: Optional[PylogixPLC] = None
        self._connected = False

    def connect(self) -> bool:
        """Connect to PLC."""
        try:
            self._plc = PylogixPLC()
            self._plc.IPAddress = self.host
            self._plc.ProcessorSlot = self.slot
            self._plc.Timeout = self.timeout * 1000  # ms
            self._connected = True
            logger.info(f"Connected to PLC at {self.host}:{self.slot}")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to PLC {self.host}: {e}")
            self._connected = False
            return False

    def disconnect(self):
        """Disconnect from PLC."""
        if self._plc:
            try:
                self._plc.Close()
            except Exception as e:
                logger.warning(f"Error disconnecting PLC: {e}")
            finally:
                self._connected = False
                self._plc = None

    def is_connected(self) -> bool:
        """Check connection status by reading a dummy tag or checking socket."""
        if not self._plc or not self._connected:
            return False
        try:
            # Try to read Program:MainProgram.Recipe.RecipeID or any known tag
            # If you have a heartbeat tag, use that instead
            return True
        except:
            return False

    def read_tag(self, tag_name: str) -> PlcTagResult:
        """Read single tag from PLC."""
        if not self._plc:
            return PlcTagResult(tag_name, None, "Error", "Not connected")

        try:
            response: Response = self._plc.Read(tag_name)
            if response.Status == "Success":
                return PlcTagResult(tag_name, response.Value, "Success")
            else:
                return PlcTagResult(tag_name, None, "Error", response.Status)
        except Exception as e:
            logger.error(f"Error reading tag {tag_name}: {e}")
            return PlcTagResult(tag_name, None, "Error", str(e))

    def read_tags(self, tag_names: List[str]) -> List[PlcTagResult]:
        """Read multiple tags efficiently."""
        if not self._plc:
            return [PlcTagResult(t, None, "Error", "Not connected") for t in tag_names]

        try:
            responses = self._plc.Read(tag_names)
            results = []
            for resp in responses:
                if resp.Status == "Success":
                    results.append(PlcTagResult(resp.TagName, resp.Value, "Success"))
                else:
                    results.append(PlcTagResult(resp.TagName, None, "Error", resp.Status))
            return results
        except Exception as e:
            logger.error(f"Error reading tags {tag_names}: {e}")
            return [PlcTagResult(t, None, "Error", str(e)) for t in tag_names]

    def write_tag(self, tag_name: str, value: Union[int, float, bool, str]) -> PlcTagResult:
        """Write single tag to PLC."""
        if not self._plc:
            return PlcTagResult(tag_name, None, "Error", "Not connected")

        try:
            response = self._plc.Write(tag_name, value)
            if response.Status == "Success":
                return PlcTagResult(tag_name, value, "Success")
            else:
                return PlcTagResult(tag_name, None, "Error", response.Status)
        except Exception as e:
            logger.error(f"Error writing tag {tag_name}: {e}")
            return PlcTagResult(tag_name, None, "Error", str(e))

    def write_tags(self, tags: Dict[str, Union[int, float, bool, str]]) -> List[PlcTagResult]:
        """Write multiple tags. PyLogix doesn't support true multi-write,
        so we write sequentially with error handling."""
        results = []
        for tag_name, value in tags.items():
            result = self.write_tag(tag_name, value)
            results.append(result)
            if result.status != "Success":
                logger.warning(f"Failed to write {tag_name}: {result.error}")
        return results

    def get_plc_info(self) -> Dict[str, Any]:
        """Get PLC information."""
        if not self._plc:
            return {"error": "Not connected"}
        try:
            props = self._plc.GetDeviceProperties()
            if props.Value:
                p = props.Value[0]
                return {
                    "product_name": p.ProductName,
                    "product_code": p.ProductCode,
                    "revision": f"{p.Revision.Major}.{p.Revision.Minor}",
                    "serial_number": p.SerialNumber,
                    "vendor": p.Vendor,
                    "status": "connected"
                }
            return {"status": "connected", "info": "No properties available"}
        except Exception as e:
            return {"error": str(e)}


class AsyncPyLogixClient:
    """Async wrapper that runs PyLogix in thread pool."""

    def __init__(self, host: str, slot: int = 0, timeout: int = 5):
        self._client = PyLogixClient(host, slot, timeout)
        self._lock = asyncio.Lock()

    async def connect(self) -> bool:
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._client.connect)

    async def disconnect(self):
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self._client.disconnect)

    async def read_tag(self, tag_name: str) -> PlcTagResult:
        async with self._lock:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, self._client.read_tag, tag_name)

    async def read_tags(self, tag_names: List[str]) -> List[PlcTagResult]:
        async with self._lock:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, self._client.read_tags, tag_names)

    async def write_tag(self, tag_name: str, value: Any) -> PlcTagResult:
        async with self._lock:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, self._client.write_tag, tag_name, value)

    async def write_tags(self, tags: Dict[str, Any]) -> List[PlcTagResult]:
        async with self._lock:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, self._client.write_tags, tags)

    async def get_plc_info(self) -> Dict[str, Any]:
        async with self._lock:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, self._client.get_plc_info)


# ─── PLC Client Registry ───

_plc_clients: Dict[str, AsyncPyLogixClient] = {}


def get_plc_client(plc_id: str, host: str, slot: int = 0, timeout: int = 5) -> AsyncPyLogixClient:
    """Get or create PLC client."""
    if plc_id not in _plc_clients:
        _plc_clients[plc_id] = AsyncPyLogixClient(host, slot, timeout)
    return _plc_clients[plc_id]


async def disconnect_all_plcs():
    """Disconnect all PLC clients."""
    for plc_id, client in _plc_clients.items():
        try:
            await client.disconnect()
            logger.info(f"Disconnected PLC {plc_id}")
        except Exception as e:
            logger.error(f"Error disconnecting PLC {plc_id}: {e}")
    _plc_clients.clear()
