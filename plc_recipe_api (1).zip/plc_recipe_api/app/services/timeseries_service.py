"""Time-series data service - PLC tag buffering and batch writes."""
import logging
import asyncio
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
from collections import defaultdict

from app.core.config import settings
from app.core.database import insert_tag_values_batch, get_tag_history, get_current_tag_values
from app.clients.plc_client import get_plc_client

logger = logging.getLogger(__name__)


class TagBuffer:
    """In-memory buffer for PLC tag values before batch insert to TimescaleDB."""

    def __init__(self):
        self._buffer: List[Dict[str, Any]] = []
        self._lock = asyncio.Lock()
        self._last_flush = datetime.now(timezone.utc)

    async def add(self, values: List[Dict[str, Any]]):
        """Add values to buffer."""
        async with self._lock:
            self._buffer.extend(values)

    async def flush(self) -> int:
        """Flush buffer to database. Returns count written."""
        async with self._lock:
            if not self._buffer:
                return 0

            batch = self._buffer[:settings.TAG_BATCH_INSERT_SIZE]
            self._buffer = self._buffer[settings.TAG_BATCH_INSERT_SIZE:]

            try:
                await insert_tag_values_batch(batch)
                self._last_flush = datetime.now(timezone.utc)
                return len(batch)
            except Exception as e:
                logger.error(f"Failed to flush tag buffer: {e}")
                # Put back to buffer for retry
                self._buffer = batch + self._buffer
                return 0

    async def should_flush(self) -> bool:
        """Check if buffer should be flushed."""
        async with self._lock:
            if len(self._buffer) >= settings.TAG_BATCH_INSERT_SIZE:
                return True

            elapsed = (datetime.now(timezone.utc) - self._last_flush).total_seconds()
            if elapsed >= settings.TAG_BUFFER_FLUSH_INTERVAL_S and self._buffer:
                return True

            return False

    @property
    def size(self) -> int:
        return len(self._buffer)


class TagCollector:
    """Background service to collect PLC tag values at intervals."""

    def __init__(self):
        self._buffer = TagBuffer()
        self._running = False
        self._tasks: List[asyncio.Task] = []
        self._tag_configs: Dict[str, List[str]] = defaultdict(list)  # plc_id -> tag_names

    def register_tags(self, plc_id: str, tag_names: List[str]):
        """Register tags to collect from a PLC."""
        self._tag_configs[plc_id] = list(set(self._tag_configs[plc_id] + tag_names))
        logger.info(f"Registered {len(tag_names)} tags for PLC {plc_id}")

    def unregister_plc(self, plc_id: str):
        """Remove all tags for a PLC."""
        if plc_id in self._tag_configs:
            del self._tag_configs[plc_id]

    async def start(self):
        """Start collection tasks."""
        self._running = True
        # Start collector for each PLC
        for plc_id in self._tag_configs:
            task = asyncio.create_task(self._collect_loop(plc_id))
            self._tasks.append(task)

        # Start flush task
        flush_task = asyncio.create_task(self._flush_loop())
        self._tasks.append(flush_task)

        logger.info(f"Tag collector started for {len(self._tag_configs)} PLCs")

    async def stop(self):
        """Stop all collection tasks."""
        self._running = False
        for task in self._tasks:
            task.cancel()

        # Final flush
        await self._buffer.flush()
        logger.info("Tag collector stopped")

    async def _collect_loop(self, plc_id: str):
        """Collect tags from a single PLC at intervals."""
        from app.services.plc_service import plc_service

        while self._running:
            try:
                tag_names = self._tag_configs.get(plc_id, [])
                if not tag_names:
                    await asyncio.sleep(5)
                    continue

                result = await plc_service.read_plc_tags(plc_id, tag_names)

                # Values are already logged to DB by read_plc_tags
                # But we also buffer for any additional processing
                for r in result.get("results", []):
                    if r["status"] == "Success":
                        await self._buffer.add([{
                            "time": datetime.now(timezone.utc),
                            "plc_id": plc_id,
                            "tag_name": r["tag"],
                            "tag_value": r["value"],
                            "tag_quality": 192
                        }])

                await asyncio.sleep(settings.TAG_SAMPLING_INTERVAL_MS / 1000)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error collecting tags from {plc_id}: {e}")
                await asyncio.sleep(5)

    async def _flush_loop(self):
        """Periodically flush buffer to database."""
        while self._running:
            try:
                if await self._buffer.should_flush():
                    count = await self._buffer.flush()
                    if count > 0:
                        logger.debug(f"Flushed {count} tag values to TimescaleDB")

                await asyncio.sleep(1)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in flush loop: {e}")
                await asyncio.sleep(5)


class TimeSeriesService:
    """Service for querying time-series data with aggregation."""

    @staticmethod
    async def get_tag_trend(
        plc_id: str,
        tag_name: str,
        hours: int = 24,
        bucket: str = "1 minute"
    ) -> Dict[str, Any]:
        """Get tag trend with aggregation."""
        from datetime import timedelta

        end_time = datetime.now(timezone.utc)
        start_time = end_time - timedelta(hours=hours)

        data = await get_tag_history(plc_id, tag_name, start_time, end_time, bucket)

        return {
            "plc_id": plc_id,
            "tag_name": tag_name,
            "bucket": bucket,
            "points": len(data),
            "data": data
        }

    @staticmethod
    async def get_plc_snapshot(plc_id: str) -> Dict[str, Any]:
        """Get current snapshot of all tags for a PLC."""
        tags = await get_current_tag_values(plc_id)

        return {
            "plc_id": plc_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "tag_count": len(tags),
            "tags": tags
        }

    @staticmethod
    async def get_recipe_execution_history(
        recipe_id: str,
        hours: int = 168  # 7 days
    ) -> Dict[str, Any]:
        """Get recipe execution history with tag trends."""
        from app.core.database import get_download_history

        downloads = await get_download_history(recipe_id=recipe_id, hours=hours)

        # Get tag trends during recipe execution
        # This would join with plc_tag_values filtered by recipe_id

        return {
            "recipe_id": recipe_id,
            "download_count": len(downloads),
            "success_rate": (
                sum(1 for d in downloads if d["status"] == "SUCCESS") / len(downloads) * 100
                if downloads else 0
            ),
            "downloads": downloads
        }


# Global instances
tag_collector = TagCollector()
timeseries_service = TimeSeriesService()
