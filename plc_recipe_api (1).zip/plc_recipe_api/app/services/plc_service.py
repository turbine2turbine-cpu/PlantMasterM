"""PLC service - download recipes, read/write tags with retry logic."""
import logging
import asyncio
import uuid
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List

from app.core.config import settings
from app.core.database import (
    db, get_recipe_by_id, log_recipe_download, log_process_event,
    insert_tag_values_batch
)
from app.clients.plc_client import get_plc_client, AsyncPyLogixClient
from app.clients.opcua_client import get_opcua_client, OpcuaClient

logger = logging.getLogger(__name__)


class PlcService:
    """Service for PLC operations with retry and transaction safety."""

    def __init__(self):
        self._download_queue: asyncio.Queue = asyncio.Queue(
            maxsize=settings.DOWNLOAD_QUEUE_MAX_SIZE
        )
        self._download_results: Dict[str, Dict[str, Any]] = {}
        self._running = False

    async def start_worker(self):
        """Start background worker for processing download queue."""
        self._running = True
        asyncio.create_task(self._process_download_queue())
        logger.info("PLC download worker started")

    async def stop_worker(self):
        """Stop background worker."""
        self._running = False
        # Wait for queue to empty
        await self._download_queue.join()
        logger.info("PLC download worker stopped")

    async def _process_download_queue(self):
        """Background worker to process download jobs."""
        while self._running:
            try:
                job = await asyncio.wait_for(
                    self._download_queue.get(), timeout=1.0
                )
                await self._execute_download(job)
                self._download_queue.task_done()
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Error in download worker: {e}")

    async def _execute_download(self, job: Dict[str, Any]):
        """Execute single download job with full transaction logic."""
        tx_id = job["transaction_id"]
        recipe_id = job["recipe_id"]
        plc_id = job["plc_id"]
        user = job["user"]
        validate = job.get("validate", True)
        backup = job.get("backup_current", True)

        start_time = datetime.now(timezone.utc)

        try:
            # 1. Get recipe from DB
            recipe = await get_recipe_by_id(recipe_id)
            if not recipe:
                raise ValueError(f"Recipe {recipe_id} not found")

            # 2. Validate parameters
            if validate:
                validation = await self._validate_parameters(recipe)
                if not validation["valid"]:
                    raise ValueError(f"Validation failed: {validation['errors']}")

            # 3. Get PLC client
            plc_client = self._get_client_for_plc(plc_id)

            # 4. Connect to PLC
            connected = await self._connect_with_retry(plc_client)
            if not connected:
                raise ConnectionError(f"Cannot connect to PLC {plc_id}")

            try:
                # 5. Backup current recipe on PLC (if enabled)
                if backup:
                    await self._backup_current_recipe(plc_client, plc_id, recipe)

                # 6. Write parameters to PLC
                write_results = await self._write_recipe_to_plc(
                    plc_client, recipe, plc_id
                )

                # 7. Write PO Number to PLC if provided
                po_written = False
                if job.get("po_number"):
                    po_result = await plc_client.write_tag("Recipe.PONumber", job["po_number"])
                    if po_result.status == "Success":
                        po_written = True
                        logger.info(f"PO Number {job['po_number']} written to PLC")
                    else:
                        logger.warning(f"Failed to write PO Number: {po_result.error}")

                # 8. Verify write (read back)
                verified = await self._verify_plc_write(plc_client, write_results)

                # 9. Log success
                duration = int((datetime.now(timezone.utc) - start_time).total_seconds() * 1000)
                await log_recipe_download(
                    recipe_id=recipe_id,
                    plc_id=plc_id,
                    downloaded_by=user,
                    status="SUCCESS",
                    duration_ms=duration,
                    plc_ack=verified
                )

                # Log order execution if order_id exists
                if job.get("order_id"):
                    from app.core.database import log_order_execution
                    await log_order_execution(
                        order_id=job["order_id"],
                        po_number=job.get("po_number", ""),
                        recipe_id=recipe_id,
                        plc_id=plc_id,
                        event_type="download_success",
                        message=f"Recipe downloaded successfully. PO: {job.get('po_number', 'N/A')}"
                    )

                await log_process_event(
                    event_type="RECIPE_DOWNLOADED",
                    plc_id=plc_id,
                    recipe_id=recipe_id,
                    severity=1,
                    message=f"Recipe {recipe['recipe_code']} downloaded successfully"
                )

                self._download_results[tx_id] = {
                    "status": "SUCCESS",
                    "message": "Recipe downloaded to PLC successfully",
                    "duration_ms": duration,
                    "verified": verified,
                    "tags_written": len(write_results)
                }

                logger.info(f"Download {tx_id} completed successfully in {duration}ms")

            finally:
                await plc_client.disconnect()

        except Exception as e:
            duration = int((datetime.now(timezone.utc) - start_time).total_seconds() * 1000)
            error_msg = str(e)

            await log_recipe_download(
                recipe_id=recipe_id,
                plc_id=plc_id,
                downloaded_by=user,
                status="FAILED",
                error_message=error_msg,
                duration_ms=duration
            )

            await log_process_event(
                event_type="RECIPE_DOWNLOAD_FAILED",
                plc_id=plc_id,
                recipe_id=recipe_id,
                severity=3,
                message=f"Download failed: {error_msg}"
            )

            self._download_results[tx_id] = {
                "status": "FAILED",
                "message": error_msg,
                "duration_ms": duration
            }

            logger.error(f"Download {tx_id} failed: {error_msg}")

    def _get_client_for_plc(self, plc_id: str):
        """Get appropriate client for PLC (PyLogix or OPC UA)."""
        # In production, load PLC config from database
        # For now, use settings defaults
        if settings.OPC_UA_ENDPOINT:
            return get_opcua_client(
                plc_id=plc_id,
                endpoint=settings.OPC_UA_ENDPOINT,
                username=settings.OPC_UA_USERNAME,
                password=settings.OPC_UA_PASSWORD
            )
        else:
            return get_plc_client(
                plc_id=plc_id,
                host=settings.PLC_HOST,
                slot=settings.PLC_SLOT,
                timeout=settings.PLC_TIMEOUT
            )

    async def _connect_with_retry(self, client) -> bool:
        """Connect to PLC with retry logic."""
        for attempt in range(settings.PLC_RETRY_ATTEMPTS):
            try:
                connected = await client.connect()
                if connected:
                    return True
            except Exception as e:
                logger.warning(f"PLC connection attempt {attempt + 1} failed: {e}")

            if attempt < settings.PLC_RETRY_ATTEMPTS - 1:
                await asyncio.sleep(settings.PLC_RETRY_DELAY * (attempt + 1))

        return False

    async def _validate_parameters(self, recipe: Dict[str, Any]) -> Dict[str, Any]:
        """Validate recipe parameters before sending to PLC."""
        errors = []

        for param in recipe.get("parameters", []):
            val = param.get("value_default")
            min_val = param.get("value_min")
            max_val = param.get("value_max")
            plc_tag = param.get("plc_tag")

            if not plc_tag:
                errors.append(f"{param['param_name']}: Missing PLC tag")
                continue

            if val is None:
                errors.append(f"{param['param_name']}: No value to write")
                continue

            try:
                numeric_val = float(val)
                if min_val is not None and numeric_val < min_val:
                    errors.append(
                        f"{param['param_name']}: {numeric_val} < min {min_val}"
                    )
                if max_val is not None and numeric_val > max_val:
                    errors.append(
                        f"{param['param_name']}: {numeric_val} > max {max_val}"
                    )
            except (ValueError, TypeError):
                # Non-numeric types skip range check
                pass

        return {"valid": len(errors) == 0, "errors": errors}

    async def _backup_current_recipe(self, client, plc_id: str, recipe: Dict[str, Any]):
        """Backup current PLC values before writing new recipe."""
        tag_names = [p["plc_tag"] for p in recipe.get("parameters", []) if p.get("plc_tag")]
        if not tag_names:
            return

        results = await client.read_tags(tag_names)
        backup_data = []
        for result in results:
            if result.status == "Success":
                backup_data.append({
                    "time": datetime.now(timezone.utc),
                    "plc_id": plc_id,
                    "tag_name": result.tag_name,
                    "tag_value": result.value,
                    "tag_quality": 192,
                    "recipe_id": recipe.get("id")
                })

        if backup_data:
            await insert_tag_values_batch(backup_data)
            logger.info(f"Backed up {len(backup_data)} tags from PLC {plc_id}")

    async def _write_recipe_to_plc(
        self, client, recipe: Dict[str, Any], plc_id: str
    ) -> List[Dict[str, Any]]:
        """Write recipe parameters to PLC tags."""
        tags_to_write = {}
        for param in recipe.get("parameters", []):
            tag = param.get("plc_tag")
            val = param.get("value_default")
            if tag and val is not None:
                # Cast value to correct type
                casted_val = self._cast_value(val, param.get("param_type", "REAL"))
                tags_to_write[tag] = casted_val

        if not tags_to_write:
            raise ValueError("No valid tags to write")

        results = await client.write_tags(tags_to_write)

        failed = [r for r in results if r.status != "Success"]
        if failed:
            failed_tags = [f"{r.tag_name}: {r.error}" for r in failed]
            raise RuntimeError(f"Failed to write tags: {', '.join(failed_tags)}")

        return [{"tag": r.tag_name, "value": r.value} for r in results]

    def _cast_value(self, value: Any, param_type: str) -> Any:
        """Cast value to appropriate PLC type."""
        type_map = {
            "BOOL": bool,
            "INT": int,
            "DINT": int,
            "REAL": float,
            "STRING": str
        }
        caster = type_map.get(param_type, float)
        try:
            return caster(value)
        except (ValueError, TypeError):
            return value

    async def _verify_plc_write(self, client, write_results: List[Dict[str, Any]]) -> bool:
        """Verify written values by reading them back."""
        tag_names = [w["tag"] for w in write_results]
        read_results = await client.read_tags(tag_names)

        all_match = True
        for write, read in zip(write_results, read_results):
            if read.status != "Success":
                all_match = False
                logger.warning(f"Verification failed for {read.tag_name}: {read.error}")
                continue

            try:
                if abs(float(write["value"]) - float(read.value)) > 0.001:
                    all_match = False
                    logger.warning(
                        f"Verification mismatch {read.tag_name}: "
                        f"wrote {write['value']}, read {read.value}"
                    )
            except (ValueError, TypeError):
                if str(write["value"]) != str(read.value):
                    all_match = False

        return all_match

    # ─── Public API Methods ───

    async def queue_download(
        self, recipe_id: str, plc_id: str, user: str = "system",
        validate: bool = True, backup_current: bool = True,
        po_number: str = None, order_id: str = None
    ) -> str:
        """Queue a recipe download job."""
        tx_id = str(uuid.uuid4())
        job = {
            "transaction_id": tx_id,
            "recipe_id": recipe_id,
            "plc_id": plc_id,
            "user": user,
            "validate": validate,
            "backup_current": backup_current,
            "po_number": po_number,
            "order_id": order_id,
            "queued_at": datetime.now(timezone.utc).isoformat()
        }

        await self._download_queue.put(job)
        self._download_results[tx_id] = {"status": "PENDING"}

        logger.info(f"Download queued: {tx_id}")
        return tx_id

    async def get_download_status(self, transaction_id: str) -> Dict[str, Any]:
        """Get download job status."""
        return self._download_results.get(transaction_id, {"status": "NOT_FOUND"})

    async def read_plc_tags(self, plc_id: str, tag_names: List[str]) -> Dict[str, Any]:
        """Read tags from PLC directly."""
        client = self._get_client_for_plc(plc_id)

        try:
            connected = await self._connect_with_retry(client)
            if not connected:
                raise ConnectionError(f"Cannot connect to PLC {plc_id}")

            results = await client.read_tags(tag_names)

            # Log to TimescaleDB
            tag_values = []
            for r in results:
                if r.status == "Success":
                    tag_values.append({
                        "time": datetime.now(timezone.utc),
                        "plc_id": plc_id,
                        "tag_name": r.tag_name,
                        "tag_value": r.value,
                        "tag_quality": 192
                    })

            if tag_values:
                await insert_tag_values_batch(tag_values)

            return {
                "plc_id": plc_id,
                "results": [
                    {"tag": r.tag_name, "value": r.value, "status": r.status, "error": r.error}
                    for r in results
                ]
            }
        finally:
            await client.disconnect()

    async def write_plc_tags(
        self, plc_id: str, tags: Dict[str, Any], user: str = "system"
    ) -> Dict[str, Any]:
        """Write tags to PLC directly."""
        client = self._get_client_for_plc(plc_id)

        try:
            connected = await self._connect_with_retry(client)
            if not connected:
                raise ConnectionError(f"Cannot connect to PLC {plc_id}")

            results = await client.write_tags(tags)

            # Log to TimescaleDB
            tag_values = []
            for r in results:
                if r.status == "Success":
                    tag_values.append({
                        "time": datetime.now(timezone.utc),
                        "plc_id": plc_id,
                        "tag_name": r.tag_name,
                        "tag_value": r.value,
                        "tag_quality": 192
                    })

            if tag_values:
                await insert_tag_values_batch(tag_values)

            success = {r.tag_name: r.value for r in results if r.status == "Success"}
            failed = {r.tag_name: r.error for r in results if r.status != "Success"}

            await log_process_event(
                event_type="PLC_TAGS_WRITTEN" if not failed else "PLC_TAGS_PARTIAL",
                plc_id=plc_id,
                severity=1 if not failed else 2,
                message=f"Wrote {len(success)} tags, failed {len(failed)}"
            )

            return {"plc_id": plc_id, "success": success, "failed": failed}
        finally:
            await client.disconnect()


# Global service instance
plc_service = PlcService()
