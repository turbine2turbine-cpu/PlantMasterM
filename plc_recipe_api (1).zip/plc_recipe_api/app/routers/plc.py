"""PLC operations API endpoints."""
import logging
from typing import List, Dict, Any
from fastapi import APIRouter, HTTPException, BackgroundTasks

from app.models import DownloadRequest, TagReadRequest, TagWriteRequest
from app.services.plc_service import plc_service
from app.services.timeseries_service import timeseries_service
from app.core.database import get_current_tag_values, get_unacknowledged_alarms

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/plc", tags=["PLC"])


@router.post("/download")
async def download_recipe(request: DownloadRequest, background_tasks: BackgroundTasks):
    """Queue recipe download to PLC."""
    tx_id = await plc_service.queue_download(
        recipe_id=request.recipe_id,
        plc_id=request.plc_id,
        user=request.user,
        validate=request.validate,
        backup_current=request.backup_current
    )
    return {
        "transaction_id": tx_id,
        "status": "PENDING",
        "message": "Download queued for processing"
    }


@router.get("/download/{transaction_id}")
async def get_download_status(transaction_id: str):
    """Get download job status."""
    status = await plc_service.get_download_status(transaction_id)
    if status.get("status") == "NOT_FOUND":
        raise HTTPException(status_code=404, detail="Transaction not found")
    return status


@router.post("/read-tags")
async def read_tags(request: TagReadRequest):
    """Read tags from PLC and log to TimescaleDB."""
    try:
        return await plc_service.read_plc_tags(request.plc_id, request.tag_names)
    except Exception as e:
        logger.error(f"Error reading tags: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/write-tags")
async def write_tags(request: TagWriteRequest):
    """Write tags to PLC and log to TimescaleDB."""
    try:
        return await plc_service.write_plc_tags(
            request.plc_id, request.tags, user="api"
        )
    except Exception as e:
        logger.error(f"Error writing tags: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/status/{plc_id}")
async def get_plc_status(plc_id: str):
    """Get PLC connection status and current recipe."""
    from app.clients.plc_client import get_plc_client

    client = get_plc_client(plc_id, "192.168.1.10")

    try:
        connected = await client.connect()
        info = await client.get_plc_info() if connected else {"status": "offline"}
        await client.disconnect()

        tags = await get_current_tag_values(plc_id)
        alarms = await get_unacknowledged_alarms(plc_id)

        return {
            "plc_id": plc_id,
            "is_online": connected,
            "plc_info": info,
            "active_tags": len(tags),
            "unack_alarms": len(alarms),
            "last_tags": tags[:10]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
