"""Production Order API endpoints."""
import logging
from typing import List, Optional
from fastapi import APIRouter, HTTPException, Query

from app.models import ProductionOrderCreate, ProductionOrderUpdate, OrderDownloadRequest
from app.core.database import (
    create_production_order, get_order_by_id, get_order_by_po,
    list_orders, update_order_status, log_order_execution
)
from app.services.plc_service import plc_service

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/orders", tags=["Production Orders"])


@router.get("")
async def get_orders(
    status: Optional[str] = Query(None),
    plc_id: Optional[str] = Query(None)
):
    """List production orders with optional filtering."""
    return await list_orders(status, plc_id)


@router.get("/{order_id}")
async def get_order(order_id: str):
    """Get order by ID with recipe info."""
    order = await get_order_by_id(order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return order


@router.get("/po/{po_number}")
async def get_order_by_po_number(po_number: str):
    """Get order by PO number."""
    order = await get_order_by_po(po_number)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return order


@router.post("", status_code=201)
async def create_order(data: ProductionOrderCreate):
    """Create new production order."""
    try:
        # Check if PO number already exists
        existing = await get_order_by_po(data.po_number)
        if existing:
            raise HTTPException(status_code=400, detail=f"PO number '{data.po_number}' already exists")

        order_id = await create_production_order(data.model_dump())
        return await get_order_by_id(order_id)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating order: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{order_id}")
async def update_order(order_id: str, data: ProductionOrderUpdate):
    """Update order status or details."""
    from app.core.database import db

    async with db.acquire() as conn:
        updates = []
        params = []
        if data.status:
            updates.append("status = $" + str(len(params) + 1))
            params.append(data.status.value)
        if data.quantity:
            updates.append("quantity = $" + str(len(params) + 1))
            params.append(data.quantity)
        if data.notes:
            updates.append("notes = $" + str(len(params) + 1))
            params.append(data.notes)
        if data.operator:
            updates.append("operator = $" + str(len(params) + 1))
            params.append(data.operator)

        if not updates:
            raise HTTPException(status_code=400, detail="No fields to update")

        updates.append("updated_at = NOW()")

        if data.status == "running":
            updates.append("started_at = COALESCE(started_at, NOW())")
        if data.status == "completed":
            updates.append("completed_at = NOW()")

        query = f"""UPDATE production_orders SET {', '.join(updates)} WHERE id = ${len(params) + 1}"""
        params.append(order_id)

        result = await conn.execute(query, *params)
        if result != "UPDATE 1":
            raise HTTPException(status_code=404, detail="Order not found")

    return await get_order_by_id(order_id)


@router.post("/{order_id}/download")
async def download_order_to_plc(order_id: str, request: OrderDownloadRequest):
    """Download recipe for this order to PLC with PO number."""
    order = await get_order_by_id(order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    if order["status"] == "cancelled":
        raise HTTPException(status_code=400, detail="Order is cancelled")

    # Queue download with PO number
    tx_id = await plc_service.queue_download(
        recipe_id=order["recipe_id"],
        plc_id=request.plc_id,
        user=request.user,
        validate=request.validate,
        backup_current=request.backup_current,
        po_number=order["po_number"],
        order_id=order_id
    )

    # Update order status to running
    await update_order_status(order_id, "running")

    # Log execution
    await log_order_execution(
        order_id=order_id,
        po_number=order["po_number"],
        recipe_id=order["recipe_id"],
        plc_id=request.plc_id,
        event_type="download_queued",
        message=f"Download queued for PO {order['po_number']}"
    )

    return {
        "transaction_id": tx_id,
        "order_id": order_id,
        "po_number": order["po_number"],
        "status": "PENDING",
        "message": f"PO {order['po_number']} queued for download to PLC"
    }


@router.get("/{order_id}/history")
async def get_order_history(order_id: str, hours: int = Query(168)):
    """Get execution history for an order."""
    from app.core.database import db

    async with db.acquire() as conn:
        rows = await conn.fetch(
            """
            SELECT time, order_id, po_number, event_type, tag_name, tag_value, message
            FROM order_executions
            WHERE order_id = $1 AND time > NOW() - INTERVAL '%s hours'
            ORDER BY time DESC
            """ % hours,
            order_id
        )
        return [dict(r) for r in rows]
