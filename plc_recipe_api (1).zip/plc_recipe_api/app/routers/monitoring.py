"""Monitoring and time-series query endpoints."""
import logging
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Query

from app.services.timeseries_service import timeseries_service
from app.core.database import get_tag_history, get_download_history, get_unacknowledged_alarms

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/monitoring", tags=["Monitoring"])


@router.get("/tags/{plc_id}/trend")
async def get_tag_trend(
    plc_id: str,
    tag_name: str = Query(...),
    hours: int = Query(24, ge=1, le=720),
    bucket: str = Query("1 minute", regex="^(1 minute|5 minutes|1 hour)$")
):
    """Get tag trend with time-bucket aggregation."""
    return await timeseries_service.get_tag_trend(plc_id, tag_name, hours, bucket)


@router.get("/tags/{plc_id}/current")
async def get_current_tags(plc_id: str):
    """Get current snapshot of all PLC tags."""
    return await timeseries_service.get_plc_snapshot(plc_id)


@router.get("/downloads")
async def get_downloads(
    recipe_id: str = Query(None),
    plc_id: str = Query(None),
    hours: int = Query(24, ge=1, le=720)
):
    """Get recipe download history."""
    return await get_download_history(recipe_id, plc_id, hours)


@router.get("/alarms")
async def get_alarms(
    plc_id: str = Query(None),
    unacknowledged_only: bool = Query(True)
):
    """Get process events/alarms."""
    if unacknowledged_only:
        return await get_unacknowledged_alarms(plc_id)
    return []


@router.get("/recipe/{recipe_id}/execution")
async def get_recipe_execution(recipe_id: str, hours: int = Query(168)):
    """Get recipe execution history with success rate."""
    return await timeseries_service.get_recipe_execution_history(recipe_id, hours)
