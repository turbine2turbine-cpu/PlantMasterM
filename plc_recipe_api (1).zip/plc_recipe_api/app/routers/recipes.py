"""Recipe API endpoints."""
import logging
from typing import List, Optional
from fastapi import APIRouter, HTTPException, Query

from app.models import RecipeCreate, RecipeUpdate, RecipeResponse
from app.core.database import get_recipe_by_id, list_recipes
from app.services.recipe_service import RecipeService

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/recipes", tags=["Recipes"])


@router.get("")
async def get_recipes(
    product_id: Optional[str] = Query(None),
    active_only: bool = Query(True)
):
    """List all recipes with optional filtering."""
    return await list_recipes(product_id, active_only)


@router.get("/{recipe_id}")
async def get_recipe(recipe_id: str):
    """Get recipe by ID with parameters."""
    recipe = await get_recipe_by_id(recipe_id)
    if not recipe:
        raise HTTPException(status_code=404, detail="Recipe not found")
    return recipe


@router.post("", status_code=201)
async def create_recipe(data: RecipeCreate):
    """Create new recipe with parameters."""
    try:
        return await RecipeService.create_recipe(data)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.put("/{recipe_id}")
async def update_recipe(recipe_id: str, data: RecipeUpdate, user: str = "system"):
    """Update recipe (creates new version if parameters change)."""
    try:
        return await RecipeService.update_recipe(recipe_id, data, user)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.delete("/{recipe_id}")
async def delete_recipe(recipe_id: str):
    """Soft delete recipe."""
    success = await RecipeService.delete_recipe(recipe_id)
    if not success:
        raise HTTPException(status_code=404, detail="Recipe not found")
    return {"message": "Recipe deactivated"}


@router.post("/{recipe_id}/validate")
async def validate_recipe(recipe_id: str):
    """Validate recipe parameters."""
    try:
        return await RecipeService.validate_recipe_parameters(recipe_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.post("/{recipe_id}/compare/{plc_id}")
async def compare_with_plc(recipe_id: str, plc_id: str):
    """Compare recipe with current PLC values."""
    from app.services.plc_service import plc_service
    try:
        recipe = await get_recipe_by_id(recipe_id)
        if not recipe:
            raise HTTPException(status_code=404, detail="Recipe not found")
        return await RecipeService.compare_with_plc(recipe_id, plc_id, plc_service)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/{recipe_id}/version")
async def create_version(recipe_id: str, user: str = "system"):
    """Create new version of recipe."""
    try:
        new_id = await create_recipe_version(recipe_id, user)
        return {"new_version_id": new_id}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
