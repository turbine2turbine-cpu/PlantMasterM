import { Routes, Route } from 'react-router-dom';
import Layout from '@/components/layout/Layout';
import RecipesPage from '@/pages/RecipesPage';
import RecipeEditPage from '@/pages/RecipeEditPage';
import OrdersPage from '@/pages/OrdersPage';
import OrderEditPage from '@/pages/OrderEditPage';
import PlcPage from '@/pages/PlcPage';
import MonitoringPage from '@/pages/MonitoringPage';

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<OrdersPage />} />
        <Route path="/orders" element={<OrdersPage />} />
        <Route path="/orders/new" element={<OrderEditPage />} />
        <Route path="/orders/:id" element={<OrderEditPage />} />
        <Route path="/recipes" element={<RecipesPage />} />
        <Route path="/recipes/new" element={<RecipeEditPage />} />
        <Route path="/recipes/:id" element={<RecipeEditPage />} />
        <Route path="/plc" element={<PlcPage />} />
        <Route path="/monitoring" element={<MonitoringPage />} />
      </Routes>
    </Layout>
  );
}

export default App;
