import { Link, useLocation } from 'react-router-dom';
import { Factory, ClipboardList, Activity, Cpu, Menu, PanelLeftClose, PanelLeftOpen, User, LogOut, ShoppingCart } from 'lucide-react';
import { useState } from 'react';
import LiveClock from './LiveClock';
import { useAuth } from '@/context/AuthContext';

const navItems = [
  { path: '/orders', label: 'Orders', icon: ShoppingCart },
  { path: '/recipes', label: 'Recipes', icon: ClipboardList },
  { path: '/plc', label: 'PLC Control', icon: Cpu },
  { path: '/monitoring', label: 'Monitoring', icon: Activity },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();
  const { user, logout } = useAuth();

  const sidebarBase = "fixed inset-y-0 left-0 z-50 bg-slate-900 text-white transition-all duration-300 flex flex-col ";
  const sidebarMobile = sidebarOpen ? "translate-x-0 " : "-translate-x-full ";
  const sidebarDesktop = "md:translate-x-0 md:static ";
  const sidebarWidth = collapsed ? "md:w-16 " : "md:w-60 ";
  const sidebarClass = sidebarBase + sidebarMobile + sidebarDesktop + sidebarWidth + "w-60";

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={sidebarClass}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-4 py-4 border-b border-slate-700 h-16 overflow-hidden">
          <Factory className="w-6 h-6 text-blue-400 shrink-0" />
          <span className={"font-bold text-lg whitespace-nowrap transition-opacity duration-300 " + (collapsed ? "opacity-0 w-0 hidden" : "opacity-100")}>
            Recipe PLC
          </span>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-2 py-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = location.pathname.startsWith(item.path);
            const navBase = "flex items-center gap-3 px-3 py-3 rounded-lg text-sm font-medium transition-all ";
            const navActive = active ? "bg-blue-600 text-white " : "text-slate-300 hover:bg-slate-800 hover:text-white ";
            const navCollapsed = collapsed ? "justify-center" : "";
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setSidebarOpen(false)}
                className={navBase + navActive + navCollapsed}
                title={collapsed ? item.label : undefined}
              >
                <Icon className="w-5 h-5 shrink-0" />
                <span className={"whitespace-nowrap transition-all duration-300 " + (collapsed ? "opacity-0 w-0 hidden" : "opacity-100")}>
                  {item.label}
                </span>
              </Link>
            );
          })}
        </nav>

        {/* User info at bottom */}
        <div className="border-t border-slate-700 p-3">
          <div className={"flex items-center gap-3 " + (collapsed ? "justify-center" : "")}>
            <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center shrink-0">
              <User className="w-4 h-4 text-white" />
            </div>
            <div className={"overflow-hidden transition-all duration-300 " + (collapsed ? "opacity-0 w-0 hidden" : "opacity-100")}>
              <p className="text-sm font-medium truncate">{user?.displayName || "Guest"}</p>
              <p className="text-xs text-slate-400 truncate">{user?.role}</p>
            </div>
            {!collapsed && (
              <button
                onClick={logout}
                className="ml-auto p-1.5 rounded hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
                title="Logout"
              >
                <LogOut className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        {/* Header */}
        <header className="bg-white border-b px-4 py-3 flex items-center justify-between sticky top-0 z-30 h-16">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="md:hidden p-2 hover:bg-gray-100 rounded-lg"
            >
              <Menu className="w-5 h-5" />
            </button>
            {/* Sidebar toggle - moved to header */}
            <button
              onClick={() => setCollapsed(!collapsed)}
              className="hidden md:flex p-2 hover:bg-gray-100 rounded-lg text-gray-600 transition-colors"
              title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            >
              {collapsed ? (
                <PanelLeftOpen className="w-5 h-5" />
              ) : (
                <PanelLeftClose className="w-5 h-5" />
              )}
            </button>
            <h1 className="text-lg font-semibold text-gray-800 hidden sm:block">
              Recipe Manager for Rockwell PLC
            </h1>
          </div>

          <div className="flex items-center gap-3">
            <LiveClock />
            <div className="hidden md:flex items-center gap-2 pl-3 border-l">
              <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                <User className="w-4 h-4 text-blue-600" />
              </div>
              <div className="text-sm">
                <p className="font-medium text-gray-800">{user?.displayName || "Guest"}</p>
                <p className="text-xs text-gray-500">{user?.role}</p>
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 p-6 overflow-auto">{children}</main>
      </div>
    </div>
  );
}
