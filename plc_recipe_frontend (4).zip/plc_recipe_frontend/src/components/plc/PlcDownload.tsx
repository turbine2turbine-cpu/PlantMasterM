import { useState } from 'react';
import { useRecipes } from '@/hooks/useRecipes';
import { useDownloadRecipe, useDownloadStatus } from '@/hooks/usePlc';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import Alert from '@/components/ui/Alert';
import Badge from '@/components/ui/Badge';
import { Download, RefreshCw, CheckCircle, XCircle, Clock } from 'lucide-react';
import { statusColor } from '@/lib/utils';

const PLC_OPTIONS = [
  { id: 'LINE_A_PLC', name: 'Line A PLC' },
  { id: 'LINE_B_PLC', name: 'Line B PLC' },
  { id: 'LINE_C_PLC', name: 'Line C PLC' },
];

export default function PlcDownload() {
  const { data: recipes } = useRecipes();
  const downloadMutation = useDownloadRecipe();
  const [recipeId, setRecipeId] = useState('');
  const [plcId, setPlcId] = useState('LINE_A_PLC');
  const [txId, setTxId] = useState('');
  const [validate, setValidate] = useState(true);
  const [backup, setBackup] = useState(true);

  const { data: status } = useDownloadStatus(txId);

  const handleDownload = async () => {
    if (!recipeId || !plcId) return;
    const res = await downloadMutation.mutateAsync({
      recipe_id: recipeId,
      plc_id: plcId,
      validate,
      backup_current: backup,
      user: 'operator',
    });
    setTxId(res.transaction_id);
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="bg-white rounded-xl border shadow-sm p-6 space-y-4">
        <h3 className="font-semibold text-lg">Download Recipe to PLC</h3>

        <div className="space-y-3">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Select Recipe</label>
            <Select value={recipeId} onChange={e => setRecipeId(e.target.value)}>
              <option value="">-- Choose Recipe --</option>
              {recipes?.map((r: any) => (
                <option key={r.id} value={r.id}>{r.recipe_code} - {r.recipe_name} (v{r.version})</option>
              ))}
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Select PLC</label>
            <Select value={plcId} onChange={e => setPlcId(e.target.value)}>
              {PLC_OPTIONS.map(p => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </Select>
          </div>

          <div className="flex gap-6 pt-2">
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={validate} onChange={e => setValidate(e.target.checked)} className="rounded" />
              Validate before send
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={backup} onChange={e => setBackup(e.target.checked)} className="rounded" />
              Backup current recipe
            </label>
          </div>
        </div>

        <Button
          onClick={handleDownload}
          disabled={!recipeId || downloadMutation.isPending}
          className="w-full"
          size="lg"
        >
          <Download className="w-5 h-5 mr-2" />
          {downloadMutation.isPending ? 'Queuing...' : 'Download to PLC'}
        </Button>
      </div>

      {txId && status && (
        <div className="bg-white rounded-xl border shadow-sm p-6">
          <h4 className="font-medium mb-3">Transaction Status</h4>
          <div className="flex items-center gap-3 mb-3">
            {status.status === 'PENDING' && <Clock className="w-5 h-5 text-yellow-500 animate-spin" />}
            {status.status === 'SUCCESS' && <CheckCircle className="w-5 h-5 text-green-500" />}
            {status.status === 'FAILED' && <XCircle className="w-5 h-5 text-red-500" />}
            <Badge className={statusColor(status.status)}>{status.status}</Badge>
            {status.duration_ms && <span className="text-sm text-gray-500">({status.duration_ms}ms)</span>}
          </div>
          {status.message && (
            <Alert variant={status.status === 'FAILED' ? 'error' : 'info'}>
              {status.message}
            </Alert>
          )}
          {status.verified !== undefined && (
            <p className="text-sm mt-2">
              Verified: {status.verified ? 'Yes' : 'No'}
              {status.tags_written && ` | Tags written: ${status.tags_written}`}
            </p>
          )}
        </div>
      )}
    </div>
  );
}
