import { usePlcStatus } from '@/hooks/usePlc';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import Badge from '@/components/ui/Badge';
import { Cpu, Wifi, WifiOff, Tag, AlertTriangle } from 'lucide-react';

const PLC_IDS = ['LINE_A_PLC', 'LINE_B_PLC', 'LINE_C_PLC'];

export default function PlcStatusPanel() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {PLC_IDS.map(plcId => (
        <PlcCard key={plcId} plcId={plcId} />
      ))}
    </div>
  );
}

function PlcCard({ plcId }: { plcId: string }) {
  const { data, isLoading } = usePlcStatus(plcId);

  if (isLoading) return <Card className="h-48 animate-pulse bg-gray-100" />;

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Cpu className="w-4 h-4" />
            {plcId}
          </CardTitle>
          {data?.is_online ? (
            <Badge variant="success"><Wifi className="w-3 h-3 mr-1" /> Online</Badge>
          ) : (
            <Badge variant="error"><WifiOff className="w-3 h-3 mr-1" /> Offline</Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-500">Active Tags</span>
            <span className="font-medium">{data?.active_tags ?? 0}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-500">Unack Alarms</span>
            <span className={`font-medium ${data?.unack_alarms ? 'text-red-600' : ''}`}>
              {data?.unack_alarms ?? 0}
            </span>
          </div>
          {data?.last_tags?.slice(0, 3).map((tag: any) => (
            <div key={tag.tag} className="flex justify-between text-xs">
              <span className="text-gray-400 font-mono">{tag.tag}</span>
              <span className="font-mono">{tag.value ?? '---'}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
