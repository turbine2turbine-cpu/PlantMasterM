import { cn } from '@/lib/utils';
import { AlertCircle, CheckCircle, Info } from 'lucide-react';

interface AlertProps {
  children: React.ReactNode;
  variant?: 'info' | 'success' | 'warning' | 'error';
  className?: string;
}

export default function Alert({ children, variant = 'info', className }: AlertProps) {
  const icons = { info: Info, success: CheckCircle, warning: AlertCircle, error: AlertCircle };
  const Icon = icons[variant];
  return (
    <div className={cn(
      'flex items-start gap-3 rounded-lg border p-4',
      {
        'bg-blue-50 border-blue-200 text-blue-800': variant === 'info',
        'bg-green-50 border-green-200 text-green-800': variant === 'success',
        'bg-yellow-50 border-yellow-200 text-yellow-800': variant === 'warning',
        'bg-red-50 border-red-200 text-red-800': variant === 'error',
      },
      className
    )}>
      <Icon className="w-5 h-5 shrink-0 mt-0.5" />
      <div className="text-sm">{children}</div>
    </div>
  );
}
