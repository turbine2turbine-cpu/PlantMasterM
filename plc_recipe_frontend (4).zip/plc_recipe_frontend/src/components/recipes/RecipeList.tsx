import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useRecipes, useDeleteRecipe } from '@/hooks/useRecipes';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import { Plus, Pencil, Trash2, Eye } from 'lucide-react';
import { formatDate } from '@/lib/utils';

export default function RecipeList() {
  const navigate = useNavigate();
  const { data: recipes, isLoading } = useRecipes();
  const deleteMutation = useDeleteRecipe();
  const [deleteId, setDeleteId] = useState<string | null>(null);

  if (isLoading) return <div className="p-8 text-center text-gray-500">Loading recipes...</div>;

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-gray-800">Recipes</h2>
        <Button onClick={() => navigate('/recipes/new')}>
          <Plus className="w-4 h-4 mr-2" /> New Recipe
        </Button>
      </div>

      <div className="bg-white rounded-xl border shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-4 py-3 text-left font-medium text-gray-600">Code</th>
              <th className="px-4 py-3 text-left font-medium text-gray-600">Name</th>
              <th className="px-4 py-3 text-left font-medium text-gray-600">Version</th>
              <th className="px-4 py-3 text-left font-medium text-gray-600">Status</th>
              <th className="px-4 py-3 text-left font-medium text-gray-600">Updated</th>
              <th className="px-4 py-3 text-right font-medium text-gray-600">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {recipes?.map((recipe: any) => (
              <tr key={recipe.id} className="hover:bg-gray-50">
                <td className="px-4 py-3 font-mono text-blue-600">{recipe.recipe_code}</td>
                <td className="px-4 py-3">{recipe.recipe_name}</td>
                <td className="px-4 py-3">v{recipe.version}</td>
                <td className="px-4 py-3">
                  <Badge variant={recipe.is_active ? 'success' : 'default'}>
                    {recipe.is_active ? 'Active' : 'Inactive'}
                  </Badge>
                </td>
                <td className="px-4 py-3 text-gray-500">{formatDate(recipe.updated_at)}</td>
                <td className="px-4 py-3 text-right">
                  <div className="flex justify-end gap-2">
                    <Button variant="ghost" size="sm" onClick={() => navigate(`/recipes/${recipe.id}`)}>
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => setDeleteId(recipe.id)}>
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {deleteId && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-sm w-full mx-4 shadow-xl">
            <h3 className="text-lg font-semibold mb-2">Confirm Delete</h3>
            <p className="text-gray-600 mb-4">Are you sure you want to deactivate this recipe?</p>
            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setDeleteId(null)}>Cancel</Button>
              <Button variant="destructive" onClick={() => { deleteMutation.mutate(deleteId); setDeleteId(null); }}>
                Delete
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
