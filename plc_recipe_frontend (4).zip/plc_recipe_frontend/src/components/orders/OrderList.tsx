import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useOrders, useUpdateOrder } from '@/hooks/useOrders';
import Button from '@/components/ui/Button';
import { Plus, Play, CheckCircle, FileText } from 'lucide-react';
import { formatDate } from '@/lib/utils';

const statusColors: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800',
  running: 'bg-blue-100 text-blue-800',
  completed: 'bg-green-100 text-green-800',
  cancelled: 'bg-gray-100 text-gray-800',
};

export default function OrderList() {
  const navigate = useNavigate();
  const { data: orders, isLoading } = useOrders();
  const updateMutation = useUpdateOrder();
  const [filter, setFilter] = useState('all');

  const filtered = filter === 'all' ? orders : orders?.filter((o: any) => o.status === filter);

  if (isLoading) return <div className="p-8 text-center text-gray-500">Loading orders...</div>;

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-gray-800">Production Orders</h2>
        <Button onClick={() => navigate('/orders/new')}>
          <Plus className="w-4 h-4 mr-2" /> New Order
        </Button>
      </div>

      <div className="flex gap-2">
        {['all', 'pending', 'running', 'completed', 'cancelled'].map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={"px-3 py-1 rounded-full text-sm font-medium capitalize transition-colors " +
              (filter === s ? "bg-slate-800 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200")
            }
          >
            {s}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-xl border shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-4 py-3 text-left font-medium text-gray-600">PO Number</th>
              <th className="px-4 py-3 text-left font-medium text-gray-600">Recipe</th>
              <th className="px-4 py-3 text-left font-medium text-gray-600">PLC</th>
              <th className="px-4 py-3 text-left font-medium text-gray-600">Qty</th>
              <th className="px-4 py-3 text-left font-medium text-gray-600">Status</th>
              <th className="px-4 py-3 text-left font-medium text-gray-600">Created</th>
              <th className="px-4 py-3 text-right font-medium text-gray-600">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {filtered?.map((order: any) => (
              <tr key={order.id} className="hover:bg-gray-50">
                <td className="px-4 py-3 font-mono font-semibold text-blue-600">{order.po_number}</td>
                <td className="px-4 py-3">{order.recipe_code} - {order.recipe_name}</td>
                <td className="px-4 py-3 font-mono text-xs">{order.plc_id}</td>
                <td className="px-4 py-3">{order.quantity}</td>
                <td className="px-4 py-3">
                  <span className={"px-2 py-0.5 rounded-full text-xs font-medium " + (statusColors[order.status] || 'bg-gray-100')}>
                    {order.status}
                  </span>
                </td>
                <td className="px-4 py-3 text-gray-500">{formatDate(order.created_at)}</td>
                <td className="px-4 py-3 text-right">
                  <div className="flex justify-end gap-2">
                    {order.status === 'pending' && (
                      <Button size="sm" variant="outline" onClick={() => navigate(`/orders/${order.id}`)}>
                        <Play className="w-3 h-3 mr-1" /> Start
                      </Button>
                    )}
                    {order.status === 'running' && (
                      <Button size="sm" variant="outline" onClick={() => updateMutation.mutate({ id: order.id, data: { status: 'completed' } })}>
                        <CheckCircle className="w-3 h-3 mr-1" /> Complete
                      </Button>
                    )}
                    <Button size="sm" variant="ghost" onClick={() => navigate(`/orders/${order.id}`)}>
                      <FileText className="w-4 h-4" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
