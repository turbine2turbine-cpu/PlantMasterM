import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useOrder, useCreateOrder, useDownloadOrder } from '@/hooks/useOrders';
import { useRecipes } from '@/hooks/useRecipes';
import { useDownloadStatus } from '@/hooks/usePlc';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import Alert from '@/components/ui/Alert';
import { Save, Download, ArrowLeft, Clock } from 'lucide-react';
import { formatDate, statusColor } from '@/lib/utils';

const PLC_OPTIONS = [
  { id: 'LINE_A_PLC', name: 'Line A PLC' },
  { id: 'LINE_B_PLC', name: 'Line B PLC' },
  { id: 'LINE_C_PLC', name: 'Line C PLC' },
];

export default function OrderEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isNew = !id;
  const { data: existing } = useOrder(id || '');
  const { data: recipes } = useRecipes();
  const createMutation = useCreateOrder();
  const downloadMutation = useDownloadOrder();
  const [txId, setTxId] = useState('');
  const { data: downloadStatus } = useDownloadStatus(txId);

  const [poNumber, setPoNumber] = useState('');
  const [recipeId, setRecipeId] = useState('');
  const [plcId, setPlcId] = useState('LINE_A_PLC');
  const [quantity, setQuantity] = useState(1);
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (existing) {
      setPoNumber(existing.po_number);
      setRecipeId(existing.recipe_id);
      setPlcId(existing.plc_id);
      setQuantity(existing.quantity);
      setNotes(existing.notes || '');
    }
  }, [existing]);

  const handleCreate = async () => {
    try {
      await createMutation.mutateAsync({
        po_number: poNumber,
        recipe_id: recipeId,
        plc_id: plcId,
        quantity,
        notes,
      });
      navigate('/orders');
    } catch (e: any) {
      setError(e.response?.data?.detail || 'Create failed');
    }
  };

  const handleDownload = async () => {
    if (!id) return;
    try {
      const res = await downloadMutation.mutateAsync({ orderId: id, plcId });
      setTxId(res.transaction_id);
    } catch (e: any) {
      setError(e.response?.data?.detail || 'Download failed');
    }
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={() => navigate('/orders')}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <h2 className="text-xl font-bold">{isNew ? 'New Production Order' : 'Order Details'}</h2>
        {existing && (
          <span className={"px-2 py-0.5 rounded-full text-xs font-medium " + statusColor(existing.status)}>
            {existing.status}
          </span>
        )}
      </div>

      {error && <Alert variant="error">{error}</Alert>}

      <div className="bg-white rounded-xl border shadow-sm p-6 space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">PO Number</label>
            <Input
              value={poNumber}
              onChange={e => setPoNumber(e.target.value)}
              disabled={!isNew}
              placeholder="PO-2024-001"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Quantity</label>
            <Input
              type="number"
              value={quantity}
              onChange={e => setQuantity(Number(e.target.value))}
              min={1}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Recipe</label>
            <Select value={recipeId} onChange={e => setRecipeId(e.target.value)} disabled={!isNew}>
              <option value="">-- Select Recipe --</option>
              {recipes?.map((r: any) => (
                <option key={r.id} value={r.id}>{r.recipe_code} - {r.recipe_name}</option>
              ))}
            </Select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Target PLC</label>
            <Select value={plcId} onChange={e => setPlcId(e.target.value)} disabled={!isNew}>
              {PLC_OPTIONS.map(p => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </Select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
          <Input value={notes} onChange={e => setNotes(e.target.value)} placeholder="Production notes..." />
        </div>

        {isNew ? (
          <Button onClick={handleCreate} disabled={createMutation.isPending} className="w-full">
            <Save className="w-4 h-4 mr-2" />
            {createMutation.isPending ? 'Creating...' : 'Create Order'}
          </Button>
        ) : existing?.status === 'pending' && (
          <Button onClick={handleDownload} disabled={downloadMutation.isPending} className="w-full">
            <Download className="w-4 h-4 mr-2" />
            {downloadMutation.isPending ? 'Downloading...' : 'Download Recipe to PLC'}
          </Button>
        )}
      </div>

      {txId && downloadStatus && downloadStatus.status !== 'NOT_FOUND' && (
        <div className="bg-white rounded-xl border shadow-sm p-6">
          <h4 className="font-medium mb-3 flex items-center gap-2">
            <Clock className="w-4 h-4" />
            Download Status
          </h4>
          <div className="flex items-center gap-3 mb-3">
            <span className={"px-2 py-0.5 rounded-full text-xs font-medium " + statusColor(downloadStatus.status)}>
              {downloadStatus.status}
            </span>
            {downloadStatus.duration_ms && <span className="text-sm text-gray-500">({downloadStatus.duration_ms}ms)</span>}
          </div>
          {downloadStatus.po_number && (
            <p className="text-sm text-gray-600">PO Number written: <span className="font-mono font-semibold">{downloadStatus.po_number}</span></p>
          )}
          {downloadStatus.message && (
            <Alert variant={downloadStatus.status === 'FAILED' ? 'error' : 'info'} className="mt-2">
              {downloadStatus.message}
            </Alert>
          )}
        </div>
      )}

      {existing && !isNew && (
        <div className="bg-white rounded-xl border shadow-sm p-6 space-y-2 text-sm">
          <h4 className="font-medium mb-2">Order Timeline</h4>
          <div className="flex justify-between text-gray-600">
            <span>Created</span>
            <span>{formatDate(existing.created_at)}</span>
          </div>
          {existing.started_at && (
            <div className="flex justify-between text-gray-600">
              <span>Started</span>
              <span>{formatDate(existing.started_at)}</span>
            </div>
          )}
          {existing.completed_at && (
            <div className="flex justify-between text-gray-600">
              <span>Completed</span>
              <span>{formatDate(existing.completed_at)}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
