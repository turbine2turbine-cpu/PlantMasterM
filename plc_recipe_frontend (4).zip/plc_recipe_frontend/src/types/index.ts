export interface Recipe {
  id: string;
  recipe_code: string;
  recipe_name: string;
  product_id: string | null;
  version: number;
  is_active: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
  parameters?: RecipeParameter[];
}

export interface RecipeParameter {
  id?: string;
  param_name: string;
  param_type: 'INT' | 'REAL' | 'DINT' | 'BOOL' | 'STRING';
  value_default: number | string | boolean | null;
  value_min?: number | null;
  value_max?: number | null;
  plc_tag: string;
  unit?: string | null;
  sort_order: number;
}

export interface DownloadRequest {
  recipe_id: string;
  plc_id: string;
  validate: boolean;
  backup_current: boolean;
  user: string;
}

export interface DownloadStatus {
  transaction_id: string;
  status: 'PENDING' | 'SUCCESS' | 'FAILED' | 'NOT_FOUND';
  message?: string;
  duration_ms?: number;
  verified?: boolean;
  tags_written?: number;
}

export interface PlcTagResult {
  tag: string;
  value: number | string | boolean | null;
  status: string;
  error?: string;
}

export interface PlcStatus {
  plc_id: string;
  is_online: boolean;
  plc_info: Record<string, unknown>;
  active_tags: number;
  unack_alarms: number;
  last_tags: PlcTagResult[];
}

export interface TagTrendPoint {
  bucket: string;
  avg_value: number;
  min_value: number;
  max_value: number;
  sample_count: number;
}

export interface ProcessEvent {
  time: string;
  event_type: string;
  plc_id: string | null;
  recipe_id: string | null;
  severity: number;
  message: string;
  ack_by: string | null;
}

export interface ValidationResult {
  recipe_id: string;
  recipe_code: string;
  valid: boolean;
  errors: string[];
  warnings: string[];
}

export interface RecipeComparison {
  recipe_id: string;
  plc_id: string;
  matches: number;
  total: number;
  comparisons: Array<{
    param_name: string;
    plc_tag: string;
    recipe_value: unknown;
    plc_value: unknown;
    unit: string | null;
    match: boolean;
    deviation?: number;
  }>;
}


export interface ProductionOrder {
  id: string;
  po_number: string;
  recipe_id: string;
  plc_id: string;
  quantity: number;
  status: 'pending' | 'running' | 'completed' | 'cancelled';
  operator: string | null;
  notes: string | null;
  started_at: string | null;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
  recipe_name?: string;
  recipe_code?: string;
}

export interface OrderCreate {
  po_number: string;
  recipe_id: string;
  plc_id: string;
  quantity: number;
  operator?: string;
  notes?: string;
}

export interface OrderExecution {
  time: string;
  order_id: string;
  po_number: string;
  event_type: string;
  tag_name: string | null;
  tag_value: number | null;
  message: string | null;
}
