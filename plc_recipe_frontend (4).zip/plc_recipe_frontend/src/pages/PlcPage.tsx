import PlcDownload from '@/components/plc/PlcDownload';
import PlcStatusPanel from '@/components/plc/PlcStatus';

export default function PlcPage() {
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold">PLC Control</h2>
      <PlcStatusPanel />
      <PlcDownload />
    </div>
  );
}
