import OrderEditor from '@/components/orders/OrderEditor';

export default function OrderEditPage() {
  return <OrderEditor />;
}
