import RecipeEditor from '@/components/recipes/RecipeEditor';

export default function RecipeEditPage() {
  return <RecipeEditor />;
}
