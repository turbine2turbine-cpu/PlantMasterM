import { useQuery, useMutation } from '@tanstack/react-query';
import { plcApi } from '@/services/api';
import type { DownloadRequest } from '@/types';

export function usePlcStatus(plcId: string) {
  return useQuery({
    queryKey: ['plc-status', plcId],
    queryFn: () => plcApi.status(plcId),
    refetchInterval: 5000,
    enabled: !!plcId,
  });
}

export function useDownloadRecipe() {
  return useMutation({
    mutationFn: plcApi.download,
  });
}

export function useDownloadStatus(txId: string) {
  return useQuery({
    queryKey: ['download-status', txId],
    queryFn: () => plcApi.downloadStatus(txId),
    refetchInterval: (data) => {
      return data?.status === 'PENDING' ? 1000 : false;
    },
    enabled: !!txId,
  });
}

export function useReadTags() {
  return useMutation({
    mutationFn: ({ plcId, tagNames }: { plcId: string; tagNames: string[] }) =>
      plcApi.readTags(plcId, tagNames),
  });
}
