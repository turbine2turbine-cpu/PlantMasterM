import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { orderApi } from '@/services/api';

export function useOrders(status?: string, plcId?: string) {
  return useQuery({
    queryKey: ['orders', status, plcId],
    queryFn: () => orderApi.list(status, plcId),
  });
}

export function useOrder(id: string) {
  return useQuery({
    queryKey: ['order', id],
    queryFn: () => orderApi.get(id),
    enabled: !!id,
  });
}

export function useOrderByPo(poNumber: string) {
  return useQuery({
    queryKey: ['order-po', poNumber],
    queryFn: () => orderApi.getByPo(poNumber),
    enabled: !!poNumber,
  });
}

export function useCreateOrder() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: orderApi.create,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['orders'] }),
  });
}

export function useUpdateOrder() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => orderApi.update(id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['orders'] }),
  });
}

export function useDownloadOrder() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ orderId, plcId }: { orderId: string; plcId: string }) =>
      orderApi.download(orderId, plcId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['orders'] });
      qc.invalidateQueries({ queryKey: ['download-status'] });
    },
  });
}

export function useOrderHistory(orderId: string) {
  return useQuery({
    queryKey: ['order-history', orderId],
    queryFn: () => orderApi.history(orderId),
    enabled: !!orderId,
  });
}
