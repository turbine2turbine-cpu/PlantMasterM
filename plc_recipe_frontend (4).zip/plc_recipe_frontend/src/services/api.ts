import axios from 'axios';
import type {
  Recipe, RecipeCreate, RecipeUpdate, DownloadRequest, DownloadStatus,
  PlcStatus, TagTrendPoint, ProcessEvent, ValidationResult, RecipeComparison
} from '@/types';

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' },
  timeout: 30000,
});

// Recipes
export const recipeApi = {
  list: (productId?: string, activeOnly = true) =>
    api.get('/recipes', { params: { product_id: productId, active_only: activeOnly } }).then(r => r.data),
  get: (id: string) =>
    api.get(`/recipes/${id}`).then(r => r.data),
  create: (data: RecipeCreate) =>
    api.post('/recipes', data).then(r => r.data),
  update: (id: string, data: RecipeUpdate) =>
    api.put(`/recipes/${id}`, data).then(r => r.data),
  delete: (id: string) =>
    api.delete(`/recipes/${id}`).then(r => r.data),
  validate: (id: string) =>
    api.post(`/recipes/${id}/validate`).then(r => r.data as ValidationResult),
  compare: (recipeId: string, plcId: string) =>
    api.post(`/recipes/${recipeId}/compare/${plcId}`).then(r => r.data as RecipeComparison),
  version: (id: string) =>
    api.post(`/recipes/${id}/version`).then(r => r.data),
};

// PLC
export const plcApi = {
  download: (data: DownloadRequest) =>
    api.post('/plc/download', data).then(r => r.data as { transaction_id: string; status: string }),
  downloadStatus: (txId: string) =>
    api.get(`/plc/download/${txId}`).then(r => r.data as DownloadStatus),
  readTags: (plcId: string, tagNames: string[]) =>
    api.post('/plc/read-tags', { plc_id: plcId, tag_names: tagNames }).then(r => r.data),
  writeTags: (plcId: string, tags: Record<string, unknown>) =>
    api.post('/plc/write-tags', { plc_id: plcId, tags }).then(r => r.data),
  status: (plcId: string) =>
    api.get(`/plc/status/${plcId}`).then(r => r.data as PlcStatus),
};

// Monitoring
export const monitoringApi = {
  tagTrend: (plcId: string, tagName: string, hours = 24, bucket = '1 minute') =>
    api.get(`/monitoring/tags/${plcId}/trend`, { params: { tag_name: tagName, hours, bucket } })
      .then(r => r.data as { plc_id: string; tag_name: string; bucket: string; points: number; data: TagTrendPoint[] }),
  currentTags: (plcId: string) =>
    api.get(`/monitoring/tags/${plcId}/current`).then(r => r.data),
  downloads: (recipeId?: string, plcId?: string, hours = 24) =>
    api.get('/monitoring/downloads', { params: { recipe_id: recipeId, plc_id: plcId, hours } }).then(r => r.data),
  alarms: (plcId?: string, unackOnly = true) =>
    api.get('/monitoring/alarms', { params: { plc_id: plcId, unacknowledged_only: unackOnly } }).then(r => r.data as ProcessEvent[]),
  recipeExecution: (recipeId: string, hours = 168) =>
    api.get(`/monitoring/recipe/${recipeId}/execution`, { params: { hours } }).then(r => r.data),
};



// Production Orders
export const orderApi = {
  list: (status?: string, plcId?: string) =>
    axios.get('/api/orders', { params: { status, plc_id: plcId } }).then(r => r.data as ProductionOrder[]),
  get: (id: string) =>
    axios.get(`/api/orders/${id}`).then(r => r.data as ProductionOrder),
  getByPo: (poNumber: string) =>
    axios.get(`/api/orders/po/${poNumber}`).then(r => r.data as ProductionOrder),
  create: (data: OrderCreate) =>
    axios.post('/api/orders', data).then(r => r.data as ProductionOrder),
  update: (id: string, data: Partial<OrderCreate> & { status?: string }) =>
    axios.put(`/api/orders/${id}`, data).then(r => r.data as ProductionOrder),
  download: (orderId: string, plcId: string, user?: string) =>
    axios.post(`/api/orders/${orderId}/download`, {
      order_id: orderId,
      plc_id: plcId,
      validate: true,
      backup_current: true,
      user: user || 'operator',
    }).then(r => r.data),
  history: (orderId: string, hours?: number) =>
    axios.get(`/api/orders/${orderId}/history`, { params: { hours } }).then(r => r.data as OrderExecution[]),
};

export default api;
