import { InfluxDB, Point } from '@influxdata/influxdb-client';
import { DeleteAPI } from '@influxdata/influxdb-client-apis';

const url = process.env.INFLUX_URL || 'http://localhost:8086';
const token = process.env.INFLUX_TOKEN || 'opcua-token-12345';
const org = process.env.INFLUX_ORG || 'ai-tech';
const bucket = process.env.INFLUX_BUCKET || 'machine_history';

const influxDB = new InfluxDB({ url, token });
const writeApi = influxDB.getWriteApi(org, bucket, 'ms');
const queryApi = influxDB.getQueryApi(org);

writeApi.useDefaultTags({ source: 'opcua-simulator' });

export async function writeMachineState(machineId, machineName, status, tags) {
  const point = new Point('machine_state')
    .tag('machine_id', machineId)
    .tag('machine_name', machineName)
    .tag('status', status)
    .stringField('status_value', status)
    .floatField('energy', tags.energy || 0)
    .floatField('temperature', tags.temperature || 0)
    .intField('speed', tags.speed || 0)
    .floatField('runtime', tags.runtime || 0)
    .floatField('air_pressure', tags.airPressure || 0)
    .stringField('lubricant', tags.lubricant || '')
    .timestamp(Date.now());

  writeApi.writePoint(point);
  await writeApi.flush();
}

export async function writeTagValues(machineId, machineName, tagValues) {
  const point = new Point('machine_tags')
    .tag('machine_id', machineId)
    .tag('machine_name', machineName)
    .floatField('energy', tagValues.energy || 0)
    .floatField('temperature', tagValues.temperature || 0)
    .intField('speed', tagValues.speed || 0)
    .floatField('runtime', tagValues.runtime || 0)
    .floatField('air_pressure', tagValues.airPressure || 0)
    .stringField('lubricant', tagValues.lubricant || '')
    .timestamp(Date.now());

  writeApi.writePoint(point);
  await writeApi.flush();
}

export async function queryMachineHistory(machineId, hours = 24) {
  const fluxQuery = `
    from(bucket: "${bucket}")
      |> range(start: -${hours}h)
      |> filter(fn: (r) => r._measurement == "machine_state")
      |> filter(fn: (r) => r.machine_id == "${machineId}")
      |> pivot(rowKey:["_time"], columnKey: ["_field"], valueColumn: "_value")
      |> sort(columns: ["_time"], desc: false)
  `;

  const rows = [];
  return new Promise((resolve, reject) => {
    queryApi.queryRows(fluxQuery, {
      next(row, tableMeta) {
        const o = tableMeta.toObject(row);
        rows.push({
          time: o._time,
          machineId: o.machine_id,
          machineName: o.machine_name,
          status: o.status_value,
          energy: o.energy,
          temperature: o.temperature,
          speed: o.speed,
          runtime: o.runtime,
          airPressure: o.air_pressure,
          lubricant: o.lubricant,
        });
      },
      error(error) {
        reject(error);
      },
      complete() {
        resolve(rows);
      },
    });
  });
}

export async function queryTagHistory(machineId, field, hours = 24) {
  const fluxQuery = `
    from(bucket: "${bucket}")
      |> range(start: -${hours}h)
      |> filter(fn: (r) => r._measurement == "machine_tags")
      |> filter(fn: (r) => r.machine_id == "${machineId}")
      |> filter(fn: (r) => r._field == "${field}")
      |> aggregateWindow(every: 1m, fn: mean, createEmpty: false)
      |> yield(name: "mean")
  `;

  const rows = [];
  return new Promise((resolve, reject) => {
    queryApi.queryRows(fluxQuery, {
      next(row, tableMeta) {
        const o = tableMeta.toObject(row);
        rows.push({ time: o._time, value: o._value });
      },
      error(error) {
        reject(error);
      },
      complete() {
        resolve(rows);
      },
    });
  });
}

export async function queryStatusTimeline(machineId, hours = 24) {
  const fluxQuery = `
    from(bucket: "${bucket}")
      |> range(start: -${hours}h)
      |> filter(fn: (r) => r._measurement == "machine_state")
      |> filter(fn: (r) => r.machine_id == "${machineId}")
      |> filter(fn: (r) => r._field == "status_value")
      |> sort(columns: ["_time"], desc: false)
  `;

  const rows = [];
  return new Promise((resolve, reject) => {
    queryApi.queryRows(fluxQuery, {
      next(row, tableMeta) {
        const o = tableMeta.toObject(row);
        rows.push({ time: o._time, status: o._value });
      },
      error(error) {
        reject(error);
      },
      complete() {
        resolve(rows);
      },
    });
  });
}

export { influxDB, writeApi, queryApi };
