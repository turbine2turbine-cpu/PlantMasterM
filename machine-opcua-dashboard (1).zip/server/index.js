import express from 'express';
import cors from 'cors';
import { InfluxDB, Point } from '@influxdata/influxdb-client';

const app = express();
app.use(cors());
app.use(express.json());

// InfluxDB config
const url = process.env.INFLUX_URL || 'http://localhost:8086';
const token = process.env.INFLUX_TOKEN || 'opcua-token-12345';
const org = process.env.INFLUX_ORG || 'ai-tech';
const bucket = process.env.INFLUX_BUCKET || 'machine_history';

const influxDB = new InfluxDB({ url, token });
const writeApi = influxDB.getWriteApi(org, bucket, 'ms');
const queryApi = influxDB.getQueryApi(org);

writeApi.useDefaultTags({ source: 'opcua-dashboard' });

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Write machine state + tags
app.post('/api/write', async (req, res) => {
  try {
    const { machineId, machineName, status, tags } = req.body;
    const now = Date.now();

    const point = new Point('machine_state')
      .tag('machine_id', machineId)
      .tag('machine_name', machineName)
      .tag('status', status)
      .stringField('status_value', status)
      .floatField('energy', tags?.energy || 0)
      .floatField('temperature', tags?.temperature || 0)
      .intField('speed', tags?.speed || 0)
      .floatField('runtime', tags?.runtime || 0)
      .floatField('air_pressure', tags?.airPressure || 0)
      .stringField('lubricant', tags?.lubricant || '')
      .timestamp(now);

    writeApi.writePoint(point);
    await writeApi.flush();

    res.json({ success: true, timestamp: now });
  } catch (err) {
    console.error('Write error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// Query history
app.get('/api/history/:machineId', async (req, res) => {
  try {
    const { machineId } = req.params;
    const hours = parseInt(req.query.hours) || 24;

    const fluxQuery = `
      from(bucket: "${bucket}")
        |> range(start: -${hours}h)
        |> filter(fn: (r) => r._measurement == "machine_state")
        |> filter(fn: (r) => r.machine_id == "${machineId}")
        |> pivot(rowKey:["_time"], columnKey: ["_field"], valueColumn: "_value")
        |> sort(columns: ["_time"], desc: false)
    `;

    const rows = [];
    queryApi.queryRows(fluxQuery, {
      next(row, tableMeta) {
        const o = tableMeta.toObject(row);
        rows.push({
          time: o._time,
          status: o.status_value,
          energy: o.energy,
          temperature: o.temperature,
          speed: o.speed,
          runtime: o.runtime,
          airPressure: o.air_pressure,
          lubricant: o.lubricant,
        });
      },
      error(err) {
        res.status(500).json({ error: err.message });
      },
      complete() {
        res.json(rows);
      },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Query tag history for chart
app.get('/api/history/:machineId/tag/:field', async (req, res) => {
  try {
    const { machineId, field } = req.params;
    const hours = parseInt(req.query.hours) || 24;

    const fluxQuery = `
      from(bucket: "${bucket}")
        |> range(start: -${hours}h)
        |> filter(fn: (r) => r._measurement == "machine_state")
        |> filter(fn: (r) => r.machine_id == "${machineId}")
        |> filter(fn: (r) => r._field == "${field}")
        |> aggregateWindow(every: 5m, fn: mean, createEmpty: false)
        |> yield(name: "mean")
    `;

    const rows = [];
    queryApi.queryRows(fluxQuery, {
      next(row, tableMeta) {
        const o = tableMeta.toObject(row);
        rows.push({ time: o._time, value: o._value });
      },
      error(err) {
        res.status(500).json({ error: err.message });
      },
      complete() {
        res.json(rows);
      },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`🚀 OPC UA History API running on port ${PORT}`);
  console.log(`📊 InfluxDB: ${url} | Bucket: ${bucket}`);
});
