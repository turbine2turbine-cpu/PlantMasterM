export const MACHINES = [
  { id: 'M01', name: 'CNC-Lathe-01',       tag: 'ns=2;s=M01.State', icon: 'cnc' },
  { id: 'M02', name: 'CNC-Mill-02',        tag: 'ns=2;s=M02.State', icon: 'cnc' },
  { id: 'M03', name: 'Conveyor-03',        tag: 'ns=2;s=M03.State', icon: 'conv' },
  { id: 'M04', name: 'CMM-Measure-04',     tag: 'ns=2;s=M04.State', icon: 'cmm' },
  { id: 'M05', name: 'Robot-Arm-05',       tag: 'ns=2;s=M05.State', icon: 'robot' },
  { id: 'M06', name: 'Injection-Mold-06',  tag: 'ns=2;s=M06.State', icon: 'mold' },
  { id: 'M07', name: 'Hydraulic-Press-07', tag: 'ns=2;s=M07.State', icon: 'press' },
  { id: 'M08', name: 'Welding-Robot-08',   tag: 'ns=2;s=M08.State', icon: 'weld' },
  { id: 'M09', name: 'Packaging-Line-09',  tag: 'ns=2;s=M09.State', icon: 'pack' },
  { id: 'M10', name: 'AGV-Transport-10',   tag: 'ns=2;s=M10.State', icon: 'agv' },
];

export const EXTRA_TAGS = [
  { key: 'energy',      label: 'Consumption Energy', unit: 'kWh',  type: 'float',   min: 12,   max: 145 },
  { key: 'temperature', label: 'Temperature',        unit: '°C',   type: 'float',   min: 35,   max: 82  },
  { key: 'speed',       label: 'Speed',              unit: 'rpm',  type: 'int',     min: 800,  max: 3600 },
  { key: 'runtime',     label: 'Runtime Hr',         unit: 'h',    type: 'float',   min: 1240, max: 8760 },
  { key: 'airPressure', label: 'Air Pressure',       unit: 'bar',  type: 'float',   min: 4.5,  max: 8.2 },
  { key: 'lubricant',   label: 'Lubricant Lasttime', unit: '',     type: 'date',    min: 1,    max: 30 },
];

export const STATUS_COLORS = {
  running: '#84a315',
  idle: '#f9a8d4',
  waiting: '#fbbf24',
  alarm: '#dc2626',
  maint: '#60a5fa',
  offline: '#9ca3af',
};

export const STATUS_NAMES = {
  running: 'Running',
  idle: 'Idle',
  waiting: 'Waiting',
  alarm: 'Alarm',
  maint: 'Maintenance',
  offline: 'Offline',
};

export function generateTimeline(seed = 1) {
  const states = ['running','idle','waiting','alarm','maint','offline'];
  const weights = [0.45, 0.20, 0.15, 0.08, 0.07, 0.05];
  const data = [];
  let hour = 0;
  let rng = seed;

  const rand = () => {
    rng = (rng * 9301 + 49297) % 233280;
    return rng / 233280;
  };

  while (hour < 24) {
    let r = rand(), sum = 0, state = 'running';
    for (let i = 0; i < states.length; i++) {
      sum += weights[i];
      if (r < sum) { state = states[i]; break; }
    }
    let dur = Math.max(0.3, Math.min(4, rand() * 3.5 + 0.3));
    if (hour + dur > 24) dur = 24 - hour;
    data.push({ start: hour, duration: dur, status: state });
    hour += dur;
  }
  return data;
}

export function calcStats(timeline) {
  const total = timeline.reduce((s, seg) => s + seg.duration, 0);
  const stats = {};
  for (const seg of timeline) {
    stats[seg.status] = (stats[seg.status] || 0) + seg.duration;
  }
  for (const k in stats) stats[k] = ((stats[k] / total) * 100).toFixed(1);
  return stats;
}

export function generateTagValues(machineId) {
  const seed = machineId.charCodeAt(machineId.length - 1) + machineId.charCodeAt(0);
  const rng = () => {
    const x = Math.sin(seed + Math.random() * 100) * 10000;
    return x - Math.floor(x);
  };

  const values = {};
  for (const tag of EXTRA_TAGS) {
    if (tag.type === 'date') {
      const daysAgo = Math.floor(tag.min + rng() * (tag.max - tag.min));
      const d = new Date();
      d.setDate(d.getDate() - daysAgo);
      values[tag.key] = d.toISOString().split('T')[0];
    } else if (tag.type === 'int') {
      values[tag.key] = Math.floor(tag.min + rng() * (tag.max - tag.min));
    } else {
      const v = tag.min + rng() * (tag.max - tag.min);
      values[tag.key] = Number(v.toFixed(1));
    }
  }
  return values;
}

export function updateTagValues(prevValues, currentStatus) {
  const next = { ...prevValues };
  const rng = () => (Math.random() - 0.5) * 2;

  const energyDelta = {
    running: 0.05 + Math.random() * 0.08,
    idle: 0.005 + Math.random() * 0.01,
    waiting: 0.01 + Math.random() * 0.02,
    alarm: 0.002,
    maint: 0.003,
    offline: 0,
  };
  next.energy = Number((next.energy + (energyDelta[currentStatus] || 0)).toFixed(1));
  if (next.energy > 145) next.energy = 145;

  let tempDir = rng() * 0.08;
  if (currentStatus === 'running') tempDir += 0.03;
  if (currentStatus === 'idle') tempDir -= 0.02;
  next.temperature = Number((next.temperature + tempDir).toFixed(1));
  if (next.temperature > 82) next.temperature = 82;
  if (next.temperature < 35) next.temperature = 35;

  const speedMap = {
    running: () => 1200 + Math.floor(Math.random() * 2400),
    idle: () => 0,
    waiting: () => Math.floor(Math.random() * 150),
    alarm: () => 0,
    maint: () => Math.floor(Math.random() * 50),
    offline: () => 0,
  };
  if (Math.random() < 0.3) {
    next.speed = speedMap[currentStatus]();
  } else if (currentStatus === 'running') {
    next.speed = Math.max(800, Math.min(3600, next.speed + Math.floor(rng() * 100)));
  }

  next.runtime = Number((next.runtime + 1 / 3600).toFixed(1));

  let pressureDir = rng() * 0.015;
  if (currentStatus === 'running') pressureDir += 0.005;
  next.airPressure = Number((next.airPressure + pressureDir).toFixed(2));
  if (next.airPressure > 8.2) next.airPressure = 8.2;
  if (next.airPressure < 4.5) next.airPressure = 4.5;

  return next;
}
