import { useState, useEffect } from 'react';
import { useOPCUA } from './hooks/useOPCUA';
import { AuthProvider, useAuth } from './context/AuthContext';
import Sidebar from './components/Sidebar';
import Overview from './components/Overview';
import MachineDetail from './components/MachineDetail';
import LoginPage from './components/LoginPage';

function LiveClock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);
  const pad = (n) => String(n).padStart(2, '0');
  const dateStr = `${pad(now.getDate())}/${pad(now.getMonth()+1)}/${now.getFullYear()}`;
  const timeStr = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
  return (
    <div className="live-clock">
      <div className="clock-date">{dateStr}</div>
      <div className="clock-time">{timeStr}</div>
    </div>
  );
}

function Dashboard() {
  const machines = useOPCUA();
  const { user, logout } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeView, setActiveView] = useState('overview');

  const activeMachine = machines.find(m => m.id === activeView);

  return (
    <div className="app-layout">
      <Sidebar
        sidebarOpen={sidebarOpen}
        setSidebarOpen={setSidebarOpen}
        activeView={activeView}
        setActiveView={setActiveView}
        machines={machines}
        user={user}
        onLogout={logout}
      />

      <div className="main-content">
        <header className="topbar">
          <div>
            <div className="topbar-title">
              {activeView === 'overview' ? 'Overview' : activeMachine?.name}
            </div>
            <div className="topbar-sub">
              {activeView === 'overview'
                ? 'Real-time machine status monitoring'
                : `OPC UA Tag: ${activeMachine?.tag}`}
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <LiveClock />
            <div className="user-pill">
              <div className="user-avatar">{user?.name?.[0] || 'U'}</div>
              <div className="user-info">
                <span className="user-name">{user?.name}</span>
                <span className="user-role">{user?.role}</span>
              </div>
            </div>
            <div className="live-indicator">
              <div className="live-dot" />
              <span>OPC UA Live</span>
            </div>
          </div>
        </header>

        <div className="page-content">
          {activeView === 'overview' ? (
            <Overview
              machines={machines}
              onSelectMachine={setActiveView}
            />
          ) : activeMachine ? (
            <MachineDetail
              machine={activeMachine}
              onBack={() => setActiveView('overview')}
            />
          ) : null}
        </div>
      </div>
    </div>
  );
}

function AppContent() {
  const { user } = useAuth();
  if (!user) return <LoginPage />;
  return <Dashboard />;
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
