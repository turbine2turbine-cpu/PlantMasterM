import { useState, useEffect } from 'react';
import { MACHINES, generateTagValues, updateTagValues } from '../data/mockOPCUA';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001';
const HOUR = 60 * 60 * 1000;
const DAY = 24 * HOUR;

const STATES = ['running', 'idle', 'waiting', 'alarm', 'maint'];
const STATE_WEIGHTS = [0.50, 0.18, 0.14, 0.10, 0.08];

function pickState() {
  const r = Math.random();
  let sum = 0;
  for (let i = 0; i < STATES.length; i++) {
    sum += STATE_WEIGHTS[i];
    if (r < sum) return STATES[i];
  }
  return 'running';
}

function pickDuration() {
  return Math.floor(5 * 60 * 1000 + Math.random() * 40 * 60 * 1000);
}

function generateHistory(startTime, endTime) {
  const changes = [];
  let t = startTime;
  let state = pickState();
  changes.push({ time: t, status: state });

  while (t < endTime) {
    const dur = pickDuration();
    t += dur;
    if (t >= endTime) break;
    state = pickState();
    changes.push({ time: t, status: state });
  }
  return changes;
}

function computeSegments(stateChanges, now) {
  const windowStart = now - DAY;
  const windowMs = DAY;

  let relevant = [];
  let lastBefore = null;
  for (const c of stateChanges) {
    if (c.time <= windowStart) lastBefore = c;
    else if (c.time <= now) relevant.push(c);
  }

  if (lastBefore) {
    relevant.unshift({ time: windowStart, status: lastBefore.status });
  } else if (relevant.length > 0 && relevant[0].time > windowStart) {
    relevant.unshift({ time: windowStart, status: relevant[0].status });
  }

  const segments = [];
  for (let i = 0; i < relevant.length; i++) {
    const start = relevant[i].time;
    const end = i + 1 < relevant.length ? relevant[i + 1].time : now;
    if (end <= start) continue;
    const left = ((start - windowStart) / windowMs) * 100;
    const width = ((end - start) / windowMs) * 100;
    segments.push({
      status: relevant[i].status,
      left: Math.max(0, left),
      width: Math.min(100, width),
    });
  }
  return segments;
}

function getTimeLabels(now) {
  const labels = [];
  for (let i = 6; i >= 0; i--) {
    const t = new Date(now - i * 4 * HOUR);
    const h = String(t.getHours()).padStart(2, '0');
    const m = String(t.getMinutes()).padStart(2, '0');
    labels.push(`${h}:${m}`);
  }
  return labels;
}

async function writeToInflux(machineId, machineName, status, tags) {
  try {
    await fetch(`${API_URL}/api/write`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ machineId, machineName, status, tags }),
    });
  } catch (err) {
    // Backend not running - data stays in memory only
  }
}

export function useOPCUA() {
  const [machineData, setMachineData] = useState(() => {
    const now = Date.now();
    const startWindow = now - DAY;
    return MACHINES.map((m, i) => {
      const changes = generateHistory(startWindow, now);
      for (let j = 0; j < i * 3; j++) pickState();
      const currentStatus = changes[changes.length - 1].status;
      const nextChangeAt = now + pickDuration();
      const tagValues = generateTagValues(m.id);
      writeToInflux(m.id, m.name, currentStatus, tagValues);
      return {
        ...m,
        stateChanges: changes,
        segments: computeSegments(changes, now),
        labels: getTimeLabels(now),
        currentStatus,
        nextChangeAt,
        tagValues,
      };
    });
  });

  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      setMachineData(prev => prev.map(m => {
        let newChanges = m.stateChanges;
        let newStatus = m.currentStatus;
        let nextAt = m.nextChangeAt;

        if (now >= m.nextChangeAt) {
          newStatus = pickState();
          newChanges = [...m.stateChanges, { time: now, status: newStatus }];
          nextAt = now + pickDuration();
        }

        const cutoff = now - 2 * DAY;
        newChanges = newChanges.filter(c => c.time > cutoff);
        const newTagValues = updateTagValues(m.tagValues, newStatus);
        writeToInflux(m.id, m.name, newStatus, newTagValues);

        return {
          ...m,
          stateChanges: newChanges,
          segments: computeSegments(newChanges, now),
          labels: getTimeLabels(now),
          currentStatus: newStatus,
          nextChangeAt: nextAt,
          tagValues: newTagValues,
        };
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return machineData;
}

export async function fetchMachineHistory(machineId, hours = 24) {
  try {
    const res = await fetch(`${API_URL}/api/history/${machineId}?hours=${hours}`);
    return await res.json();
  } catch { return []; }
}

export async function fetchTagHistory(machineId, field, hours = 24) {
  try {
    const res = await fetch(`${API_URL}/api/history/${machineId}/tag/${field}?hours=${hours}`);
    return await res.json();
  } catch { return []; }
}
