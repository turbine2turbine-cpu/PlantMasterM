import { useState, useEffect } from 'react';
import { fetchTagHistory } from '../hooks/useOPCUA';

export default function HistoryChart({ machineId, field, label, color, unit }) {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    async function load() {
      setLoading(true);
      const rows = await fetchTagHistory(machineId, field, 24);
      if (mounted) {
        setData(rows);
        setLoading(false);
      }
    }
    load();
    const interval = setInterval(load, 30000);
    return () => { mounted = false; clearInterval(interval); };
  }, [machineId, field]);

  if (loading && data.length === 0) {
    return (
      <div style={{ padding: 20, textAlign: 'center', color: '#9ca3af', fontSize: 12 }}>
        Loading history from InfluxDB...
      </div>
    );
  }

  if (data.length === 0) {
    return (
      <div style={{ padding: 20, textAlign: 'center', color: '#9ca3af', fontSize: 12 }}>
        No history data. Start docker-compose to enable InfluxDB.
      </div>
    );
  }

  const values = data.map(d => d.value).filter(v => v != null);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;

  const points = data.map((d, i) => {
    const x = (i / (data.length - 1 || 1)) * 100;
    const y = 100 - ((d.value - min) / range) * 80 - 10;
    return `${x},${y}`;
  }).join(' ');

  return (
    <div style={{ marginBottom: 16 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
        <span style={{ fontSize: 12, fontWeight: 600, color: '#374151' }}>{label}</span>
        <span style={{ fontSize: 11, color: '#9ca3af' }}>Last 24h</span>
      </div>
      <div style={{ background: '#f9fafb', borderRadius: 6, padding: 12, height: 120, position: 'relative' }}>
        <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
          <polyline
            fill="none"
            stroke={color}
            strokeWidth="2"
            points={points}
            vectorEffect="non-scaling-stroke"
          />
          {data.map((d, i) => {
            const x = (i / (data.length - 1 || 1)) * 100;
            const y = 100 - ((d.value - min) / range) * 80 - 10;
            return (
              <circle
                key={i}
                cx={x}
                cy={y}
                r="1.5"
                fill={color}
              />
            );
          })}
        </svg>
        <div style={{ position: 'absolute', bottom: 4, left: 8, fontSize: 10, color: '#9ca3af' }}>
          {min.toFixed(1)}{unit}
        </div>
        <div style={{ position: 'absolute', top: 4, right: 8, fontSize: 10, color: '#9ca3af' }}>
          {max.toFixed(1)}{unit}
        </div>
      </div>
    </div>
  );
}
