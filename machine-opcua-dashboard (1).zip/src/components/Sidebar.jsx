import { STATUS_COLORS } from '../data/mockOPCUA';

const ICONS = {
  overview: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="3" y="3" width="7" height="7" rx="1"/>
      <rect x="14" y="3" width="7" height="7" rx="1"/>
      <rect x="3" y="14" width="7" height="7" rx="1"/>
      <rect x="14" y="14" width="7" height="7" rx="1"/>
    </svg>
  ),
  cnc: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="2" y="8" width="20" height="10" rx="2"/>
      <path d="M6 8V6a2 2 0 012-2h8a2 2 0 012 2v2"/>
      <line x1="4" y1="12" x2="20" y2="12"/>
      <circle cx="8" cy="12" r="1" fill="currentColor"/>
      <circle cx="16" cy="12" r="1" fill="currentColor"/>
    </svg>
  ),
  conv: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="2" y="6" width="20" height="6" rx="1"/>
      <path d="M4 18h16" strokeDasharray="3 2"/>
      <circle cx="7" cy="15" r="1.5" fill="currentColor"/>
      <circle cx="12" cy="15" r="1.5" fill="currentColor"/>
      <circle cx="17" cy="15" r="1.5" fill="currentColor"/>
    </svg>
  ),
  cmm: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M12 2v4"/>
      <rect x="6" y="6" width="12" height="14" rx="2"/>
      <path d="M9 14l3-3 3 3"/>
      <circle cx="12" cy="11" r="1" fill="currentColor"/>
    </svg>
  ),
  robot: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="4" y="4" width="16" height="16" rx="2"/>
      <path d="M4 9h16"/>
      <path d="M9 9v11"/>
      <circle cx="7" cy="6.5" r="1" fill="currentColor"/>
      <circle cx="12" cy="6.5" r="1" fill="currentColor"/>
      <circle cx="17" cy="6.5" r="1" fill="currentColor"/>
    </svg>
  ),
  mold: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="4" y="3" width="16" height="18" rx="2"/>
      <line x1="4" y1="8" x2="20" y2="8"/>
      <line x1="10" y1="12" x2="14" y2="12"/>
      <line x1="10" y1="15" x2="14" y2="15"/>
    </svg>
  ),
  press: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="6" y="2" width="12" height="4" rx="1"/>
      <rect x="8" y="6" width="8" height="8" rx="1"/>
      <rect x="4" y="14" width="16" height="8" rx="1"/>
      <line x1="12" y1="6" x2="12" y2="2"/>
    </svg>
  ),
  weld: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M8 20l4-16 4 16"/>
      <path d="M6 16h12"/>
      <circle cx="12" cy="5" r="2" fill="currentColor"/>
    </svg>
  ),
  pack: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="3" y="8" width="18" height="14" rx="2"/>
      <path d="M3 12h18"/>
      <path d="M12 8V4"/>
      <path d="M8 4h8"/>
    </svg>
  ),
  agv: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="2" y="10" width="20" height="10" rx="2"/>
      <circle cx="7" cy="20" r="2"/>
      <circle cx="17" cy="20" r="2"/>
      <path d="M6 10V6a3 3 0 013-3h6a3 3 0 013 3v4"/>
      <circle cx="12" cy="6" r="1" fill="currentColor"/>
    </svg>
  ),
  logout: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
      <polyline points="16 17 21 12 16 7"/>
      <line x1="21" y1="12" x2="9" y2="12"/>
    </svg>
  ),
  chevronLeft: (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <polyline points="15 18 9 12 15 6"/>
    </svg>
  ),
  chevronRight: (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <polyline points="9 18 15 12 9 6"/>
    </svg>
  ),
};

export default function Sidebar({ sidebarOpen, setSidebarOpen, activeView, setActiveView, machines, user, onLogout }) {
  return (
    <aside className={`sidebar ${sidebarOpen ? 'open' : 'closed'}`}>
      <div className="sidebar-header">
        <div className="sidebar-logo">
          <div className="sidebar-logo-icon">
            {[...Array(9)].map((_, i) => <span key={i} />)}
          </div>
          {sidebarOpen && <span>AI Factory Machine</span>}
        </div>
        <div className="sidebar-toggle" onClick={() => setSidebarOpen(!sidebarOpen)}>
          {sidebarOpen ? ICONS.chevronLeft : ICONS.chevronRight}
        </div>
      </div>

      <div className="sidebar-user" style={{ padding: sidebarOpen ? '16px' : '12px 8px', borderBottom: '1px solid #374151', display: 'flex', alignItems: 'center', gap: 10, transition: 'all 0.3s' }}>
        <div style={{
          width: 36, height: 36, borderRadius: '50%', background: '#84a315',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 14, fontWeight: 700, color: '#fff', flexShrink: 0
        }}>
          {user?.name?.[0] || 'U'}
        </div>
        {sidebarOpen && (
          <div style={{ overflow: 'hidden' }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#fff', whiteSpace: 'nowrap' }}>{user?.name}</div>
            <div style={{ fontSize: 11, color: '#9ca3af', whiteSpace: 'nowrap' }}>{user?.role}</div>
          </div>
        )}
      </div>

      <nav className="sidebar-nav">
        <div className="nav-section-label">Dashboard</div>
        <div
          className={`nav-item ${activeView === 'overview' ? 'active' : ''}`}
          onClick={() => setActiveView('overview')}
        >
          <div className="nav-icon">{ICONS.overview}</div>
          <span className="nav-text">Overview</span>
        </div>

        <div className="nav-section-label" style={{ marginTop: 8 }}>Machines</div>
        {machines.map(m => (
          <div
            key={m.id}
            className={`nav-item ${activeView === m.id ? 'active' : ''}`}
            onClick={() => setActiveView(m.id)}
          >
            <div className="nav-icon">{ICONS[m.icon] || ICONS.cnc}</div>
            <span className="nav-text">{m.name}</span>
            <span
              className="nav-text"
              style={{
                marginLeft: 'auto',
                width: 8, height: 8, borderRadius: '50%',
                background: STATUS_COLORS[m.currentStatus],
                flexShrink: 0
              }}
            />
          </div>
        ))}
      </nav>

      <div style={{ flex: 1 }} />

      <div className="sidebar-company" style={{ padding: '12px 16px', borderTop: '1px solid #374151', textAlign: 'center' }}>
        {sidebarOpen ? (
          <div style={{ fontSize: 10, color: '#6b7280', lineHeight: 1.5 }}>
            <div style={{ fontWeight: 600, color: '#9ca3af', marginBottom: 2 }}>Developed by</div>
            <div>AI-Tech Automation</div>
            <div>Co., Ltd.</div>
          </div>
        ) : (
          <div style={{ fontSize: 8, color: '#6b7280', writingMode: 'vertical-rl', letterSpacing: 2, margin: '0 auto' }}>
            AI-TECH
          </div>
        )}
      </div>

      <div
        className="nav-item"
        onClick={onLogout}
        style={{ margin: '8px', color: '#ef4444' }}
      >
        <div className="nav-icon">{ICONS.logout}</div>
        <span className="nav-text">Logout</span>
      </div>

      <div className="sidebar-footer">
        {sidebarOpen ? 'OPC UA v1.04' : 'UA'}
      </div>
    </aside>
  );
}
