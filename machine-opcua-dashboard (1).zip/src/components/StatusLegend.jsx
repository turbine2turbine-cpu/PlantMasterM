import { STATUS_COLORS, STATUS_NAMES } from '../data/mockOPCUA';

const ITEMS = [
  { key: 'running', tag: 'ns=2;s=Machine.State.Running' },
  { key: 'idle',    tag: 'ns=2;s=Machine.State.Idle' },
  { key: 'waiting', tag: 'ns=2;s=Machine.State.Waiting' },
  { key: 'alarm',   tag: 'ns=2;s=Machine.State.Alarm' },
  { key: 'maint',   tag: 'ns=2;s=Machine.State.Maint' },
  { key: 'offline', tag: 'No Tag / Disconnected' },
];

export default function StatusLegend() {
  return (
    <div className="legend">
      {ITEMS.map(item => (
        <div key={item.key} className="legend-item">
          <div className="legend-dot" style={{ background: STATUS_COLORS[item.key] }} />
          <span>{STATUS_NAMES[item.key]} ({item.tag})</span>
        </div>
      ))}
    </div>
  );
}
