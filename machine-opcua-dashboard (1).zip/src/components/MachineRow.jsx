import { useState } from 'react';
import { STATUS_COLORS, STATUS_NAMES } from '../data/mockOPCUA';

const ICONS = {
  cnc: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="2" y="8" width="20" height="10" rx="2"/>
      <path d="M6 8V6a2 2 0 012-2h8a2 2 0 012 2v2"/>
      <line x1="4" y1="12" x2="20" y2="12"/>
      <circle cx="8" cy="12" r="1" fill="currentColor"/>
      <circle cx="16" cy="12" r="1" fill="currentColor"/>
    </svg>
  ),
  conv: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="2" y="6" width="20" height="6" rx="1"/>
      <path d="M4 18h16" strokeDasharray="3 2"/>
      <circle cx="7" cy="15" r="1.5" fill="currentColor"/>
      <circle cx="12" cy="15" r="1.5" fill="currentColor"/>
      <circle cx="17" cy="15" r="1.5" fill="currentColor"/>
    </svg>
  ),
  cmm: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M12 2v4"/>
      <rect x="6" y="6" width="12" height="14" rx="2"/>
      <path d="M9 14l3-3 3 3"/>
      <circle cx="12" cy="11" r="1" fill="currentColor"/>
    </svg>
  ),
  robot: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="4" y="4" width="16" height="16" rx="2"/>
      <path d="M4 9h16"/>
      <path d="M9 9v11"/>
      <circle cx="7" cy="6.5" r="1" fill="currentColor"/>
      <circle cx="12" cy="6.5" r="1" fill="currentColor"/>
      <circle cx="17" cy="6.5" r="1" fill="currentColor"/>
    </svg>
  ),
  mold: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="4" y="3" width="16" height="18" rx="2"/>
      <line x1="4" y1="8" x2="20" y2="8"/>
      <line x1="10" y1="12" x2="14" y2="12"/>
      <line x1="10" y1="15" x2="14" y2="15"/>
    </svg>
  ),
  press: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="6" y="2" width="12" height="4" rx="1"/>
      <rect x="8" y="6" width="8" height="8" rx="1"/>
      <rect x="4" y="14" width="16" height="8" rx="1"/>
      <line x1="12" y1="6" x2="12" y2="2"/>
    </svg>
  ),
  weld: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M8 20l4-16 4 16"/>
      <path d="M6 16h12"/>
      <circle cx="12" cy="5" r="2" fill="currentColor"/>
    </svg>
  ),
  pack: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="3" y="8" width="18" height="14" rx="2"/>
      <path d="M3 12h18"/>
      <path d="M12 8V4"/>
      <path d="M8 4h8"/>
    </svg>
  ),
  agv: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="2" y="10" width="20" height="10" rx="2"/>
      <circle cx="7" cy="20" r="2"/>
      <circle cx="17" cy="20" r="2"/>
      <path d="M6 10V6a3 3 0 013-3h6a3 3 0 013 3v4"/>
      <circle cx="12" cy="6" r="1" fill="currentColor"/>
    </svg>
  ),
};

function formatDuration(ms) {
  const m = Math.floor(ms / 60000);
  const h = Math.floor(m / 60);
  const min = m % 60;
  if (h > 0) return `${h}h ${min}m`;
  return `${min}m`;
}

function findContiguousGroup(segments, hoveredIdx) {
  if (!segments || hoveredIdx < 0 || hoveredIdx >= segments.length) return null;
  const status = segments[hoveredIdx].status;
  let startIdx = hoveredIdx;
  let endIdx = hoveredIdx;
  // walk backward
  while (startIdx > 0 && segments[startIdx - 1].status === status) startIdx--;
  // walk forward
  while (endIdx < segments.length - 1 && segments[endIdx + 1].status === status) endIdx++;
  const totalWidth = segments.slice(startIdx, endIdx + 1).reduce((s, seg) => s + seg.width, 0);
  return {
    status,
    startIdx,
    endIdx,
    left: segments[startIdx].left,
    width: totalWidth,
  };
}

function SegmentTooltip({ group, windowStart }) {
  if (!group) return null;
  const segStartMs = windowStart + (group.left / 100) * 24 * 60 * 60 * 1000;
  const segEndMs = segStartMs + (group.width / 100) * 24 * 60 * 60 * 1000;
  const durMs = segEndMs - segStartMs;
  const startTime = new Date(segStartMs);
  const endTime = new Date(segEndMs);
  const fmt = (d) => `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;

  return (
    <div className="segment-tooltip">
      <div className="tooltip-header">
        <span className="tooltip-dot" style={{ background: STATUS_COLORS[group.status] }} />
        <span className="tooltip-state">{STATUS_NAMES[group.status]}</span>
      </div>
      <div className="tooltip-time">
        {fmt(startTime)} – {fmt(endTime)}
      </div>
      <div className="tooltip-dur">Duration: {formatDuration(durMs)}</div>
    </div>
  );
}

export default function MachineRow({ machine, onClick }) {
  const [hoveredIdx, setHoveredIdx] = useState(null);
  const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });
  const now = Date.now();
  const windowStart = now - 24 * 60 * 60 * 1000;

  const group = hoveredIdx !== null ? findContiguousGroup(machine.segments, hoveredIdx) : null;

  const handleMouseMove = (e) => {
    setTooltipPos({ x: e.clientX, y: e.clientY });
  };

  return (
    <div className="machine-row" onClick={onClick}>
      <div className="machine-icon">{ICONS[machine.icon] || ICONS.cnc}</div>
      <div className="machine-info">
        <div className="machine-name">{machine.name}</div>
        <div className="machine-tag">{machine.tag}</div>
      </div>
      <div className="timeline-wrap">
        <div className="timeline-bar" style={{ position: 'relative' }}>
          {machine.segments.map((seg, idx) => (
            <div
              key={idx}
              className="time-segment"
              style={{
                position: 'absolute',
                left: `${seg.left}%`,
                width: `${seg.width}%`,
                background: STATUS_COLORS[seg.status],
                height: '100%',
                cursor: 'pointer',
              }}
              onMouseEnter={() => setHoveredIdx(idx)}
              onMouseLeave={() => setHoveredIdx(null)}
              onMouseMove={handleMouseMove}
            />
          ))}
        </div>
        <div className="time-labels">
          {machine.labels.map((lbl, i) => (
            <span key={i}>{lbl}</span>
          ))}
        </div>
      </div>
      <div className="arrow-btn">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <polyline points="9 18 15 12 9 6"/>
        </svg>
      </div>

      {group && (
        <div
          className="floating-tooltip"
          style={{
            position: 'fixed',
            left: tooltipPos.x + 14,
            top: tooltipPos.y - 90,
            zIndex: 2147483647,
            pointerEvents: 'none',
          }}
        >
          <SegmentTooltip group={group} windowStart={windowStart} />
        </div>
      )}
    </div>
  );
}
