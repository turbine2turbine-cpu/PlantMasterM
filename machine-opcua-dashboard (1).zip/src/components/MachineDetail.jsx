import { useState } from 'react';
import HistoryChart from './HistoryChart';
import { STATUS_COLORS, STATUS_NAMES, calcStats, EXTRA_TAGS } from '../data/mockOPCUA';
import DonutChart from './DonutChart';

const ICONS = {
  cnc: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="2" y="8" width="20" height="10" rx="2"/>
      <path d="M6 8V6a2 2 0 012-2h8a2 2 0 012 2v2"/>
      <line x1="4" y1="12" x2="20" y2="12"/>
      <circle cx="8" cy="12" r="1" fill="currentColor"/>
      <circle cx="16" cy="12" r="1" fill="currentColor"/>
    </svg>
  ),
  conv: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="2" y="6" width="20" height="6" rx="1"/>
      <path d="M4 18h16" strokeDasharray="3 2"/>
      <circle cx="7" cy="15" r="1.5" fill="currentColor"/>
      <circle cx="12" cy="15" r="1.5" fill="currentColor"/>
      <circle cx="17" cy="15" r="1.5" fill="currentColor"/>
    </svg>
  ),
  cmm: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M12 2v4"/>
      <rect x="6" y="6" width="12" height="14" rx="2"/>
      <path d="M9 14l3-3 3 3"/>
      <circle cx="12" cy="11" r="1" fill="currentColor"/>
    </svg>
  ),
  robot: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="4" y="4" width="16" height="16" rx="2"/>
      <path d="M4 9h16"/>
      <path d="M9 9v11"/>
      <circle cx="7" cy="6.5" r="1" fill="currentColor"/>
      <circle cx="12" cy="6.5" r="1" fill="currentColor"/>
      <circle cx="17" cy="6.5" r="1" fill="currentColor"/>
    </svg>
  ),
  mold: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="4" y="3" width="16" height="18" rx="2"/>
      <line x1="4" y1="8" x2="20" y2="8"/>
      <line x1="10" y1="12" x2="14" y2="12"/>
      <line x1="10" y1="15" x2="14" y2="15"/>
    </svg>
  ),
  press: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="6" y="2" width="12" height="4" rx="1"/>
      <rect x="8" y="6" width="8" height="8" rx="1"/>
      <rect x="4" y="14" width="16" height="8" rx="1"/>
      <line x1="12" y1="6" x2="12" y2="2"/>
    </svg>
  ),
  weld: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M8 20l4-16 4 16"/>
      <path d="M6 16h12"/>
      <circle cx="12" cy="5" r="2" fill="currentColor"/>
    </svg>
  ),
  pack: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="3" y="8" width="18" height="14" rx="2"/>
      <path d="M3 12h18"/>
      <path d="M12 8V4"/>
      <path d="M8 4h8"/>
    </svg>
  ),
  agv: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="2" y="10" width="20" height="10" rx="2"/>
      <circle cx="7" cy="20" r="2"/>
      <circle cx="17" cy="20" r="2"/>
      <path d="M6 10V6a3 3 0 013-3h6a3 3 0 013 3v4"/>
      <circle cx="12" cy="6" r="1" fill="currentColor"/>
    </svg>
  ),
  back: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <polyline points="15 18 9 12 15 6"/>
    </svg>
  ),
};

function formatDuration(ms) {
  const m = Math.floor(ms / 60000);
  const h = Math.floor(m / 60);
  const min = m % 60;
  if (h > 0) return `${h}h ${min}m`;
  return `${min}m`;
}

function findContiguousGroup(segments, hoveredIdx) {
  if (!segments || hoveredIdx < 0 || hoveredIdx >= segments.length) return null;
  const status = segments[hoveredIdx].status;
  let startIdx = hoveredIdx;
  let endIdx = hoveredIdx;
  while (startIdx > 0 && segments[startIdx - 1].status === status) startIdx--;
  while (endIdx < segments.length - 1 && segments[endIdx + 1].status === status) endIdx++;
  const totalWidth = segments.slice(startIdx, endIdx + 1).reduce((s, seg) => s + seg.width, 0);
  return {
    status,
    startIdx,
    endIdx,
    left: segments[startIdx].left,
    width: totalWidth,
  };
}

function SegmentTooltip({ group, windowStart }) {
  if (!group) return null;
  const segStartMs = windowStart + (group.left / 100) * 24 * 60 * 60 * 1000;
  const segEndMs = segStartMs + (group.width / 100) * 24 * 60 * 60 * 1000;
  const durMs = segEndMs - segStartMs;
  const startTime = new Date(segStartMs);
  const endTime = new Date(segEndMs);
  const fmt = (d) => `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;

  return (
    <div className="segment-tooltip">
      <div className="tooltip-header">
        <span className="tooltip-dot" style={{ background: STATUS_COLORS[group.status] }} />
        <span className="tooltip-state">{STATUS_NAMES[group.status]}</span>
      </div>
      <div className="tooltip-time">
        {fmt(startTime)} – {fmt(endTime)}
      </div>
      <div className="tooltip-dur">Duration: {formatDuration(durMs)}</div>
    </div>
  );
}

export default function MachineDetail({ machine, onBack }) {
  const [hoveredIdx, setHoveredIdx] = useState(null);
  const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });
  const stats = calcStats(machine.timeline || machine.segments.map(s => ({
    duration: s.width / 100 * 24,
    status: s.status
  })));
  const statusColor = STATUS_COLORS[machine.currentStatus];
  const now = Date.now();
  const windowStart = now - 24 * 60 * 60 * 1000;

  const group = hoveredIdx !== null ? findContiguousGroup(machine.segments, hoveredIdx) : null;

  const handleMouseMove = (e) => {
    setTooltipPos({ x: e.clientX, y: e.clientY });
  };

  return (
    <>
      <div className="detail-header">
        <button className="back-btn" onClick={onBack}>
          {ICONS.back} Back to Overview
        </button>
      </div>

      <div className="detail-grid">
        {/* LEFT COLUMN */}
        <div>
          {/* Timeline Card */}
          <div className="detail-card" style={{ marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 16 }}>
              <div style={{ width: 48, height: 48, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#6b7280' }}>
                {ICONS[machine.icon] || ICONS.cnc}
              </div>
              <div>
                <h2 style={{ fontSize: 20, fontWeight: 700, color: '#111827' }}>{machine.name}</h2>
                <code style={{ fontSize: 12, color: '#9ca3af' }}>{machine.tag}</code>
              </div>
              <div style={{ marginLeft: 'auto' }}>
                <span
                  className="detail-status-badge"
                  style={{ background: statusColor + '20', color: statusColor }}
                >
                  <span style={{ width: 8, height: 8, borderRadius: '50%', background: statusColor }} />
                  {STATUS_NAMES[machine.currentStatus]}
                </span>
              </div>
            </div>

            <h3>24-Hour Timeline (Right = Now)</h3>
            <div className="timeline-bar" style={{ height: 56, borderRadius: 6, position: 'relative' }}>
              {machine.segments.map((seg, idx) => (
                <div
                  key={idx}
                  className="time-segment"
                  style={{
                    position: 'absolute',
                    left: `${seg.left}%`,
                    width: `${seg.width}%`,
                    background: STATUS_COLORS[seg.status],
                    height: '100%',
                    cursor: 'pointer',
                  }}
                  onMouseEnter={() => setHoveredIdx(idx)}
                  onMouseLeave={() => setHoveredIdx(null)}
                  onMouseMove={handleMouseMove}
                />
              ))}
            </div>
            <div className="time-labels">
              {machine.labels.map((lbl, i) => (
                <span key={i}>{lbl}</span>
              ))}
            </div>
          </div>

          {/* Status Breakdown */}
          <div className="detail-card" style={{ marginBottom: 16 }}>
            <h3>Status Breakdown (Last 24h)</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {Object.entries(stats).map(([status, pct]) => (
                <div key={status} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ width: 12, height: 12, borderRadius: 2, background: STATUS_COLORS[status], flexShrink: 0 }} />
                  <span style={{ width: 100, fontSize: 13, fontWeight: 500, color: '#374151' }}>{STATUS_NAMES[status]}</span>
                  <div style={{ flex: 1, height: 8, background: '#f3f4f6', borderRadius: 4, overflow: 'hidden' }}>
                    <div style={{ width: `${pct}%`, height: '100%', background: STATUS_COLORS[status], borderRadius: 4 }} />
                  </div>
                  <span style={{ width: 50, fontSize: 13, fontWeight: 600, color: '#111827', textAlign: 'right' }}>{pct}%</span>
                </div>
              ))}
            </div>
          </div>

          {/* OPC UA Tags TABLE — moved to left column, empty space */}
          <div className="detail-card">
            <h3>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/>
                <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>
              </svg>
              OPC UA Tags
            </h3>
            <table className="opcua-table">
              <thead>
                <tr>
                  <th>Tag Name</th>
                  <th>Node ID</th>
                  <th style={{ textAlign: 'right' }}>Value</th>
                  <th style={{ textAlign: 'center' }}>Unit</th>
                </tr>
              </thead>
              <tbody>
                {EXTRA_TAGS.map((tag, idx) => (
                  <tr key={tag.key} className={idx % 2 === 0 ? 'even' : 'odd'}>
                    <td>
                      <div className="tag-name-cell">
                        <span className="tag-dot" style={{ background: STATUS_COLORS[['running','idle','waiting','alarm','maint','offline'][idx % 6]] }} />
                        {tag.label}
                      </div>
                    </td>
                    <td>
                      <code className="tag-node">{machine.tag}.{tag.key}</code>
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      <span className="tag-value">{machine.tagValues?.[tag.key] ?? '--'}</span>
                    </td>
                    <td style={{ textAlign: 'center' }}>
                      <span className="tag-unit">{tag.unit}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* RIGHT COLUMN */}
        <div>
          <div className="detail-card" style={{ marginBottom: 16 }}>
            <h3>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 20V10"/><path d="M18 20V4"/><path d="M6 20v-4"/>
              </svg>
              Key Metrics
            </h3>
            <div className="donut-grid">
              <DonutChart value={84.2} label="OEE" color="#84a315" />
              <DonutChart value={91.5} label="Availability" color="#60a5fa" />
              <DonutChart value={92.0} label="Performance" color="#fbbf24" />
              <DonutChart value={99.8} label="Quality" color="#84a315" />
            </div>
          </div>

          <div className="detail-card" style={{ marginBottom: 16 }}>
            <h3>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 20V10"/><path d="M18 20V4"/><path d="M6 20v-4"/>
              </svg>
              History (InfluxDB)
            </h3>
            <HistoryChart machineId={machine.id} field="energy" label="Energy" color="#84a315" unit=" kWh" />
            <HistoryChart machineId={machine.id} field="temperature" label="Temperature" color="#dc2626" unit="°C" />
            <HistoryChart machineId={machine.id} field="speed" label="Speed" color="#60a5fa" unit=" rpm" />
            <HistoryChart machineId={machine.id} field="air_pressure" label="Air Pressure" color="#fbbf24" unit=" bar" />
          </div>

          <div className="detail-card">
            <h3>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="4" y="4" width="16" height="16" rx="2"/>
                <path d="M4 9h16"/>
                <path d="M9 9v11"/>
              </svg>
              Tag Browser
            </h3>
            <div className="tag-list">
              <div className="tag-row"><code>{machine.tag}</code><span className="tag-val">State</span></div>
              <div className="tag-row"><code>{machine.tag}.Running</code><span className="tag-val">Bool</span></div>
              <div className="tag-row"><code>{machine.tag}.Alarm</code><span className="tag-val">Bool</span></div>
              <div className="tag-row"><code>{machine.tag}.CycleTime</code><span className="tag-val">Float</span></div>
              <div className="tag-row"><code>{machine.tag}.PartCount</code><span className="tag-val">Int32</span></div>
            </div>
          </div>
        </div>
      </div>

      {group && (
        <div
          className="floating-tooltip"
          style={{
            position: 'fixed',
            left: tooltipPos.x + 14,
            top: tooltipPos.y - 90,
            zIndex: 2147483647,
            pointerEvents: 'none',
          }}
        >
          <SegmentTooltip group={group} windowStart={windowStart} />
        </div>
      )}
    </>
  );
}
