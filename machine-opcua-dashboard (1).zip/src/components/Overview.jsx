import MachineRow from './MachineRow';
import StatusLegend from './StatusLegend';
import DonutChart from './DonutChart';
import { STATUS_COLORS } from '../data/mockOPCUA';

export default function Overview({ machines, onSelectMachine }) {
  const runningCount = machines.filter(m => m.currentStatus === 'running').length;
  const alarmCount = machines.filter(m => m.currentStatus === 'alarm').length;

  // Calculate actual uptime from all machines' segments
  let totalRunning = 0;
  let totalAll = 0;
  machines.forEach(m => {
    m.segments.forEach(seg => {
      if (seg.status === 'running') totalRunning += seg.width;
      totalAll += seg.width;
    });
  });
  const uptimePct = totalAll > 0 ? Number((totalRunning / totalAll * 100).toFixed(1)) : 87.4;

  return (
    <>
      <div className="opcua-info">
        <strong>OPC UA Server:</strong> <code>opc.tcp://factory-server:4840</code> &nbsp;|&nbsp;
        <strong>Namespace:</strong> <code>urn:Factory:Machines</code> &nbsp;|&nbsp;
        <strong>Update Rate:</strong> <code>1 000 ms</code> &nbsp;|&nbsp;
        <strong>Window:</strong> <code>Last 24 Hours</code>
      </div>

      <div className="summary-cards">
        <div className="summary-card">
          <h4>Total Machines</h4>
          <div className="value">{machines.length}</div>
          <div className="sub">All connected</div>
        </div>
        <div className="summary-card">
          <h4>Running</h4>
          <div className="value" style={{ color: STATUS_COLORS.running }}>{runningCount}</div>
          <div className="sub">Active production</div>
        </div>
        <div className="summary-card">
          <h4>Alarm</h4>
          <div className="value" style={{ color: STATUS_COLORS.alarm }}>{alarmCount}</div>
          <div className="sub">Needs attention</div>
        </div>
        <div className="summary-card summary-donut">
          <DonutChart value={uptimePct} label="Uptime Today" color="#84a315" size={90} stroke={8} />
          <div className="sub">Plant average</div>
        </div>
      </div>

      {machines.map(machine => (
        <MachineRow
          key={machine.id}
          machine={machine}
          onClick={() => onSelectMachine(machine.id)}
        />
      ))}

      <StatusLegend />
    </>
  );
}
