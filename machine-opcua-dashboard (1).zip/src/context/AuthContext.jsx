import { createContext, useContext, useState } from 'react';

const AuthContext = createContext(null);

const MOCK_USERS = [
  { username: 'admin', password: 'admin', name: 'Administrator', role: 'Admin' },
  { username: 'operator', password: 'operator', name: 'Operator', role: 'Operator' },
  { username: 'viewer', password: 'viewer', name: 'Viewer', role: 'Viewer' },
];

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('opcua_user');
    return saved ? JSON.parse(saved) : null;
  });

  const login = (username, password) => {
    const found = MOCK_USERS.find(
      u => u.username === username && u.password === password
    );
    if (found) {
      const userData = { name: found.name, role: found.role, username: found.username };
      setUser(userData);
      localStorage.setItem('opcua_user', JSON.stringify(userData));
      return { success: true };
    }
    return { success: false, error: 'Invalid username or password' };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('opcua_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
