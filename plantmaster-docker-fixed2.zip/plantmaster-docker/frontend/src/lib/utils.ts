import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleString('th-TH', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function statusColor(status: string): string {
  switch (status) {
    case 'SUCCESS': return 'bg-green-100 text-green-800';
    case 'FAILED': return 'bg-red-100 text-red-800';
    case 'PENDING': return 'bg-amber-100 text-amber-800';
    default: return 'bg-stone-100 text-stone-800';
  }
}

export function severityColor(severity: number): string {
  switch (severity) {
    case 4: return 'bg-red-600 text-white';
    case 3: return 'bg-orange-500 text-white';
    case 2: return 'bg-yellow-500 text-white';
    default: return 'bg-amber-500 text-white';
  }
}
