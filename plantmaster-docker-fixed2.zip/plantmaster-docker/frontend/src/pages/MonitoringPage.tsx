import TagTrendChart from '@/components/monitoring/TagTrendChart';
import AlarmList from '@/components/monitoring/AlarmList';

export default function MonitoringPage() {
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-stone-800">Roasting Monitoring</h2>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <TagTrendChart />
        <AlarmList />
      </div>
    </div>
  );
}
