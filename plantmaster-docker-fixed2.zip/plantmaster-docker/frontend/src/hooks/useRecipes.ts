import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { recipeApi } from '@/services/api';
import type { Recipe, RecipeCreate, RecipeUpdate } from '@/types';

export function useRecipes(productId?: string) {
  return useQuery({
    queryKey: ['recipes', productId],
    queryFn: () => recipeApi.list(productId),
  });
}

export function useRecipe(id: string) {
  return useQuery({
    queryKey: ['recipe', id],
    queryFn: () => recipeApi.get(id),
    enabled: !!id,
  });
}

export function useCreateRecipe() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: recipeApi.create,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['recipes'] }),
  });
}

export function useUpdateRecipe() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: RecipeUpdate }) => recipeApi.update(id, data),
    onSuccess: (_, vars) => {
      qc.invalidateQueries({ queryKey: ['recipes'] });
      qc.invalidateQueries({ queryKey: ['recipe', vars.id] });
    },
  });
}

export function useDeleteRecipe() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: recipeApi.delete,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['recipes'] }),
  });
}

export function useValidateRecipe(id: string) {
  return useQuery({
    queryKey: ['validate', id],
    queryFn: () => recipeApi.validate(id),
    enabled: !!id,
  });
}

export function useCompareRecipe(recipeId: string, plcId: string) {
  return useQuery({
    queryKey: ['compare', recipeId, plcId],
    queryFn: () => recipeApi.compare(recipeId, plcId),
    enabled: !!recipeId && !!plcId,
  });
}

export function useCloneRecipe() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, newCode, newName }: { id: string; newCode: string; newName: string }) =>
      recipeApi.clone(id, newCode, newName),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['recipes'] }),
  });
}
