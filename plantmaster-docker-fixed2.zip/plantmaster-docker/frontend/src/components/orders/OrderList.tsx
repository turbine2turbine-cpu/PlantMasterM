import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useOrders, useUpdateOrder } from '@/hooks/useOrders';
import Button from '@/components/ui/Button';
import { Plus, Play, CheckCircle, FileText, Loader2, AlertCircle } from 'lucide-react';
import { formatDate } from '@/lib/utils';

const statusColors: Record<string, string> = {
  pending: 'bg-amber-100 text-amber-800',
  running: 'bg-orange-100 text-orange-800',
  completed: 'bg-green-100 text-green-800',
  cancelled: 'bg-stone-100 text-stone-800',
};

export default function OrderList() {
  const navigate = useNavigate();
  const { data: orders, isLoading, error } = useOrders();
  const updateMutation = useUpdateOrder();
  const [filter, setFilter] = useState('all');

  const filtered = filter === 'all' ? orders : orders?.filter((o: any) => o.status === filter);
  const runningPlcs = new Set(orders?.filter((o: any) => o.status === 'running').map((o: any) => o.plc_id) || []);

  if (isLoading) return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="w-8 h-8 animate-spin text-amber-600" />
      <span className="ml-3 text-stone-600">Loading roasting batches...</span>
    </div>
  );

  if (error) return (
    <div className="text-center py-20">
      <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
      <h2 className="text-xl font-bold text-red-700 mb-2">Failed to load batches</h2>
      <p className="text-stone-500 mb-4">{(error as any)?.message || 'Please check your connection and try again.'}</p>
      <Button onClick={() => window.location.reload()}>Retry</Button>
    </div>
  );

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-stone-800">Roasting Batches</h2>
        <Button onClick={() => navigate('/orders/new')}>
          <Plus className="w-4 h-4 mr-2" /> New Batch
        </Button>
      </div>

      <div className="flex gap-2 items-center flex-wrap">
        {['all', 'pending', 'running', 'completed', 'cancelled'].map((s) => {
          const count = s === 'all' ? (orders?.length ?? 0) : (orders?.filter((o: any) => o.status === s).length ?? 0);
          return (
            <button key={s} onClick={() => setFilter(s)}
              className={"px-3 py-1 rounded-full text-sm font-medium capitalize transition-colors " +
                (filter === s ? "bg-amber-900 text-white" : "bg-stone-100 text-stone-600 hover:bg-stone-200")}>
              {s} <span className="ml-1 opacity-70">({count})</span>
            </button>
          );
        })}
      </div>

      <div className="bg-white rounded-xl border border-stone-200 shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-stone-50 border-b border-stone-200">
            <tr>
              <th className="px-4 py-3 text-left font-medium text-stone-600">Batch No.</th>
              <th className="px-4 py-3 text-left font-medium text-stone-600">Profile</th>
              <th className="px-4 py-3 text-left font-medium text-stone-600">Roaster</th>
              <th className="px-4 py-3 text-left font-medium text-stone-600">Weight (kg)</th>
              <th className="px-4 py-3 text-left font-medium text-stone-600">Status</th>
              <th className="px-4 py-3 text-left font-medium text-stone-600">Created</th>
              <th className="px-4 py-3 text-right font-medium text-stone-600">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100">
            {filtered?.map((order: any) => (
              <tr key={order.id} className="hover:bg-stone-50">
                <td className="px-4 py-3 font-mono font-semibold text-amber-700">{order.po_number}</td>
                <td className="px-4 py-3">{order.recipe_code} - {order.recipe_name}</td>
                <td className="px-4 py-3 font-mono text-xs">{order.plc_id}</td>
                <td className="px-4 py-3">{order.quantity}</td>
                <td className="px-4 py-3">
                  <span className={"px-2 py-0.5 rounded-full text-xs font-medium " + (statusColors[order.status] || 'bg-stone-100')}>
                    {order.status}
                  </span>
                </td>
                <td className="px-4 py-3 text-stone-500">{formatDate(order.created_at)}</td>
                <td className="px-4 py-3 text-right">
                  <div className="flex justify-end gap-2">
                    {order.status === 'pending' && (
                      <Button size="sm" variant="outline" onClick={() => navigate(`/orders/${order.id}`)} disabled={runningPlcs.has(order.plc_id)} title={runningPlcs.has(order.plc_id) ? 'Roaster busy' : 'Start roast'}>
                        <Play className="w-3 h-3 mr-1" /> {runningPlcs.has(order.plc_id) ? 'Busy' : 'Start'}
                      </Button>
                    )}
                    {order.status === 'running' && (
                      <Button size="sm" variant="outline" onClick={() => updateMutation.mutate({ id: order.id, data: { status: 'completed' } })}>
                        <CheckCircle className="w-3 h-3 mr-1" /> Complete
                      </Button>
                    )}
                    <Button size="sm" variant="ghost" onClick={() => navigate(`/orders/${order.id}`)}>
                      <FileText className="w-4 h-4" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {(!filtered || filtered.length === 0) && (
          <div className="text-center py-12 text-stone-500">
            <p className="text-lg mb-2">📭 No batches found</p>
            <p className="text-sm">Create a new batch to get started.</p>
          </div>
        )}
      </div>
    </div>
  );
}
