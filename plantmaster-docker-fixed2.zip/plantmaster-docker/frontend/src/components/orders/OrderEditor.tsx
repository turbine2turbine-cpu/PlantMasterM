import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useOrders, useOrder, useCreateOrder, useDownloadOrder } from '@/hooks/useOrders';
import { useRecipes } from '@/hooks/useRecipes';
import { useDownloadStatus } from '@/hooks/usePlc';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import Alert from '@/components/ui/Alert';
import { Save, Download, ArrowLeft, Clock, Loader2 } from 'lucide-react';
import { formatDate, statusColor } from '@/lib/utils';
import type { DownloadStatus } from '@/types';

const ROASTER_OPTIONS = [
  { id: 'LINE_A_PLC', name: 'Roaster A' },
  { id: 'LINE_B_PLC', name: 'Roaster B' },
  { id: 'LINE_C_PLC', name: 'Roaster C' },
];

export default function OrderEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isNew = !id;
  const { data: existing, isLoading: isLoadingOrder, error: orderError } = useOrder(id || '');
  const { data: recipes, isLoading: isLoadingRecipes, error: recipesError } = useRecipes();
  const { data: allOrders } = useOrders();
  const createMutation = useCreateOrder();
  const downloadMutation = useDownloadOrder();
  const [txId, setTxId] = useState('');
  const { data: downloadStatus } = useDownloadStatus(txId);

  const runningPlcs = new Set(allOrders?.filter((o: any) => o.status === 'running').map((o: any) => o.plc_id) || []);

  const [poNumber, setPoNumber] = useState('');
  const [recipeId, setRecipeId] = useState('');
  const [plcId, setPlcId] = useState('LINE_A_PLC');
  const [quantity, setQuantity] = useState(1);
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  // Generate batch number on mount for new orders
  useEffect(() => {
    if (isNew && !poNumber) {
      const year = new Date().getFullYear();
      const random = Math.floor(Math.random() * 900) + 100;
      setPoNumber(`BTH-${year}-${random}`);
    }
  }, [isNew]);

  useEffect(() => {
    if (existing) {
      setPoNumber(existing.po_number || '');
      setRecipeId(existing.recipe_id || '');
      setPlcId(existing.plc_id || 'LINE_A_PLC');
      setQuantity(existing.quantity || 1);
      setNotes(existing.notes || '');
    }
  }, [existing]);

  const validate = (): boolean => {
    const errors: Record<string, string> = {};
    if (!poNumber.trim()) errors.poNumber = 'Batch number is required';
    if (!recipeId) errors.recipeId = 'Please select a roasting profile';
    if (!plcId) errors.plcId = 'Please select a target roaster';
    if (!quantity || quantity <= 0) errors.quantity = 'Weight must be greater than 0';
    
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!validate()) return;

    try {
      await createMutation.mutateAsync({
        po_number: poNumber,
        recipe_id: recipeId,
        plc_id: plcId,
        quantity,
        notes,
      });
      // Success - navigate to orders list
      navigate('/orders', { replace: true });
    } catch (e: any) {
      console.error('Create batch error:', e);
      const message = e?.response?.data?.detail || e?.message || 'Failed to create batch. Please try again.';
      setError(message);
    }
  };

  const handleDownload = async () => {
    if (!id) return;
    setError('');
    try {
      const res = await downloadMutation.mutateAsync({ orderId: id, plcId });
      setTxId(res.transaction_id);
    } catch (e: any) {
      console.error('Download error:', e);
      const message = e?.response?.data?.detail || e?.message || 'Failed to start roast. Please try again.';
      setError(message);
    }
  };

  // Show loading state
  if (!isNew && isLoadingOrder) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-amber-600" />
        <span className="ml-3 text-stone-600">Loading batch details...</span>
      </div>
    );
  }

  // Show error if failed to load existing order
  if (!isNew && orderError) {
    return (
      <div className="space-y-6 max-w-3xl">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={() => navigate('/orders')}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h2 className="text-xl font-bold">Error</h2>
        </div>
        <Alert variant="error">
          Failed to load batch details. {(orderError as any)?.message || 'Please try again.'}
        </Alert>
        <Button onClick={() => navigate('/orders')}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Batches
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={() => navigate('/orders')}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <h2 className="text-xl font-bold">{isNew ? 'New Roasting Batch' : 'Batch Details'}</h2>
        {existing && (
          <span className={"px-2 py-0.5 rounded-full text-xs font-medium " + statusColor(existing.status)}>
            {existing.status}
          </span>
        )}
      </div>

      {error && <Alert variant="error">{error}</Alert>}
      {recipesError && (
        <Alert variant="warning">
          Failed to load recipes. Some features may be limited.
        </Alert>
      )}

      <form onSubmit={handleSubmit} className="bg-white rounded-xl border border-stone-200 shadow-sm p-6 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-stone-700 mb-1">Batch Number</label>
            <Input
              value={poNumber}
              onChange={e => { setPoNumber(e.target.value); setFieldErrors(prev => ({ ...prev, poNumber: '' })); }}
              disabled={!isNew}
              placeholder="BTH-2024-001"
              className={fieldErrors.poNumber ? 'border-red-300 focus:border-red-500' : ''}
            />
            {fieldErrors.poNumber && <p className="mt-1 text-xs text-red-600">{fieldErrors.poNumber}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-stone-700 mb-1">Weight (kg)</label>
            <Input
              type="number"
              value={quantity}
              onChange={e => { setQuantity(Number(e.target.value)); setFieldErrors(prev => ({ ...prev, quantity: '' })); }}
              min={0.1}
              step={0.1}
              disabled={!isNew}
              className={fieldErrors.quantity ? 'border-red-300 focus:border-red-500' : ''}
            />
            {fieldErrors.quantity && <p className="mt-1 text-xs text-red-600">{fieldErrors.quantity}</p>}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-stone-700 mb-1">Roasting Profile</label>
            <Select 
              value={recipeId} 
              onChange={e => { setRecipeId(e.target.value); setFieldErrors(prev => ({ ...prev, recipeId: '' })); }} 
              disabled={!isNew || isLoadingRecipes}
              className={fieldErrors.recipeId ? 'border-red-300 focus:border-red-500' : ''}
            >
              <option value="">{isLoadingRecipes ? 'Loading profiles...' : '-- Select Profile --'}</option>
              {recipes?.map((r: any) => (
                <option key={r.id} value={r.id}>{r.recipe_code} - {r.recipe_name}</option>
              ))}
            </Select>
            {fieldErrors.recipeId && <p className="mt-1 text-xs text-red-600">{fieldErrors.recipeId}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-stone-700 mb-1">Target Roaster</label>
            <Select 
              value={plcId} 
              onChange={e => { setPlcId(e.target.value); setFieldErrors(prev => ({ ...prev, plcId: '' })); }} 
              disabled={!isNew}
              className={fieldErrors.plcId ? 'border-red-300 focus:border-red-500' : ''}
            >
              {ROASTER_OPTIONS.map(p => {
                const busy = runningPlcs.has(p.id);
                return (
                  <option key={p.id} value={p.id} disabled={busy}>
                    {p.name}{busy ? ' (Busy)' : ' (Available)'}
                  </option>
                );
              })}
            </Select>
            {fieldErrors.plcId && <p className="mt-1 text-xs text-red-600">{fieldErrors.plcId}</p>}
            {runningPlcs.has(plcId) && (
              <p className="text-xs text-red-600 mt-1">This roaster is currently running a batch. Please select another or wait.</p>
            )}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-stone-700 mb-1">Notes</label>
          <Input 
            value={notes} 
            onChange={e => setNotes(e.target.value)} 
            placeholder="Origin notes, bean variety..." 
            disabled={!isNew}
          />
        </div>

        {isNew ? (
          <Button 
            type="submit" 
            disabled={createMutation.isPending || isLoadingRecipes} 
            className="w-full"
          >
            {createMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Creating...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Create Batch
              </>
            )}
          </Button>
        ) : existing?.status === 'pending' && (
          <Button 
            type="button"
            onClick={handleDownload} 
            disabled={downloadMutation.isPending} 
            className="w-full"
          >
            {downloadMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Starting...
              </>
            ) : (
              <>
                <Download className="w-4 h-4 mr-2" />
                Start Roast to Roaster
              </>
            )}
          </Button>
        )}
      </form>

      {txId && downloadStatus && downloadStatus.status !== 'NOT_FOUND' && (
        <div className="bg-white rounded-xl border border-stone-200 shadow-sm p-6">
          <h4 className="font-medium mb-3 flex items-center gap-2">
            <Clock className="w-4 h-4" />
            Roast Status
          </h4>
          <div className="flex items-center gap-3 mb-3">
            <span className={"px-2 py-0.5 rounded-full text-xs font-medium " + statusColor(downloadStatus.status)}>
              {downloadStatus.status}
            </span>
            {downloadStatus.duration_ms && <span className="text-sm text-stone-500">({downloadStatus.duration_ms}ms)</span>}
          </div>
          {downloadStatus.po_number && (
            <p className="text-sm text-stone-600">Batch written: <span className="font-mono font-semibold">{downloadStatus.po_number}</span></p>
          )}
          {downloadStatus.message && (
            <Alert variant={downloadStatus.status === 'FAILED' ? 'error' : 'info'} className="mt-2">
              {downloadStatus.message}
            </Alert>
          )}
        </div>
      )}

      {existing && !isNew && (
        <div className="bg-white rounded-xl border border-stone-200 shadow-sm p-6 space-y-2 text-sm">
          <h4 className="font-medium mb-2">Batch Timeline</h4>
          <div className="flex justify-between text-stone-600">
            <span>Created</span>
            <span>{formatDate(existing.created_at)}</span>
          </div>
          {existing.started_at && (
            <div className="flex justify-between text-stone-600">
              <span>Started</span>
              <span>{formatDate(existing.started_at)}</span>
            </div>
          )}
          {existing.completed_at && (
            <div className="flex justify-between text-stone-600">
              <span>Completed</span>
              <span>{formatDate(existing.completed_at)}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
