import { useState } from 'react';
import { useRecipes } from '@/hooks/useRecipes';
import { useOrders } from '@/hooks/useOrders';
import { useDownloadRecipe, useDownloadStatus } from '@/hooks/usePlc';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import Alert from '@/components/ui/Alert';
import Badge from '@/components/ui/Badge';
import { Download, RefreshCw, CheckCircle, XCircle, Clock } from 'lucide-react';
import { statusColor } from '@/lib/utils';
import type { DownloadStatus } from '@/types';

const ROASTER_OPTIONS = [
  { id: 'LINE_A_PLC', name: 'Roaster A' },
  { id: 'LINE_B_PLC', name: 'Roaster B' },
  { id: 'LINE_C_PLC', name: 'Roaster C' },
];

export default function PlcDownload() {
  const { data: recipes } = useRecipes();
  const { data: allOrders } = useOrders();
  const downloadMutation = useDownloadRecipe();
  const [recipeId, setRecipeId] = useState('');
  const [plcId, setPlcId] = useState('LINE_A_PLC');
  const [txId, setTxId] = useState('');
  const [validate, setValidate] = useState(true);
  const [backup, setBackup] = useState(true);

  const runningPlcs = new Set(allOrders?.filter((o: any) => o.status === 'running').map((o: any) => o.plc_id) || []);
  const isBusy = runningPlcs.has(plcId);

  const { data: status } = useDownloadStatus(txId);

  const handleDownload = async () => {
    if (!recipeId || !plcId) return;
    const res = await downloadMutation.mutateAsync({
      recipe_id: recipeId,
      plc_id: plcId,
      validate,
      backup_current: backup,
      user: 'operator',
    });
    setTxId(res.transaction_id);
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="bg-white rounded-xl border border-stone-200 shadow-sm p-6 space-y-4">
        <h3 className="font-semibold text-lg">Start Roast to Roaster</h3>

        <div className="space-y-3">
          <div>
            <label className="block text-sm font-medium text-stone-700 mb-1">Select Roasting Profile</label>
            <Select value={recipeId} onChange={e => setRecipeId(e.target.value)}>
              <option value="">-- Choose Profile --</option>
              {recipes?.map((r: any) => (
                <option key={r.id} value={r.id}>{r.recipe_code} - {r.recipe_name} (v{r.version})</option>
              ))}
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium text-stone-700 mb-1">Select Roaster</label>
            <Select value={plcId} onChange={e => setPlcId(e.target.value)}>
              {ROASTER_OPTIONS.map(p => {
                const busy = runningPlcs.has(p.id);
                return (
                  <option key={p.id} value={p.id} disabled={busy}>
                    {p.name}{busy ? ' (Busy)' : ' (Available)'}
                  </option>
                );
              })}
            </Select>
            {isBusy && (
              <p className="text-xs text-red-600 mt-1">This roaster is currently running a batch. Please select another or wait.</p>
            )}
          </div>

          <div className="flex gap-6 pt-2">
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={validate} onChange={e => setValidate(e.target.checked)} className="rounded" />
              Validate before roast
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={backup} onChange={e => setBackup(e.target.checked)} className="rounded" />
              Backup current profile
            </label>
          </div>
        </div>

        <Button
          onClick={handleDownload}
          disabled={!recipeId || isBusy || downloadMutation.isPending}
          className="w-full"
          size="lg"
        >
          <Download className="w-5 h-5 mr-2" />
          {isBusy ? 'Roaster Busy' : downloadMutation.isPending ? 'Queuing...' : 'Start Roast'}
        </Button>
      </div>

      {txId && status && (
        <div className="bg-white rounded-xl border border-stone-200 shadow-sm p-6">
          <h4 className="font-medium mb-3">Roast Status</h4>
          <div className="flex items-center gap-3 mb-3">
            {status.status === 'PENDING' && <Clock className="w-5 h-5 text-yellow-500 animate-spin" />}
            {status.status === 'SUCCESS' && <CheckCircle className="w-5 h-5 text-green-500" />}
            {status.status === 'FAILED' && <XCircle className="w-5 h-5 text-red-500" />}
            <Badge className={statusColor(status.status)}>{status.status}</Badge>
            {status.duration_ms && <span className="text-sm text-stone-500">({status.duration_ms}ms)</span>}
          </div>
          {status.message && (
            <Alert variant={status.status === 'FAILED' ? 'error' : 'info'}>
              {status.message}
            </Alert>
          )}
          {status.verified !== undefined && (
            <p className="text-sm mt-2">
              Verified: {status.verified ? 'Yes' : 'No'}
              {status.tags_written && ` | Sensors updated: ${status.tags_written}`}
            </p>
          )}
        </div>
      )}
    </div>
  );
}
