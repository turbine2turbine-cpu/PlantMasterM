import { useState } from 'react';
import { usePlcStatus, useBatchStatus, useBatchControl } from '@/hooks/usePlc';
import { useRecipes } from '@/hooks/useRecipes';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Select from '@/components/ui/Select';
import Badge from '@/components/ui/Badge';
import Alert from '@/components/ui/Alert';
import {
  Thermometer, Wifi, WifiOff, Flame, Loader2,
  RotateCcw, Play, Pause, Square
} from 'lucide-react';

const ROASTER_IDS = ['LINE_A_PLC', 'LINE_B_PLC', 'LINE_C_PLC'];

const STATUS_COLORS: Record<string, string> = {
  IDLE: 'bg-gray-100 text-gray-700',
  INITIALIZING: 'bg-yellow-100 text-yellow-700',
  READY: 'bg-blue-100 text-blue-700',
  RUNNING: 'bg-green-100 text-green-700',
  HOLDING: 'bg-orange-100 text-orange-700',
  HELD: 'bg-orange-100 text-orange-700',
  ABORTING: 'bg-red-100 text-red-700',
  ABORTED: 'bg-red-100 text-red-700',
  COMPLETING: 'bg-purple-100 text-purple-700',
  COMPLETED: 'bg-green-100 text-green-700',
  UNKNOWN: 'bg-gray-100 text-gray-400',
  OFFLINE: 'bg-gray-100 text-gray-400',
};

export default function PlcStatusPanel() {
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-stone-800">Roaster Status & Control</h2>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {ROASTER_IDS.map(plcId => (
          <PlcCard key={plcId} plcId={plcId} />
        ))}
      </div>
    </div>
  );
}

function PlcCard({ plcId }: { plcId: string }) {
  const { data: plcData, isLoading: plcLoading } = usePlcStatus(plcId);
  const { data: batchData, isLoading: batchLoading } = useBatchStatus(plcId);
  const controlMutation = useBatchControl();
  const { data: recipes } = useRecipes();
  const [selectedRecipe, setSelectedRecipe] = useState('');
  const [error, setError] = useState('');

  const isLoading = plcLoading || batchLoading;
  const status = batchData;
  const runningBatch = plcData?.running_batch;
  const completedCount = plcData?.completed_batches ?? 0;

  const handleCommand = async (command: string) => {
    setError('');
    try {
      await controlMutation.mutateAsync({
        plcId,
        command,
        data: command === 'initialize' ? { recipe_id: selectedRecipe } : undefined,
      });
    } catch (e: any) {
      setError(e?.response?.data?.detail || e?.message || 'Command failed');
    }
  };

  if (isLoading) {
    return (
      <Card className="h-80 animate-pulse bg-stone-100">
        <div />
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Thermometer className="w-4 h-4" />
            {plcId.replace('LINE_', 'Roaster ').replace('_PLC', '')}
          </CardTitle>
          {plcData?.is_online ? (
            <Badge variant="success"><Wifi className="w-3 h-3 mr-1" /> Online</Badge>
          ) : (
            <Badge variant="error"><WifiOff className="w-3 h-3 mr-1" /> Offline</Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3 text-sm">
          {/* Batch Status */}
          <div className="flex items-center justify-between">
            <span className="text-stone-500">Batch State</span>
            <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${STATUS_COLORS[status?.status_name || 'UNKNOWN']}`}>
              {status?.status_name || 'UNKNOWN'}
            </span>
          </div>

          {/* Running Batch Info */}
          {runningBatch ? (
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-2">
              <div className="flex items-center gap-2 text-orange-800 font-medium">
                <Flame className="w-4 h-4" />
                <span>{String(runningBatch.po_number || '')}</span>
              </div>
              <div className="text-xs text-orange-600 mt-0.5 ml-6">
                {String(runningBatch.recipe_code || '')} — {String(runningBatch.quantity || '0')} kg
              </div>
            </div>
          ) : (
            <div className="bg-green-50 border border-green-200 rounded-lg p-2">
              <div className="flex items-center gap-2 text-green-800 font-medium">
                <Wifi className="w-4 h-4" />
                <span>Idle — Ready for next batch</span>
              </div>
            </div>
          )}

          {/* Stats */}
          <div className="flex justify-between">
            <span className="text-stone-500">Completed</span>
            <span className="font-medium">{completedCount}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-stone-500">Sensors</span>
            <span className="font-medium">{plcData?.active_tags ?? 0}</span>
          </div>

          {error && <Alert variant="error">{error}</Alert>}

          {/* Recipe Selection for Initialize */}
          {status?.can_initialize && (
            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">Recipe for Initialize</label>
              <Select value={selectedRecipe} onChange={e => setSelectedRecipe(e.target.value)}>
                <option value="">-- Select Profile --</option>
                {recipes?.map((r: any) => (
                  <option key={r.id} value={r.id}>{r.recipe_code} - {r.recipe_name}</option>
                ))}
              </Select>
            </div>
          )}

          {/* Control Buttons */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <Button
              size="sm"
              onClick={() => handleCommand('initialize')}
              disabled={!status?.can_initialize || controlMutation.isPending || !selectedRecipe}
              variant={status?.can_initialize ? 'default' : 'outline'}
            >
              <RotateCcw className="w-3 h-3 mr-1" /> Init
            </Button>
            <Button
              size="sm"
              onClick={() => handleCommand('start')}
              disabled={!status?.can_start || controlMutation.isPending}
              variant={status?.can_start ? 'default' : 'outline'}
            >
              <Play className="w-3 h-3 mr-1" /> Start
            </Button>
            <Button
              size="sm"
              onClick={() => handleCommand('hold')}
              disabled={!status?.can_hold || controlMutation.isPending}
              variant={status?.can_hold ? 'default' : 'outline'}
            >
              <Pause className="w-3 h-3 mr-1" /> Hold
            </Button>
            <Button
              size="sm"
              onClick={() => handleCommand('abort')}
              disabled={!status?.can_abort || controlMutation.isPending}
              className={status?.can_abort ? 'bg-red-600 hover:bg-red-700' : ''}
              variant={status?.can_abort ? 'default' : 'outline'}
            >
              <Square className="w-3 h-3 mr-1" /> Abort
            </Button>
          </div>

          {!status?.is_online && (
            <Alert variant="warning">PLC offline. Commands disabled.</Alert>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
