import { useState } from 'react';
import { useTagTrend } from '@/hooks/useMonitoring';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import Button from '@/components/ui/Button';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { TrendingUp } from 'lucide-react';

const BUCKETS = ['1 minute', '5 minutes', '1 hour'];

export default function TagTrendChart() {
  const [plcId, setPlcId] = useState('LINE_A_PLC');
  const [tagName, setTagName] = useState('Roaster.DrumTemp');
  const [hours, setHours] = useState(24);
  const [bucket, setBucket] = useState('1 minute');
  const [searchTag, setSearchTag] = useState('');

  const { data, isLoading } = useTagTrend(plcId, tagName || searchTag, hours, bucket);

  const chartData = data?.data?.map((d: any) => ({
    time: new Date(d.bucket).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' }),
    avg: Number(d.avg_value?.toFixed(2)),
    min: Number(d.min_value?.toFixed(2)),
    max: Number(d.max_value?.toFixed(2)),
  })) ?? [];

  return (
    <Card className="col-span-2">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-amber-600" />
          Sensor Trend
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-3 mb-4">
          <Select value={plcId} onChange={e => setPlcId(e.target.value)} className="w-40">
            <option value="LINE_A_PLC">Roaster A</option>
            <option value="LINE_B_PLC">Roaster B</option>
            <option value="LINE_C_PLC">Roaster C</option>
          </Select>
          <Input
            value={searchTag || tagName}
            onChange={e => setSearchTag(e.target.value)}
            placeholder="Sensor name (e.g. Roaster.DrumTemp)"
            className="w-56"
          />
          <Select value={String(hours)} onChange={e => setHours(Number(e.target.value))} className="w-32">
            <option value="1">1 Hour</option>
            <option value="6">6 Hours</option>
            <option value="24">24 Hours</option>
            <option value="168">7 Days</option>
          </Select>
          <Select value={bucket} onChange={e => setBucket(e.target.value)} className="w-36">
            {BUCKETS.map(b => <option key={b} value={b}>{b}</option>)}
          </Select>
          <Button size="sm" onClick={() => setTagName(searchTag)}>Load</Button>
        </div>

        {isLoading ? (
          <div className="h-80 flex items-center justify-center text-stone-400">Loading trend...</div>
        ) : chartData.length === 0 ? (
          <div className="h-80 flex items-center justify-center text-stone-400">No data available</div>
        ) : (
          <ResponsiveContainer width="100%" height={320}>
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorAvg" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#d97706" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#d97706" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="time" tick={{fontSize: 12}} stroke="#9ca3af" />
              <YAxis tick={{fontSize: 12}} stroke="#9ca3af" />
              <Tooltip
                contentStyle={{ borderRadius: '8px', border: '1px solid #e5e7eb', fontSize: '12px' }}
              />
              <Area type="monotone" dataKey="avg" stroke="#d97706" fillOpacity={1} fill="url(#colorAvg)" strokeWidth={2} />
              <Line type="monotone" dataKey="min" stroke="#10b981" strokeWidth={1} dot={false} />
              <Line type="monotone" dataKey="max" stroke="#ef4444" strokeWidth={1} dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </CardContent>
    </Card>
  );
}
