import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useRecipe, useCreateRecipe, useUpdateRecipe } from '@/hooks/useRecipes';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import Alert from '@/components/ui/Alert';
import { Plus, Trash2, Save, ArrowLeft } from 'lucide-react';
import type { RecipeParameter } from '@/types';

const PARAM_TYPES = ['INT', 'REAL', 'DINT', 'BOOL', 'STRING'];

const emptyParam = (): RecipeParameter => ({
  param_name: '',
  param_type: 'REAL',
  value_default: null,
  value_min: null,
  value_max: null,
  plc_tag: '',
  unit: '',
  sort_order: 0,
});

export default function RecipeEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isNew = !id;
  const { data: existing } = useRecipe(id || '');
  const createMutation = useCreateRecipe();
  const updateMutation = useUpdateRecipe();

  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [params, setParams] = useState<RecipeParameter[]>([emptyParam()]);
  const [error, setError] = useState('');

  useEffect(() => {
    if (existing) {
      setCode(existing.recipe_code);
      setName(existing.recipe_name);
      setParams(existing.parameters?.length ? existing.parameters : [emptyParam()]);
    }
  }, [existing]);

  const addParam = () => setParams([...params, { ...emptyParam(), sort_order: params.length }]);
  const removeParam = (idx: number) => setParams(params.filter((_, i) => i !== idx));
  const updateParam = (idx: number, field: keyof RecipeParameter, value: any) => {
    const next = [...params];
    next[idx] = { ...next[idx], [field]: value };
    setParams(next);
  };

  const handleSave = async () => {
    try {
      if (isNew) {
        await createMutation.mutateAsync({
          recipe_code: code,
          recipe_name: name,
          parameters: params.filter(p => p.param_name && p.plc_tag),
        });
      } else {
        await updateMutation.mutateAsync({
          id: id!,
          data: { recipe_name: name, parameters: params.filter(p => p.param_name && p.plc_tag) },
        });
      }
      navigate('/recipes');
    } catch (e: any) {
      setError(e.response?.data?.detail || 'Save failed');
    }
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={() => navigate('/recipes')}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <h2 className="text-xl font-bold">{isNew ? 'New Roasting Profile' : 'Edit Roasting Profile'}</h2>
      </div>

      {error && <Alert variant="error">{error}</Alert>}

      <div className="bg-white rounded-xl border border-stone-200 shadow-sm p-6 space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-stone-700 mb-1">Profile Code</label>
            <Input value={code} onChange={e => setCode(e.target.value)} disabled={!isNew} placeholder="ESP-001" />
          </div>
          <div>
            <label className="block text-sm font-medium text-stone-700 mb-1">Profile Name</label>
            <Input value={name} onChange={e => setName(e.target.value)} placeholder="Ethiopia Yirgacheffe Light Roast" />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-stone-200 shadow-sm p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-semibold">Roasting Parameters</h3>
          <Button size="sm" variant="outline" onClick={addParam}>
            <Plus className="w-4 h-4 mr-1" /> Add Parameter
          </Button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-stone-50 border-b border-stone-200">
              <tr>
                <th className="px-3 py-2 text-left">Name</th>
                <th className="px-3 py-2 text-left">Type</th>
                <th className="px-3 py-2 text-left">Default</th>
                <th className="px-3 py-2 text-left">Min</th>
                <th className="px-3 py-2 text-left">Max</th>
                <th className="px-3 py-2 text-left">Sensor Tag</th>
                <th className="px-3 py-2 text-left">Unit</th>
                <th className="px-3 py-2"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {params.map((p, i) => (
                <tr key={i}>
                  <td className="px-2 py-2"><Input size={1} value={p.param_name} onChange={e => updateParam(i, 'param_name', e.target.value)} placeholder="RoastTemp" /></td>
                  <td className="px-2 py-2">
                    <Select value={p.param_type} onChange={e => updateParam(i, 'param_type', e.target.value)}>
                      {PARAM_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                    </Select>
                  </td>
                  <td className="px-2 py-2"><Input size={1} value={typeof p.value_default === 'boolean' ? String(p.value_default) : (p.value_default ?? '')} onChange={e => updateParam(i, 'value_default', e.target.value)} placeholder="205.0" /></td>
                  <td className="px-2 py-2"><Input size={1} value={p.value_min ?? ''} onChange={e => updateParam(i, 'value_min', e.target.value ? parseFloat(e.target.value) : null)} placeholder="0" /></td>
                  <td className="px-2 py-2"><Input size={1} value={p.value_max ?? ''} onChange={e => updateParam(i, 'value_max', e.target.value ? parseFloat(e.target.value) : null)} placeholder="250" /></td>
                  <td className="px-2 py-2"><Input size={1} value={p.plc_tag} onChange={e => updateParam(i, 'plc_tag', e.target.value)} placeholder="Roaster.DrumTemp" /></td>
                  <td className="px-2 py-2"><Input size={1} value={p.unit ?? ''} onChange={e => updateParam(i, 'unit', e.target.value)} placeholder="°C" /></td>
                  <td className="px-2 py-2">
                    <Button variant="ghost" size="sm" onClick={() => removeParam(i)} disabled={params.length === 1}>
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="flex justify-end gap-3">
        <Button variant="outline" onClick={() => navigate('/recipes')}>Cancel</Button>
        <Button onClick={handleSave} disabled={createMutation.isPending || updateMutation.isPending}>
          <Save className="w-4 h-4 mr-2" />
          {createMutation.isPending || updateMutation.isPending ? 'Saving...' : 'Save Profile'}
        </Button>
      </div>
    </div>
  );
}
