import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useRecipes, useDeleteRecipe, useCloneRecipe } from '@/hooks/useRecipes';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import Input from '@/components/ui/Input';
import { Plus, Pencil, Trash2, Copy } from 'lucide-react';
import { formatDate } from '@/lib/utils';

export default function RecipeList() {
  const navigate = useNavigate();
  const { data: recipes, isLoading } = useRecipes();
  const deleteMutation = useDeleteRecipe();
  const cloneMutation = useCloneRecipe();
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [cloneRecipe, setCloneRecipe] = useState<any | null>(null);
  const [cloneCode, setCloneCode] = useState('');
  const [cloneName, setCloneName] = useState('');
  const [cloneError, setCloneError] = useState('');

  if (isLoading) return <div className="p-8 text-center text-stone-500">Loading roasting profiles...</div>;

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-stone-800">Roasting Profiles</h2>
        <Button onClick={() => navigate('/recipes/new')}>
          <Plus className="w-4 h-4 mr-2" /> New Profile
        </Button>
      </div>

      <div className="bg-white rounded-xl border border-stone-200 shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-stone-50 border-b border-stone-200">
            <tr>
              <th className="px-4 py-3 text-left font-medium text-stone-600">Code</th>
              <th className="px-4 py-3 text-left font-medium text-stone-600">Profile Name</th>
              <th className="px-4 py-3 text-left font-medium text-stone-600">Version</th>
              <th className="px-4 py-3 text-left font-medium text-stone-600">Status</th>
              <th className="px-4 py-3 text-left font-medium text-stone-600">Updated</th>
              <th className="px-4 py-3 text-right font-medium text-stone-600">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100">
            {recipes?.map((recipe: any) => (
              <tr key={recipe.id} className="hover:bg-stone-50">
                <td className="px-4 py-3 font-mono text-amber-700">{recipe.recipe_code}</td>
                <td className="px-4 py-3">{recipe.recipe_name}</td>
                <td className="px-4 py-3">v{recipe.version}</td>
                <td className="px-4 py-3">
                  <Badge variant={recipe.is_active ? 'success' : 'default'}>
                    {recipe.is_active ? 'Active' : 'Inactive'}
                  </Badge>
                </td>
                <td className="px-4 py-3 text-stone-500">{formatDate(recipe.updated_at)}</td>
                <td className="px-4 py-3 text-right">
                  <div className="flex justify-end gap-2">
                    <Button variant="ghost" size="sm" onClick={() => { setCloneRecipe(recipe); setCloneCode(recipe.recipe_code + '-COPY'); setCloneName(recipe.recipe_name + ' (Copy)'); setCloneError(''); }}>
                      <Copy className="w-4 h-4 text-amber-600" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => navigate(`/recipes/${recipe.id}`)}>
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => setDeleteId(recipe.id)}>
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {deleteId && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-sm w-full mx-4 shadow-xl">
            <h3 className="text-lg font-semibold mb-2">Confirm Delete</h3>
            <p className="text-stone-600 mb-4">Are you sure you want to deactivate this roasting profile?</p>
            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setDeleteId(null)}>Cancel</Button>
              <Button variant="destructive" onClick={() => { deleteMutation.mutate(deleteId); setDeleteId(null); }}>
                Delete
              </Button>
            </div>
          </div>
        </div>
      )}

      {cloneRecipe && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-md w-full mx-4 shadow-xl space-y-4">
            <h3 className="text-lg font-semibold">Copy Roasting Profile</h3>
            <p className="text-sm text-stone-500">Copy from: <span className="font-mono font-medium text-amber-700">{cloneRecipe.recipe_code}</span> — {cloneRecipe.recipe_name}</p>

            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-stone-700 mb-1">New Profile Code</label>
                <Input value={cloneCode} onChange={e => setCloneCode(e.target.value)} placeholder="ESP-002-COPY" />
              </div>
              <div>
                <label className="block text-sm font-medium text-stone-700 mb-1">New Profile Name</label>
                <Input value={cloneName} onChange={e => setCloneName(e.target.value)} placeholder="Ethiopia Yirgacheffe (Copy)" />
              </div>
              {cloneError && <p className="text-sm text-red-600">{cloneError}</p>}
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <Button variant="outline" onClick={() => setCloneRecipe(null)}>Cancel</Button>
              <Button
                onClick={async () => {
                  try {
                    await cloneMutation.mutateAsync({ id: cloneRecipe.id, newCode: cloneCode, newName: cloneName });
                    setCloneRecipe(null);
                  } catch (e: any) {
                    setCloneError(e.response?.data?.detail || 'Clone failed');
                  }
                }}
                disabled={!cloneCode || !cloneName || cloneMutation.isPending}
              >
                {cloneMutation.isPending ? 'Copying...' : 'Copy Profile'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
