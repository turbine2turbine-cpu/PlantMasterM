# PlantMaster - PLC Recipe Management System

A full-stack industrial application for managing manufacturing recipes and downloading them to Rockwell PLCs (Allen-Bradley), with real-time monitoring and production order tracking.

## Architecture

```
+-----------+      +-----------+      +------------------+
|  Nginx    |----->|  FastAPI  |----->|   TimescaleDB    |
| (React)   |      | (Python)  |      | (PostgreSQL +    |
|  :80      |      |  :9000    |      |  TimescaleDB)    |
+-----------+      +-----------+      +------------------+
       |                                    |
       |                                    v
       |                            Time-series data
       |                            (tags, events, orders)
       v
  Static React SPA
  (Vite + Tailwind)
```

## Tech Stack

| Layer | Technology |
|-------|-----------|
| **Frontend** | React 18, TypeScript, Vite, Tailwind CSS, TanStack Query, Recharts, Lucide React |
| **Backend** | FastAPI, Python 3.11, asyncpg, Pydantic |
| **Database** | PostgreSQL 16 + TimescaleDB extension |
| **PLC Drivers** | PyLogix (EtherNet/IP), opcua-asyncio |
| **Container** | Docker, Docker Compose |
| **Reverse Proxy** | Nginx |

## Quick Start

### Prerequisites

- Docker Engine 20.10+
- Docker Compose 2.0+

### 1. Clone & Configure

```bash
git clone <repo-url>
cd plantmaster-docker

# Copy environment file
cp .env.example .env

# Edit .env with your PLC IP address
nano .env
```

### 2. Start All Services

```bash
docker-compose up -d
```

### 3. Verify

| Service | URL | Description |
|---------|-----|-------------|
| Web UI | http://localhost | React frontend (Nginx) |
| API Docs | http://localhost:9000/docs | FastAPI Swagger UI |
| Health | http://localhost:9000/health | API health check |
| Database | localhost:5432 | TimescaleDB |

### 4. First Login

Open http://localhost in your browser. The default user is:
- **Username**: `operator`
- **Role**: `operator`

*(Note: Authentication is currently mock/stub. Integrate with your LDAP/AD in production.)*

## Services

### TimescaleDB
- **Image**: `timescale/timescaledb:latest-pg16`
- **Port**: `5432`
- **Data**: Persisted in Docker volume `timescale_data`
- **Init**: `init_db.sql` runs on first startup (schema + sample data)

### FastAPI Backend
- **Build**: Python 3.11 slim
- **Port**: `9000` (host) → `8000` (container)
- **Features**:
  - Recipe CRUD with versioning
  - Production order management
  - PLC recipe download with validation & backup
  - Real-time tag reading/writing
  - Time-series data collection & trending
  - Alarm & event logging

### React Frontend
- **Build**: Multi-stage Docker (Node build -> Nginx serve)
- **Port**: `80`
- **Features**:
  - Responsive sidebar layout
  - Recipe editor with parameter management
  - Production order workflow
  - PLC status & control panel
  - Tag trend charts (Recharts)
  - Alarm list with severity levels

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/recipes` | GET/POST | List / create recipes |
| `/api/recipes/{id}` | GET/PUT/DELETE | Recipe detail / update / delete |
| `/api/recipes/{id}/validate` | POST | Validate recipe parameters |
| `/api/recipes/{id}/compare/{plc_id}` | POST | Compare recipe vs PLC values |
| `/api/orders` | GET/POST | List / create production orders |
| `/api/orders/{id}/download` | POST | Download order recipe to PLC |
| `/api/plc/download` | POST | Queue recipe download to PLC |
| `/api/plc/read-tags` | POST | Read PLC tags |
| `/api/plc/write-tags` | POST | Write PLC tags |
| `/api/plc/status/{plc_id}` | GET | PLC connection status |
| `/api/monitoring/tags/{plc_id}/trend` | GET | Tag trend data |
| `/api/monitoring/alarms` | GET | Unacknowledged alarms |
| `/api/monitoring/downloads` | GET | Download history |

## Database Schema

### Master Tables
- `products` - Product catalog
- `recipes` - Recipe definitions with versioning
- `recipe_parameters` - Recipe parameter mappings to PLC tags
- `plc_configs` - PLC connection configurations
- `production_orders` - Manufacturing orders

### Time-Series Hypertables
- `plc_tag_values` - PLC tag readings (1-second sampling)
- `recipe_downloads` - Recipe download audit log
- `process_events` - Alarms & events
- `order_executions` - Order execution log

### Continuous Aggregates
- `plc_hourly_summary` - Hourly tag statistics
- `plc_daily_summary` - Daily tag statistics

## PLC Configuration

Edit `.env` to match your PLC network settings:

```env
# Rockwell PLC (Allen-Bradley) via EtherNet/IP
PLC_HOST=192.168.1.10
PLC_SLOT=0
PLC_TIMEOUT=5

# Or use OPC UA (via Kepware / FactoryTalk)
OPC_UA_ENDPOINT=opc.tcp://192.168.1.10:4840
```

## Development

### Run Backend Only

```bash
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 9000
```

### Run Frontend Only

```bash
cd frontend
npm install
npm run dev
# Opens at http://localhost:5173
```

### Run Full Stack (Dev Mode)

```bash
docker-compose up -d timescaledb
# Wait for DB to be ready, then:
cd backend && uvicorn app.main:app --reload --host 0.0.0.0 --port 9000
# In another terminal:
cd frontend && npm run dev
```

## Production Notes

1. **Change default passwords** in `.env` before deploying
2. **Enable API key authentication** by setting `API_KEY` in backend config
3. **Use TLS/SSL** - Add certificates to Nginx config
4. **Backup strategy** - Schedule `pg_dump` for TimescaleDB volume
5. **PLC network** - Ensure Docker host can reach PLC IP (may need `network_mode: host` or custom bridge)
6. **Resource limits** - Add `deploy.resources` constraints in docker-compose for production

## Troubleshooting

| Issue | Solution |
|-------|----------|
| `Connection refused` to PLC | Check `PLC_HOST` in `.env` and network connectivity |
| Database not initializing | Delete volume: `docker-compose down -v` then `up -d` |
| Frontend shows blank page | Check browser console for API errors; verify `api` container is healthy |
| CORS errors | Ensure `FRONTEND_PORT` matches actual access URL |

## License

MIT
