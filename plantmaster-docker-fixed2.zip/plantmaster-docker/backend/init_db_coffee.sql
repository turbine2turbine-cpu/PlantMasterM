-- ============================================
-- 20 COFFEE ROASTING PROFILES WITH 20 PARAMETERS EACH
-- ============================================

-- Profile 1: Ethiopia Yirgacheffe Light
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('ETH-001', 'Ethiopia Yirgacheffe Light', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '179', 150, 220, 'Roaster.ChargeTemp', '°C', 1
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '91', 80, 120, 'Roaster.TurnaroundTemp', '°C', 2
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '195', 190, 205, 'Roaster.FirstCrackTemp', '°C', 3
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '202', 195, 215, 'Roaster.DropTemp', '°C', 4
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '527', 420, 660, 'Roaster.RoastTime', 'sec', 5
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'Roaster.DryingPhase', 'sec', 6
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'Roaster.MaillardPhase', 'sec', 7
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '94', 60, 150, 'Roaster.DevelopmentTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 15.0, 25.0, 'Roaster.DevelopmentRatio', '%', 9
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '8.43', 5.0, 12.0, 'Roaster.RateOfRise', '°C/min', 10
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '53', 40, 70, 'Roaster.DrumSpeed', 'RPM', 11
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Airflow', 'REAL', '72', 50, 100, 'Roaster.Airflow', '%', 12
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '3.11', 1.5, 5.0, 'Roaster.GasPressure', 'kPa', 13
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'Roaster.FanSpeed', '%', 14
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '171', 120, 300, 'Roaster.CoolingTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'Roaster.BeanTempStart', '°C', 16
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 195, 215, 'Roaster.BeanTempEnd', '°C', 17
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '330', 280, 380, 'Roaster.ExhaustTemp', '°C', 18
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'Roaster.Humidity', '%RH', 19
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'Roaster.BatchSize', 'kg', 20
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;

-- Profile 2: Ethiopia Sidamo Medium
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('ETH-002', 'Ethiopia Sidamo Medium', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '204', 160, 230, 'Roaster.ChargeTemp', '°C', 1
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '99', 85, 125, 'Roaster.TurnaroundTemp', '°C', 2
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '189', 192, 208, 'Roaster.FirstCrackTemp', '°C', 3
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '210', 205, 225, 'Roaster.DropTemp', '°C', 4
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '614', 480, 720, 'Roaster.RoastTime', 'sec', 5
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '270', 210, 330, 'Roaster.DryingPhase', 'sec', 6
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '210', 150, 270, 'Roaster.MaillardPhase', 'sec', 7
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '74', 50, 120, 'Roaster.DevelopmentTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '13.52', 10.0, 20.0, 'Roaster.DevelopmentRatio', '%', 9
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.32', 4.0, 10.0, 'Roaster.RateOfRise', '°C/min', 10
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '50', 35, 65, 'Roaster.DrumSpeed', 'RPM', 11
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Airflow', 'REAL', '62', 40, 90, 'Roaster.Airflow', '%', 12
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '3.65', 2.0, 5.5, 'Roaster.GasPressure', 'kPa', 13
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '67', 45, 95, 'Roaster.FanSpeed', '%', 14
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '211', 150, 330, 'Roaster.CoolingTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 19, 31, 'Roaster.BeanTempStart', '°C', 16
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '224', 205, 225, 'Roaster.BeanTempEnd', '°C', 17
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '339', 300, 400, 'Roaster.ExhaustTemp', '°C', 18
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '46', 32, 72, 'Roaster.Humidity', '%RH', 19
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '18', 8, 35, 'Roaster.BatchSize', 'kg', 20
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;

-- Profile 3: Colombia Huila Medium
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('COL-001', 'Colombia Huila Medium', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '203', 160, 230, 'Roaster.ChargeTemp', '°C', 1
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '96', 85, 125, 'Roaster.TurnaroundTemp', '°C', 2
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '201', 192, 208, 'Roaster.FirstCrackTemp', '°C', 3
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '207', 205, 225, 'Roaster.DropTemp', '°C', 4
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '605', 480, 720, 'Roaster.RoastTime', 'sec', 5
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '266', 210, 330, 'Roaster.DryingPhase', 'sec', 6
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '220', 150, 270, 'Roaster.MaillardPhase', 'sec', 7
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '76', 50, 120, 'Roaster.DevelopmentTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '14.54', 10.0, 20.0, 'Roaster.DevelopmentRatio', '%', 9
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '6.9', 4.0, 10.0, 'Roaster.RateOfRise', '°C/min', 10
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '49', 35, 65, 'Roaster.DrumSpeed', 'RPM', 11
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Airflow', 'REAL', '67', 40, 90, 'Roaster.Airflow', '%', 12
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '3.64', 2.0, 5.5, 'Roaster.GasPressure', 'kPa', 13
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '72', 45, 95, 'Roaster.FanSpeed', '%', 14
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '207', 150, 330, 'Roaster.CoolingTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 19, 31, 'Roaster.BeanTempStart', '°C', 16
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '207', 205, 225, 'Roaster.BeanTempEnd', '°C', 17
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '337', 300, 400, 'Roaster.ExhaustTemp', '°C', 18
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '46', 32, 72, 'Roaster.Humidity', '%RH', 19
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '18', 8, 35, 'Roaster.BatchSize', 'kg', 20
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;

-- Profile 4: Colombia Supremo Dark
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('COL-002', 'Colombia Supremo Dark', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '198', 170, 240, 'Roaster.ChargeTemp', '°C', 1
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '107', 90, 130, 'Roaster.TurnaroundTemp', '°C', 2
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '210', 194, 210, 'Roaster.FirstCrackTemp', '°C', 3
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '225', 215, 235, 'Roaster.DropTemp', '°C', 4
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '647', 540, 780, 'Roaster.RoastTime', 'sec', 5
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '296', 240, 360, 'Roaster.DryingPhase', 'sec', 6
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '239', 180, 300, 'Roaster.MaillardPhase', 'sec', 7
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '58', 40, 100, 'Roaster.DevelopmentTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '10.17', 8.0, 15.0, 'Roaster.DevelopmentRatio', '%', 9
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '6.12', 3.5, 9.0, 'Roaster.RateOfRise', '°C/min', 10
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '43', 30, 60, 'Roaster.DrumSpeed', 'RPM', 11
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Airflow', 'REAL', '57', 30, 80, 'Roaster.Airflow', '%', 12
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '4.26', 2.5, 6.0, 'Roaster.GasPressure', 'kPa', 13
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '66', 40, 90, 'Roaster.FanSpeed', '%', 14
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '251', 180, 360, 'Roaster.CoolingTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 20, 32, 'Roaster.BeanTempStart', '°C', 16
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '219', 215, 235, 'Roaster.BeanTempEnd', '°C', 17
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '371', 320, 420, 'Roaster.ExhaustTemp', '°C', 18
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '51', 35, 75, 'Roaster.Humidity', '%RH', 19
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '20', 10, 40, 'Roaster.BatchSize', 'kg', 20
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;

-- Profile 5: Brazil Santos Medium
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('BRA-001', 'Brazil Santos Medium', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '203', 160, 230, 'Roaster.ChargeTemp', '°C', 1
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '98', 85, 125, 'Roaster.TurnaroundTemp', '°C', 2
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '199', 192, 208, 'Roaster.FirstCrackTemp', '°C', 3
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '206', 205, 225, 'Roaster.DropTemp', '°C', 4
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '584', 480, 720, 'Roaster.RoastTime', 'sec', 5
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '283', 210, 330, 'Roaster.DryingPhase', 'sec', 6
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '201', 150, 270, 'Roaster.MaillardPhase', 'sec', 7
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '78', 50, 120, 'Roaster.DevelopmentTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '13.74', 10.0, 20.0, 'Roaster.DevelopmentRatio', '%', 9
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '6.84', 4.0, 10.0, 'Roaster.RateOfRise', '°C/min', 10
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '49', 35, 65, 'Roaster.DrumSpeed', 'RPM', 11
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Airflow', 'REAL', '66', 40, 90, 'Roaster.Airflow', '%', 12
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '3.94', 2.0, 5.5, 'Roaster.GasPressure', 'kPa', 13
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '69', 45, 95, 'Roaster.FanSpeed', '%', 14
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '206', 150, 330, 'Roaster.CoolingTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '24', 19, 31, 'Roaster.BeanTempStart', '°C', 16
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '220', 205, 225, 'Roaster.BeanTempEnd', '°C', 17
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '348', 300, 400, 'Roaster.ExhaustTemp', '°C', 18
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '49', 32, 72, 'Roaster.Humidity', '%RH', 19
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '18', 8, 35, 'Roaster.BatchSize', 'kg', 20
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;

-- Profile 6: Brazil Cerrado Dark
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('BRA-002', 'Brazil Cerrado Dark', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '198', 170, 240, 'Roaster.ChargeTemp', '°C', 1
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '102', 90, 130, 'Roaster.TurnaroundTemp', '°C', 2
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 194, 210, 'Roaster.FirstCrackTemp', '°C', 3
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '231', 215, 235, 'Roaster.DropTemp', '°C', 4
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '660', 540, 780, 'Roaster.RoastTime', 'sec', 5
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '308', 240, 360, 'Roaster.DryingPhase', 'sec', 6
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '246', 180, 300, 'Roaster.MaillardPhase', 'sec', 7
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '60', 40, 100, 'Roaster.DevelopmentTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '10.4', 8.0, 15.0, 'Roaster.DevelopmentRatio', '%', 9
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '5.94', 3.5, 9.0, 'Roaster.RateOfRise', '°C/min', 10
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '44', 30, 60, 'Roaster.DrumSpeed', 'RPM', 11
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Airflow', 'REAL', '54', 30, 80, 'Roaster.Airflow', '%', 12
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '4.2', 2.5, 6.0, 'Roaster.GasPressure', 'kPa', 13
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '62', 40, 90, 'Roaster.FanSpeed', '%', 14
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '252', 180, 360, 'Roaster.CoolingTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 20, 32, 'Roaster.BeanTempStart', '°C', 16
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '217', 215, 235, 'Roaster.BeanTempEnd', '°C', 17
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '351', 320, 420, 'Roaster.ExhaustTemp', '°C', 18
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '49', 35, 75, 'Roaster.Humidity', '%RH', 19
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '21', 10, 40, 'Roaster.BatchSize', 'kg', 20
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;

-- Profile 7: Guatemala Antigua Medium
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('GUA-001', 'Guatemala Antigua Medium', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '199', 160, 230, 'Roaster.ChargeTemp', '°C', 1
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '104', 85, 125, 'Roaster.TurnaroundTemp', '°C', 2
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '191', 192, 208, 'Roaster.FirstCrackTemp', '°C', 3
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '217', 205, 225, 'Roaster.DropTemp', '°C', 4
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '594', 480, 720, 'Roaster.RoastTime', 'sec', 5
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '276', 210, 330, 'Roaster.DryingPhase', 'sec', 6
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '214', 150, 270, 'Roaster.MaillardPhase', 'sec', 7
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '76', 50, 120, 'Roaster.DevelopmentTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '13.65', 10.0, 20.0, 'Roaster.DevelopmentRatio', '%', 9
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.04', 4.0, 10.0, 'Roaster.RateOfRise', '°C/min', 10
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '48', 35, 65, 'Roaster.DrumSpeed', 'RPM', 11
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Airflow', 'REAL', '67', 40, 90, 'Roaster.Airflow', '%', 12
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '3.88', 2.0, 5.5, 'Roaster.GasPressure', 'kPa', 13
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '72', 45, 95, 'Roaster.FanSpeed', '%', 14
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '217', 150, 330, 'Roaster.CoolingTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 19, 31, 'Roaster.BeanTempStart', '°C', 16
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '225', 205, 225, 'Roaster.BeanTempEnd', '°C', 17
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '344', 300, 400, 'Roaster.ExhaustTemp', '°C', 18
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '46', 32, 72, 'Roaster.Humidity', '%RH', 19
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '18', 8, 35, 'Roaster.BatchSize', 'kg', 20
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;

-- Profile 8: Guatemala Huehuetenango Light
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('GUA-002', 'Guatemala Huehuetenango Light', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '189', 150, 220, 'Roaster.ChargeTemp', '°C', 1
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '93', 80, 120, 'Roaster.TurnaroundTemp', '°C', 2
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '201', 190, 205, 'Roaster.FirstCrackTemp', '°C', 3
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '195', 195, 215, 'Roaster.DropTemp', '°C', 4
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '559', 420, 660, 'Roaster.RoastTime', 'sec', 5
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '251', 180, 300, 'Roaster.DryingPhase', 'sec', 6
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '179', 120, 240, 'Roaster.MaillardPhase', 'sec', 7
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '94', 60, 150, 'Roaster.DevelopmentTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '18.47', 15.0, 25.0, 'Roaster.DevelopmentRatio', '%', 9
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '8.51', 5.0, 12.0, 'Roaster.RateOfRise', '°C/min', 10
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '53', 40, 70, 'Roaster.DrumSpeed', 'RPM', 11
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Airflow', 'REAL', '78', 50, 100, 'Roaster.Airflow', '%', 12
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '3.24', 1.5, 5.0, 'Roaster.GasPressure', 'kPa', 13
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'Roaster.FanSpeed', '%', 14
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '177', 120, 300, 'Roaster.CoolingTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '21', 18, 30, 'Roaster.BeanTempStart', '°C', 16
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '206', 195, 215, 'Roaster.BeanTempEnd', '°C', 17
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '314', 280, 380, 'Roaster.ExhaustTemp', '°C', 18
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '47', 30, 70, 'Roaster.Humidity', '%RH', 19
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'Roaster.BatchSize', 'kg', 20
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;

-- Profile 9: Kenya AA Medium
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('KEN-001', 'Kenya AA Medium', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '196', 160, 230, 'Roaster.ChargeTemp', '°C', 1
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '102', 85, 125, 'Roaster.TurnaroundTemp', '°C', 2
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '189', 192, 208, 'Roaster.FirstCrackTemp', '°C', 3
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '208', 205, 225, 'Roaster.DropTemp', '°C', 4
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '629', 480, 720, 'Roaster.RoastTime', 'sec', 5
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '268', 210, 330, 'Roaster.DryingPhase', 'sec', 6
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '209', 150, 270, 'Roaster.MaillardPhase', 'sec', 7
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '73', 50, 120, 'Roaster.DevelopmentTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '13.38', 10.0, 20.0, 'Roaster.DevelopmentRatio', '%', 9
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.26', 4.0, 10.0, 'Roaster.RateOfRise', '°C/min', 10
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '48', 35, 65, 'Roaster.DrumSpeed', 'RPM', 11
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Airflow', 'REAL', '62', 40, 90, 'Roaster.Airflow', '%', 12
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '3.89', 2.0, 5.5, 'Roaster.GasPressure', 'kPa', 13
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '73', 45, 95, 'Roaster.FanSpeed', '%', 14
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '202', 150, 330, 'Roaster.CoolingTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '24', 19, 31, 'Roaster.BeanTempStart', '°C', 16
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '209', 205, 225, 'Roaster.BeanTempEnd', '°C', 17
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '331', 300, 400, 'Roaster.ExhaustTemp', '°C', 18
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '49', 32, 72, 'Roaster.Humidity', '%RH', 19
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '18', 8, 35, 'Roaster.BatchSize', 'kg', 20
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;

-- Profile 10: Kenya PB Light
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('KEN-002', 'Kenya PB Light', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '184', 150, 220, 'Roaster.ChargeTemp', '°C', 1
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '99', 80, 120, 'Roaster.TurnaroundTemp', '°C', 2
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '200', 190, 205, 'Roaster.FirstCrackTemp', '°C', 3
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '201', 195, 215, 'Roaster.DropTemp', '°C', 4
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '547', 420, 660, 'Roaster.RoastTime', 'sec', 5
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '252', 180, 300, 'Roaster.DryingPhase', 'sec', 6
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '177', 120, 240, 'Roaster.MaillardPhase', 'sec', 7
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '90', 60, 150, 'Roaster.DevelopmentTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.82', 15.0, 25.0, 'Roaster.DevelopmentRatio', '%', 9
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '8.65', 5.0, 12.0, 'Roaster.RateOfRise', '°C/min', 10
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '55', 40, 70, 'Roaster.DrumSpeed', 'RPM', 11
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Airflow', 'REAL', '75', 50, 100, 'Roaster.Airflow', '%', 12
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '3.33', 1.5, 5.0, 'Roaster.GasPressure', 'kPa', 13
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '83', 50, 100, 'Roaster.FanSpeed', '%', 14
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '174', 120, 300, 'Roaster.CoolingTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '21', 18, 30, 'Roaster.BeanTempStart', '°C', 16
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '202', 195, 215, 'Roaster.BeanTempEnd', '°C', 17
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '308', 280, 380, 'Roaster.ExhaustTemp', '°C', 18
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '45', 30, 70, 'Roaster.Humidity', '%RH', 19
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'Roaster.BatchSize', 'kg', 20
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;

-- Profile 11: Costa Rica Tarrazu Medium
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('CRI-001', 'Costa Rica Tarrazu Medium', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '204', 160, 230, 'Roaster.ChargeTemp', '°C', 1
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '103', 85, 125, 'Roaster.TurnaroundTemp', '°C', 2
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '196', 192, 208, 'Roaster.FirstCrackTemp', '°C', 3
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '223', 205, 225, 'Roaster.DropTemp', '°C', 4
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '584', 480, 720, 'Roaster.RoastTime', 'sec', 5
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '257', 210, 330, 'Roaster.DryingPhase', 'sec', 6
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '202', 150, 270, 'Roaster.MaillardPhase', 'sec', 7
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '77', 50, 120, 'Roaster.DevelopmentTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '14.18', 10.0, 20.0, 'Roaster.DevelopmentRatio', '%', 9
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '6.81', 4.0, 10.0, 'Roaster.RateOfRise', '°C/min', 10
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '48', 35, 65, 'Roaster.DrumSpeed', 'RPM', 11
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Airflow', 'REAL', '68', 40, 90, 'Roaster.Airflow', '%', 12
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '3.74', 2.0, 5.5, 'Roaster.GasPressure', 'kPa', 13
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '71', 45, 95, 'Roaster.FanSpeed', '%', 14
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '207', 150, 330, 'Roaster.CoolingTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 19, 31, 'Roaster.BeanTempStart', '°C', 16
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '220', 205, 225, 'Roaster.BeanTempEnd', '°C', 17
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '336', 300, 400, 'Roaster.ExhaustTemp', '°C', 18
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '50', 32, 72, 'Roaster.Humidity', '%RH', 19
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '18', 8, 35, 'Roaster.BatchSize', 'kg', 20
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;

-- Profile 12: Costa Rica Honey Light
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('CRI-002', 'Costa Rica Honey Light', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '194', 150, 220, 'Roaster.ChargeTemp', '°C', 1
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '98', 80, 120, 'Roaster.TurnaroundTemp', '°C', 2
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '194', 190, 205, 'Roaster.FirstCrackTemp', '°C', 3
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '210', 195, 215, 'Roaster.DropTemp', '°C', 4
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '564', 420, 660, 'Roaster.RoastTime', 'sec', 5
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '241', 180, 300, 'Roaster.DryingPhase', 'sec', 6
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '177', 120, 240, 'Roaster.MaillardPhase', 'sec', 7
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '87', 60, 150, 'Roaster.DevelopmentTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.27', 15.0, 25.0, 'Roaster.DevelopmentRatio', '%', 9
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '8.44', 5.0, 12.0, 'Roaster.RateOfRise', '°C/min', 10
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '56', 40, 70, 'Roaster.DrumSpeed', 'RPM', 11
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Airflow', 'REAL', '75', 50, 100, 'Roaster.Airflow', '%', 12
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '3.19', 1.5, 5.0, 'Roaster.GasPressure', 'kPa', 13
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '76', 50, 100, 'Roaster.FanSpeed', '%', 14
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '174', 120, 300, 'Roaster.CoolingTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '21', 18, 30, 'Roaster.BeanTempStart', '°C', 16
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '207', 195, 215, 'Roaster.BeanTempEnd', '°C', 17
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '325', 280, 380, 'Roaster.ExhaustTemp', '°C', 18
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '43', 30, 70, 'Roaster.Humidity', '%RH', 19
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'Roaster.BatchSize', 'kg', 20
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;

-- Profile 13: Sumatra Mandheling Dark
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('SUM-001', 'Sumatra Mandheling Dark', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '196', 170, 240, 'Roaster.ChargeTemp', '°C', 1
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '103', 90, 130, 'Roaster.TurnaroundTemp', '°C', 2
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '207', 194, 210, 'Roaster.FirstCrackTemp', '°C', 3
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '228', 215, 235, 'Roaster.DropTemp', '°C', 4
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '644', 540, 780, 'Roaster.RoastTime', 'sec', 5
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '298', 240, 360, 'Roaster.DryingPhase', 'sec', 6
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '233', 180, 300, 'Roaster.MaillardPhase', 'sec', 7
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '59', 40, 100, 'Roaster.DevelopmentTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '9.96', 8.0, 15.0, 'Roaster.DevelopmentRatio', '%', 9
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '6.22', 3.5, 9.0, 'Roaster.RateOfRise', '°C/min', 10
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '43', 30, 60, 'Roaster.DrumSpeed', 'RPM', 11
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Airflow', 'REAL', '56', 30, 80, 'Roaster.Airflow', '%', 12
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '4.33', 2.5, 6.0, 'Roaster.GasPressure', 'kPa', 13
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '68', 40, 90, 'Roaster.FanSpeed', '%', 14
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '245', 180, 360, 'Roaster.CoolingTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 20, 32, 'Roaster.BeanTempStart', '°C', 16
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '215', 215, 235, 'Roaster.BeanTempEnd', '°C', 17
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '376', 320, 420, 'Roaster.ExhaustTemp', '°C', 18
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '48', 35, 75, 'Roaster.Humidity', '%RH', 19
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '19', 10, 40, 'Roaster.BatchSize', 'kg', 20
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;

-- Profile 14: Sumatra Lintong Medium
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('SUM-002', 'Sumatra Lintong Medium', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '193', 160, 230, 'Roaster.ChargeTemp', '°C', 1
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '97', 85, 125, 'Roaster.TurnaroundTemp', '°C', 2
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '202', 192, 208, 'Roaster.FirstCrackTemp', '°C', 3
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '220', 205, 225, 'Roaster.DropTemp', '°C', 4
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '600', 480, 720, 'Roaster.RoastTime', 'sec', 5
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '263', 210, 330, 'Roaster.DryingPhase', 'sec', 6
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '212', 150, 270, 'Roaster.MaillardPhase', 'sec', 7
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '72', 50, 120, 'Roaster.DevelopmentTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '13.53', 10.0, 20.0, 'Roaster.DevelopmentRatio', '%', 9
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '6.65', 4.0, 10.0, 'Roaster.RateOfRise', '°C/min', 10
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '51', 35, 65, 'Roaster.DrumSpeed', 'RPM', 11
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Airflow', 'REAL', '64', 40, 90, 'Roaster.Airflow', '%', 12
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '3.96', 2.0, 5.5, 'Roaster.GasPressure', 'kPa', 13
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '73', 45, 95, 'Roaster.FanSpeed', '%', 14
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '214', 150, 330, 'Roaster.CoolingTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 19, 31, 'Roaster.BeanTempStart', '°C', 16
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '218', 205, 225, 'Roaster.BeanTempEnd', '°C', 17
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '354', 300, 400, 'Roaster.ExhaustTemp', '°C', 18
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '47', 32, 72, 'Roaster.Humidity', '%RH', 19
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '18', 8, 35, 'Roaster.BatchSize', 'kg', 20
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;

-- Profile 15: Java Arabica Medium
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('JAV-001', 'Java Arabica Medium', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '195', 160, 230, 'Roaster.ChargeTemp', '°C', 1
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '98', 85, 125, 'Roaster.TurnaroundTemp', '°C', 2
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '190', 192, 208, 'Roaster.FirstCrackTemp', '°C', 3
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '223', 205, 225, 'Roaster.DropTemp', '°C', 4
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '617', 480, 720, 'Roaster.RoastTime', 'sec', 5
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '274', 210, 330, 'Roaster.DryingPhase', 'sec', 6
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '201', 150, 270, 'Roaster.MaillardPhase', 'sec', 7
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '77', 50, 120, 'Roaster.DevelopmentTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '13.74', 10.0, 20.0, 'Roaster.DevelopmentRatio', '%', 9
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '6.69', 4.0, 10.0, 'Roaster.RateOfRise', '°C/min', 10
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '51', 35, 65, 'Roaster.DrumSpeed', 'RPM', 11
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Airflow', 'REAL', '66', 40, 90, 'Roaster.Airflow', '%', 12
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '3.96', 2.0, 5.5, 'Roaster.GasPressure', 'kPa', 13
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '71', 45, 95, 'Roaster.FanSpeed', '%', 14
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '205', 150, 330, 'Roaster.CoolingTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '22', 19, 31, 'Roaster.BeanTempStart', '°C', 16
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '221', 205, 225, 'Roaster.BeanTempEnd', '°C', 17
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '328', 300, 400, 'Roaster.ExhaustTemp', '°C', 18
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '47', 32, 72, 'Roaster.Humidity', '%RH', 19
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '18', 8, 35, 'Roaster.BatchSize', 'kg', 20
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;

-- Profile 16: Java Estate Dark
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('JAV-002', 'Java Estate Dark', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '209', 170, 240, 'Roaster.ChargeTemp', '°C', 1
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '101', 90, 130, 'Roaster.TurnaroundTemp', '°C', 2
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 194, 210, 'Roaster.FirstCrackTemp', '°C', 3
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '226', 215, 235, 'Roaster.DropTemp', '°C', 4
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '642', 540, 780, 'Roaster.RoastTime', 'sec', 5
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '315', 240, 360, 'Roaster.DryingPhase', 'sec', 6
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '246', 180, 300, 'Roaster.MaillardPhase', 'sec', 7
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '58', 40, 100, 'Roaster.DevelopmentTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '10.08', 8.0, 15.0, 'Roaster.DevelopmentRatio', '%', 9
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '5.72', 3.5, 9.0, 'Roaster.RateOfRise', '°C/min', 10
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '43', 30, 60, 'Roaster.DrumSpeed', 'RPM', 11
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Airflow', 'REAL', '56', 30, 80, 'Roaster.Airflow', '%', 12
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '4.27', 2.5, 6.0, 'Roaster.GasPressure', 'kPa', 13
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '66', 40, 90, 'Roaster.FanSpeed', '%', 14
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '244', 180, 360, 'Roaster.CoolingTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '24', 20, 32, 'Roaster.BeanTempStart', '°C', 16
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '222', 215, 235, 'Roaster.BeanTempEnd', '°C', 17
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '355', 320, 420, 'Roaster.ExhaustTemp', '°C', 18
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '50', 35, 75, 'Roaster.Humidity', '%RH', 19
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '19', 10, 40, 'Roaster.BatchSize', 'kg', 20
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;

-- Profile 17: Tanzania Peaberry Light
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('TAN-001', 'Tanzania Peaberry Light', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '184', 150, 220, 'Roaster.ChargeTemp', '°C', 1
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '97', 80, 120, 'Roaster.TurnaroundTemp', '°C', 2
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '191', 190, 205, 'Roaster.FirstCrackTemp', '°C', 3
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '215', 195, 215, 'Roaster.DropTemp', '°C', 4
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '532', 420, 660, 'Roaster.RoastTime', 'sec', 5
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '242', 180, 300, 'Roaster.DryingPhase', 'sec', 6
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '181', 120, 240, 'Roaster.MaillardPhase', 'sec', 7
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '87', 60, 150, 'Roaster.DevelopmentTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.12', 15.0, 25.0, 'Roaster.DevelopmentRatio', '%', 9
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '8.6', 5.0, 12.0, 'Roaster.RateOfRise', '°C/min', 10
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '57', 40, 70, 'Roaster.DrumSpeed', 'RPM', 11
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Airflow', 'REAL', '72', 50, 100, 'Roaster.Airflow', '%', 12
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '3.06', 1.5, 5.0, 'Roaster.GasPressure', 'kPa', 13
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '79', 50, 100, 'Roaster.FanSpeed', '%', 14
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '187', 120, 300, 'Roaster.CoolingTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '22', 18, 30, 'Roaster.BeanTempStart', '°C', 16
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '199', 195, 215, 'Roaster.BeanTempEnd', '°C', 17
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '326', 280, 380, 'Roaster.ExhaustTemp', '°C', 18
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '43', 30, 70, 'Roaster.Humidity', '%RH', 19
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'Roaster.BatchSize', 'kg', 20
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;

-- Profile 18: Tanzania AA Medium
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('TAN-002', 'Tanzania AA Medium', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '197', 160, 230, 'Roaster.ChargeTemp', '°C', 1
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '99', 85, 125, 'Roaster.TurnaroundTemp', '°C', 2
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '194', 192, 208, 'Roaster.FirstCrackTemp', '°C', 3
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '219', 205, 225, 'Roaster.DropTemp', '°C', 4
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '623', 480, 720, 'Roaster.RoastTime', 'sec', 5
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '274', 210, 330, 'Roaster.DryingPhase', 'sec', 6
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '209', 150, 270, 'Roaster.MaillardPhase', 'sec', 7
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '76', 50, 120, 'Roaster.DevelopmentTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '14.68', 10.0, 20.0, 'Roaster.DevelopmentRatio', '%', 9
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.21', 4.0, 10.0, 'Roaster.RateOfRise', '°C/min', 10
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 35, 65, 'Roaster.DrumSpeed', 'RPM', 11
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Airflow', 'REAL', '62', 40, 90, 'Roaster.Airflow', '%', 12
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '3.86', 2.0, 5.5, 'Roaster.GasPressure', 'kPa', 13
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '71', 45, 95, 'Roaster.FanSpeed', '%', 14
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '209', 150, 330, 'Roaster.CoolingTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '24', 19, 31, 'Roaster.BeanTempStart', '°C', 16
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '208', 205, 225, 'Roaster.BeanTempEnd', '°C', 17
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '331', 300, 400, 'Roaster.ExhaustTemp', '°C', 18
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '48', 32, 72, 'Roaster.Humidity', '%RH', 19
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '18', 8, 35, 'Roaster.BatchSize', 'kg', 20
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;

-- Profile 19: Rwanda Bourbon Light
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('RWA-001', 'Rwanda Bourbon Light', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '179', 150, 220, 'Roaster.ChargeTemp', '°C', 1
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '99', 80, 120, 'Roaster.TurnaroundTemp', '°C', 2
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '191', 190, 205, 'Roaster.FirstCrackTemp', '°C', 3
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '203', 195, 215, 'Roaster.DropTemp', '°C', 4
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '531', 420, 660, 'Roaster.RoastTime', 'sec', 5
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '247', 180, 300, 'Roaster.DryingPhase', 'sec', 6
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '177', 120, 240, 'Roaster.MaillardPhase', 'sec', 7
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '91', 60, 150, 'Roaster.DevelopmentTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.47', 15.0, 25.0, 'Roaster.DevelopmentRatio', '%', 9
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '8.61', 5.0, 12.0, 'Roaster.RateOfRise', '°C/min', 10
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '55', 40, 70, 'Roaster.DrumSpeed', 'RPM', 11
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Airflow', 'REAL', '76', 50, 100, 'Roaster.Airflow', '%', 12
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '3.2', 1.5, 5.0, 'Roaster.GasPressure', 'kPa', 13
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '76', 50, 100, 'Roaster.FanSpeed', '%', 14
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '173', 120, 300, 'Roaster.CoolingTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'Roaster.BeanTempStart', '°C', 16
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '208', 195, 215, 'Roaster.BeanTempEnd', '°C', 17
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '321', 280, 380, 'Roaster.ExhaustTemp', '°C', 18
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '43', 30, 70, 'Roaster.Humidity', '%RH', 19
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'Roaster.BatchSize', 'kg', 20
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;

-- Profile 20: Rwanda Cooperative Medium
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('RWA-002', 'Rwanda Cooperative Medium', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '196', 160, 230, 'Roaster.ChargeTemp', '°C', 1
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '97', 85, 125, 'Roaster.TurnaroundTemp', '°C', 2
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 192, 208, 'Roaster.FirstCrackTemp', '°C', 3
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '210', 205, 225, 'Roaster.DropTemp', '°C', 4
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '617', 480, 720, 'Roaster.RoastTime', 'sec', 5
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '271', 210, 330, 'Roaster.DryingPhase', 'sec', 6
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '217', 150, 270, 'Roaster.MaillardPhase', 'sec', 7
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '77', 50, 120, 'Roaster.DevelopmentTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '13.9', 10.0, 20.0, 'Roaster.DevelopmentRatio', '%', 9
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '6.66', 4.0, 10.0, 'Roaster.RateOfRise', '°C/min', 10
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '48', 35, 65, 'Roaster.DrumSpeed', 'RPM', 11
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Airflow', 'REAL', '67', 40, 90, 'Roaster.Airflow', '%', 12
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '3.95', 2.0, 5.5, 'Roaster.GasPressure', 'kPa', 13
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '71', 45, 95, 'Roaster.FanSpeed', '%', 14
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '201', 150, 330, 'Roaster.CoolingTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 19, 31, 'Roaster.BeanTempStart', '°C', 16
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '223', 205, 225, 'Roaster.BeanTempEnd', '°C', 17
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '332', 300, 400, 'Roaster.ExhaustTemp', '°C', 18
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '49', 32, 72, 'Roaster.Humidity', '%RH', 19
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '18', 8, 35, 'Roaster.BatchSize', 'kg', 20
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
