-- TimescaleDB Coffee Roasting Manager Schema
CREATE EXTENSION IF NOT EXISTS timescaledb;

CREATE TABLE IF NOT EXISTS products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_code VARCHAR(50) UNIQUE NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS recipes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recipe_code VARCHAR(50) NOT NULL,
    recipe_name VARCHAR(200) NOT NULL,
    product_id UUID REFERENCES products(id),
    version INT DEFAULT 1,
    is_active BOOLEAN DEFAULT true,
    created_by VARCHAR(100),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(recipe_code, version)
);

CREATE TABLE IF NOT EXISTS recipe_parameters (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recipe_id UUID REFERENCES recipes(id) ON DELETE CASCADE,
    param_name VARCHAR(100) NOT NULL,
    param_type VARCHAR(20) CHECK (param_type IN ('INT','REAL','DINT','BOOL','STRING')),
    value_default JSONB,
    value_min NUMERIC,
    value_max NUMERIC,
    plc_tag VARCHAR(200) NOT NULL,
    unit VARCHAR(20),
    sort_order INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS plc_configs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    plc_id VARCHAR(50) UNIQUE NOT NULL,
    host VARCHAR(100) NOT NULL,
    slot INT DEFAULT 0,
    timeout INT DEFAULT 5,
    protocol VARCHAR(20) DEFAULT 'pylogix',
    opcua_endpoint VARCHAR(255),
    description TEXT,
    is_active BOOLEAN DEFAULT true
);

CREATE TABLE IF NOT EXISTS plc_tag_values (
    time TIMESTAMPTZ NOT NULL,
    plc_id VARCHAR(50) NOT NULL,
    tag_name VARCHAR(200) NOT NULL,
    tag_value DOUBLE PRECISION,
    tag_quality INT DEFAULT 192,
    recipe_id UUID REFERENCES recipes(id)
);
SELECT create_hypertable('plc_tag_values', 'time', chunk_time_interval => INTERVAL '1 day', if_not_exists => TRUE);

CREATE TABLE IF NOT EXISTS recipe_downloads (
    time TIMESTAMPTZ NOT NULL,
    recipe_id UUID NOT NULL,
    plc_id VARCHAR(50) NOT NULL,
    downloaded_by VARCHAR(100),
    status VARCHAR(20),
    error_message TEXT,
    duration_ms INT,
    plc_ack BOOLEAN DEFAULT false
);
SELECT create_hypertable('recipe_downloads', 'time', chunk_time_interval => INTERVAL '7 days', if_not_exists => TRUE);

CREATE TABLE IF NOT EXISTS process_events (
    time TIMESTAMPTZ NOT NULL,
    event_type VARCHAR(50),
    plc_id VARCHAR(50),
    recipe_id UUID,
    severity INT CHECK (severity BETWEEN 1 AND 4),
    message TEXT,
    ack_by VARCHAR(100),
    ack_time TIMESTAMPTZ
);
SELECT create_hypertable('process_events', 'time', chunk_time_interval => INTERVAL '1 day', if_not_exists => TRUE);

CREATE MATERIALIZED VIEW IF NOT EXISTS plc_hourly_summary
WITH (timescaledb.continuous) AS
SELECT time_bucket('1 hour', time) AS bucket, plc_id, tag_name,
    AVG(tag_value) AS avg_value, MIN(tag_value) AS min_value, MAX(tag_value) AS max_value, COUNT(*) AS sample_count
FROM plc_tag_values GROUP BY bucket, plc_id, tag_name WITH NO DATA;
SELECT add_continuous_aggregate_policy('plc_hourly_summary',
    start_offset => INTERVAL '1 month', end_offset => INTERVAL '1 hour',
    schedule_interval => INTERVAL '1 hour', if_not_exists => TRUE);

CREATE MATERIALIZED VIEW IF NOT EXISTS plc_daily_summary
WITH (timescaledb.continuous) AS
SELECT time_bucket('1 day', time) AS bucket, plc_id, tag_name,
    AVG(tag_value) AS avg_value, MIN(tag_value) AS min_value, MAX(tag_value) AS max_value, COUNT(*) AS sample_count
FROM plc_tag_values GROUP BY bucket, plc_id, tag_name WITH NO DATA;
SELECT add_continuous_aggregate_policy('plc_daily_summary',
    start_offset => INTERVAL '6 months', end_offset => INTERVAL '1 day',
    schedule_interval => INTERVAL '1 day', if_not_exists => TRUE);

ALTER TABLE plc_tag_values SET (timescaledb.compress, timescaledb.compress_segmentby = 'plc_id, tag_name');
SELECT add_compression_policy('plc_tag_values', INTERVAL '7 days', if_not_exists => TRUE);
SELECT add_retention_policy('plc_tag_values', INTERVAL '2 years', if_not_exists => TRUE);
SELECT add_retention_policy('recipe_downloads', INTERVAL '5 years', if_not_exists => TRUE);
SELECT add_retention_policy('process_events', INTERVAL '5 years', if_not_exists => TRUE);

CREATE INDEX IF NOT EXISTS idx_tag_values_recipe ON plc_tag_values (recipe_id, time DESC) WHERE recipe_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_tag_values_tag ON plc_tag_values (plc_id, tag_name, time DESC);
CREATE INDEX IF NOT EXISTS idx_downloads_recipe ON recipe_downloads (recipe_id, time DESC);
CREATE INDEX IF NOT EXISTS idx_downloads_plc ON recipe_downloads (plc_id, time DESC);
CREATE INDEX IF NOT EXISTS idx_events_ack ON process_events (ack_by, time DESC) WHERE ack_by IS NULL;

CREATE TABLE IF NOT EXISTS production_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    po_number VARCHAR(50) UNIQUE NOT NULL,
    recipe_id UUID NOT NULL REFERENCES recipes(id),
    plc_id VARCHAR(50) NOT NULL,
    quantity INT DEFAULT 1,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'running', 'completed', 'cancelled')),
    operator VARCHAR(100),
    notes TEXT,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_orders_status ON production_orders (status);
CREATE INDEX IF NOT EXISTS idx_orders_po ON production_orders (po_number);
CREATE INDEX IF NOT EXISTS idx_orders_recipe ON production_orders (recipe_id);

CREATE TABLE IF NOT EXISTS order_executions (
    time TIMESTAMPTZ NOT NULL,
    order_id UUID NOT NULL,
    po_number VARCHAR(50) NOT NULL,
    recipe_id UUID NOT NULL,
    plc_id VARCHAR(50) NOT NULL,
    event_type VARCHAR(50),
    tag_name VARCHAR(200),
    tag_value DOUBLE PRECISION,
    message TEXT
);
SELECT create_hypertable('order_executions', 'time', chunk_time_interval => INTERVAL '7 days', if_not_exists => TRUE);
CREATE INDEX IF NOT EXISTS idx_exec_order ON order_executions (order_id, time DESC);
CREATE INDEX IF NOT EXISTS idx_exec_po ON order_executions (po_number, time DESC);

INSERT INTO products (product_code, product_name, description) VALUES
    ('ORIGIN-ETH', 'Ethiopian Coffee', 'High altitude heirloom varieties'),
    ('ORIGIN-COL', 'Colombian Coffee', 'Washed process Arabica'),
    ('ORIGIN-BRA', 'Brazilian Coffee', 'Natural process Santos'),
    ('ORIGIN-KEN', 'Kenyan Coffee', 'AA grade SL28/SL34'),
    ('ORIGIN-GUA', 'Guatemalan Coffee', 'Antigua volcanic soil')
ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'ESP-001', 'Ethiopia Yirgacheffe Light Roast', id, 1, true, 'admin' FROM products WHERE product_code = 'ORIGIN-ETH' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'Roaster.DrumTemp', 'C', 1
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'Roaster.DrumSpeed', 'RPM', 2
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'Roaster.InletTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'Roaster.ExhaustTemp', 'C', 4
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'Roaster.BeanTemp', 'C', 5
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'Roaster.AirFlow', 'm3/h', 6
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'Roaster.GasPressure', 'mbar', 7
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'Roaster.BurnerPower', '%', 8
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'Roaster.ChargeTemp', 'C', 9
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'Roaster.DropTemp', 'C', 10
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'Roaster.DevTime', 'sec', 11
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTime', 'REAL', '465', 300, 720, 'Roaster.FC_Time', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'Roaster.FC_Temp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SecondCrackTime', 'REAL', '0', 0, 900, 'Roaster.SC_Time', 'sec', 14
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'Roaster.RoastTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'Roaster.CoolTime', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnAroundTemp', 'REAL', '84', 60, 120, 'Roaster.TATemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'Roaster.RoR', 'C/min', 18
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'Roaster.MoistureLoss', '%', 19
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'Roaster.WeightLoss', '%', 20
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'ESP-002', 'Ethiopia Sidamo Medium Roast', id, 1, true, 'admin' FROM products WHERE product_code = 'ORIGIN-ETH' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'Roaster.DrumTemp', 'C', 1
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'Roaster.DrumSpeed', 'RPM', 2
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'Roaster.InletTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'Roaster.ExhaustTemp', 'C', 4
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'Roaster.BeanTemp', 'C', 5
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'Roaster.AirFlow', 'm3/h', 6
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'Roaster.GasPressure', 'mbar', 7
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'Roaster.BurnerPower', '%', 8
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'Roaster.ChargeTemp', 'C', 9
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'Roaster.DropTemp', 'C', 10
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'Roaster.DevTime', 'sec', 11
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTime', 'REAL', '465', 300, 720, 'Roaster.FC_Time', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'Roaster.FC_Temp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SecondCrackTime', 'REAL', '0', 0, 900, 'Roaster.SC_Time', 'sec', 14
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'Roaster.RoastTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'Roaster.CoolTime', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnAroundTemp', 'REAL', '84', 60, 120, 'Roaster.TATemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'Roaster.RoR', 'C/min', 18
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'Roaster.MoistureLoss', '%', 19
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'Roaster.WeightLoss', '%', 20
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'COL-001', 'Colombia Huila Light Roast', id, 1, true, 'admin' FROM products WHERE product_code = 'ORIGIN-COL' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'Roaster.DrumTemp', 'C', 1
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'Roaster.DrumSpeed', 'RPM', 2
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'Roaster.InletTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'Roaster.ExhaustTemp', 'C', 4
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'Roaster.BeanTemp', 'C', 5
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'Roaster.AirFlow', 'm3/h', 6
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'Roaster.GasPressure', 'mbar', 7
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'Roaster.BurnerPower', '%', 8
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'Roaster.ChargeTemp', 'C', 9
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'Roaster.DropTemp', 'C', 10
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'Roaster.DevTime', 'sec', 11
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTime', 'REAL', '465', 300, 720, 'Roaster.FC_Time', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'Roaster.FC_Temp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SecondCrackTime', 'REAL', '0', 0, 900, 'Roaster.SC_Time', 'sec', 14
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'Roaster.RoastTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'Roaster.CoolTime', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnAroundTemp', 'REAL', '84', 60, 120, 'Roaster.TATemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'Roaster.RoR', 'C/min', 18
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'Roaster.MoistureLoss', '%', 19
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'Roaster.WeightLoss', '%', 20
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'COL-002', 'Colombia Narino Medium-Dark', id, 1, true, 'admin' FROM products WHERE product_code = 'ORIGIN-COL' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'Roaster.DrumTemp', 'C', 1
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'Roaster.DrumSpeed', 'RPM', 2
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'Roaster.InletTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'Roaster.ExhaustTemp', 'C', 4
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'Roaster.BeanTemp', 'C', 5
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'Roaster.AirFlow', 'm3/h', 6
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'Roaster.GasPressure', 'mbar', 7
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'Roaster.BurnerPower', '%', 8
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'Roaster.ChargeTemp', 'C', 9
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'Roaster.DropTemp', 'C', 10
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'Roaster.DevTime', 'sec', 11
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTime', 'REAL', '465', 300, 720, 'Roaster.FC_Time', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'Roaster.FC_Temp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SecondCrackTime', 'REAL', '0', 0, 900, 'Roaster.SC_Time', 'sec', 14
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'Roaster.RoastTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'Roaster.CoolTime', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnAroundTemp', 'REAL', '84', 60, 120, 'Roaster.TATemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'Roaster.RoR', 'C/min', 18
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'Roaster.MoistureLoss', '%', 19
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'Roaster.WeightLoss', '%', 20
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'BRA-001', 'Brazil Santos Medium', id, 1, true, 'admin' FROM products WHERE product_code = 'ORIGIN-BRA' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'Roaster.DrumTemp', 'C', 1
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'Roaster.DrumSpeed', 'RPM', 2
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'Roaster.InletTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'Roaster.ExhaustTemp', 'C', 4
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'Roaster.BeanTemp', 'C', 5
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'Roaster.AirFlow', 'm3/h', 6
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'Roaster.GasPressure', 'mbar', 7
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'Roaster.BurnerPower', '%', 8
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'Roaster.ChargeTemp', 'C', 9
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'Roaster.DropTemp', 'C', 10
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'Roaster.DevTime', 'sec', 11
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTime', 'REAL', '465', 300, 720, 'Roaster.FC_Time', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'Roaster.FC_Temp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SecondCrackTime', 'REAL', '0', 0, 900, 'Roaster.SC_Time', 'sec', 14
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'Roaster.RoastTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'Roaster.CoolTime', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnAroundTemp', 'REAL', '84', 60, 120, 'Roaster.TATemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'Roaster.RoR', 'C/min', 18
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'Roaster.MoistureLoss', '%', 19
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'Roaster.WeightLoss', '%', 20
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'BRA-002', 'Brazil Cerrado Dark Roast', id, 1, true, 'admin' FROM products WHERE product_code = 'ORIGIN-BRA' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'Roaster.DrumTemp', 'C', 1
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'Roaster.DrumSpeed', 'RPM', 2
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'Roaster.InletTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'Roaster.ExhaustTemp', 'C', 4
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'Roaster.BeanTemp', 'C', 5
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'Roaster.AirFlow', 'm3/h', 6
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'Roaster.GasPressure', 'mbar', 7
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'Roaster.BurnerPower', '%', 8
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'Roaster.ChargeTemp', 'C', 9
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'Roaster.DropTemp', 'C', 10
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'Roaster.DevTime', 'sec', 11
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTime', 'REAL', '465', 300, 720, 'Roaster.FC_Time', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'Roaster.FC_Temp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SecondCrackTime', 'REAL', '0', 0, 900, 'Roaster.SC_Time', 'sec', 14
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'Roaster.RoastTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'Roaster.CoolTime', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnAroundTemp', 'REAL', '84', 60, 120, 'Roaster.TATemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'Roaster.RoR', 'C/min', 18
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'Roaster.MoistureLoss', '%', 19
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'Roaster.WeightLoss', '%', 20
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'KEN-001', 'Kenya AA Light-Medium', id, 1, true, 'admin' FROM products WHERE product_code = 'ORIGIN-KEN' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'Roaster.DrumTemp', 'C', 1
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'Roaster.DrumSpeed', 'RPM', 2
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'Roaster.InletTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'Roaster.ExhaustTemp', 'C', 4
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'Roaster.BeanTemp', 'C', 5
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'Roaster.AirFlow', 'm3/h', 6
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'Roaster.GasPressure', 'mbar', 7
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'Roaster.BurnerPower', '%', 8
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'Roaster.ChargeTemp', 'C', 9
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'Roaster.DropTemp', 'C', 10
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'Roaster.DevTime', 'sec', 11
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTime', 'REAL', '465', 300, 720, 'Roaster.FC_Time', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'Roaster.FC_Temp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SecondCrackTime', 'REAL', '0', 0, 900, 'Roaster.SC_Time', 'sec', 14
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'Roaster.RoastTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'Roaster.CoolTime', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnAroundTemp', 'REAL', '84', 60, 120, 'Roaster.TATemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'Roaster.RoR', 'C/min', 18
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'Roaster.MoistureLoss', '%', 19
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'Roaster.WeightLoss', '%', 20
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'KEN-002', 'Kenya Nyeri Medium', id, 1, true, 'admin' FROM products WHERE product_code = 'ORIGIN-KEN' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'Roaster.DrumTemp', 'C', 1
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'Roaster.DrumSpeed', 'RPM', 2
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'Roaster.InletTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'Roaster.ExhaustTemp', 'C', 4
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'Roaster.BeanTemp', 'C', 5
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'Roaster.AirFlow', 'm3/h', 6
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'Roaster.GasPressure', 'mbar', 7
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'Roaster.BurnerPower', '%', 8
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'Roaster.ChargeTemp', 'C', 9
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'Roaster.DropTemp', 'C', 10
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'Roaster.DevTime', 'sec', 11
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTime', 'REAL', '465', 300, 720, 'Roaster.FC_Time', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'Roaster.FC_Temp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SecondCrackTime', 'REAL', '0', 0, 900, 'Roaster.SC_Time', 'sec', 14
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'Roaster.RoastTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'Roaster.CoolTime', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnAroundTemp', 'REAL', '84', 60, 120, 'Roaster.TATemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'Roaster.RoR', 'C/min', 18
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'Roaster.MoistureLoss', '%', 19
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'Roaster.WeightLoss', '%', 20
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'GUA-001', 'Guatemala Antigua Light', id, 1, true, 'admin' FROM products WHERE product_code = 'ORIGIN-GUA' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'Roaster.DrumTemp', 'C', 1
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'Roaster.DrumSpeed', 'RPM', 2
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'Roaster.InletTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'Roaster.ExhaustTemp', 'C', 4
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'Roaster.BeanTemp', 'C', 5
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'Roaster.AirFlow', 'm3/h', 6
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'Roaster.GasPressure', 'mbar', 7
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'Roaster.BurnerPower', '%', 8
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'Roaster.ChargeTemp', 'C', 9
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'Roaster.DropTemp', 'C', 10
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'Roaster.DevTime', 'sec', 11
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTime', 'REAL', '465', 300, 720, 'Roaster.FC_Time', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'Roaster.FC_Temp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SecondCrackTime', 'REAL', '0', 0, 900, 'Roaster.SC_Time', 'sec', 14
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'Roaster.RoastTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'Roaster.CoolTime', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnAroundTemp', 'REAL', '84', 60, 120, 'Roaster.TATemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'Roaster.RoR', 'C/min', 18
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'Roaster.MoistureLoss', '%', 19
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'Roaster.WeightLoss', '%', 20
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'GUA-002', 'Guatemala Huehuetenango Medium-Dark', id, 1, true, 'admin' FROM products WHERE product_code = 'ORIGIN-GUA' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'Roaster.DrumTemp', 'C', 1
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'Roaster.DrumSpeed', 'RPM', 2
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'Roaster.InletTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'Roaster.ExhaustTemp', 'C', 4
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'Roaster.BeanTemp', 'C', 5
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'Roaster.AirFlow', 'm3/h', 6
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'Roaster.GasPressure', 'mbar', 7
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'Roaster.BurnerPower', '%', 8
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'Roaster.ChargeTemp', 'C', 9
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'Roaster.DropTemp', 'C', 10
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'Roaster.DevTime', 'sec', 11
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTime', 'REAL', '465', 300, 720, 'Roaster.FC_Time', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'Roaster.FC_Temp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SecondCrackTime', 'REAL', '0', 0, 900, 'Roaster.SC_Time', 'sec', 14
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'Roaster.RoastTime', 'sec', 15
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'Roaster.CoolTime', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnAroundTemp', 'REAL', '84', 60, 120, 'Roaster.TATemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'Roaster.RoR', 'C/min', 18
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'Roaster.MoistureLoss', '%', 19
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'Roaster.WeightLoss', '%', 20
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;

INSERT INTO plc_configs (plc_id, host, slot, protocol, description) VALUES
    ('LINE_A_PLC', '192.168.1.10', 0, 'pylogix', 'Roaster A - Probat'),
    ('LINE_B_PLC', '192.168.1.11', 0, 'pylogix', 'Roaster B - Giesen'),
    ('LINE_C_PLC', '192.168.1.12', 0, 'pylogix', 'Roaster C - Loring')
ON CONFLICT DO NOTHING;
