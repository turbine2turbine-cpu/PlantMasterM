"""FastAPI application entry point."""
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.core.database import db
from app.clients.plc_client import disconnect_all_plcs
from app.clients.opcua_client import disconnect_all_opcua
from app.services.plc_service import plc_service
from app.services.timeseries_service import tag_collector
from app.routers import recipes, plc, monitoring, orders

logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan - startup and shutdown."""
    logger.info("Starting up Recipe PLC Manager...")
    await db.connect()
    logger.info("Connected to TimescaleDB")

    await plc_service.start_worker()

    yield

    logger.info("Shutting down...")
    await tag_collector.stop()
    await plc_service.stop_worker()
    await disconnect_all_plcs()
    await disconnect_all_opcua()
    await db.disconnect()
    logger.info("Cleanup complete")


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(recipes.router)
app.include_router(plc.router)
app.include_router(monitoring.router)
app.include_router(orders.router)


@app.get("/health")
async def health_check():
    return {"status": "ok", "version": settings.APP_VERSION}
