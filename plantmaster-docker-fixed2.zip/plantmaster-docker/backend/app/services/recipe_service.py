"""Recipe business logic service."""
import logging
import uuid
from typing import List, Optional, Dict, Any

from app.core.database import db, get_recipe_by_id, get_recipe_by_code, list_recipes, create_recipe_version
from app.models import RecipeCreate, RecipeUpdate, RecipeParameter

logger = logging.getLogger(__name__)


class RecipeService:
    """Service for recipe CRUD operations."""

    @staticmethod
    async def create_recipe(data: RecipeCreate) -> Dict[str, Any]:
        """Create new recipe with parameters."""
        async with db.transaction() as conn:
            # Check for duplicate code
            existing = await conn.fetchrow(
                "SELECT id FROM recipes WHERE recipe_code = $1 AND is_active = true",
                data.recipe_code
            )
            if existing:
                raise ValueError(f"Recipe code '{data.recipe_code}' already exists")

            recipe_id = str(uuid.uuid4())
            await conn.execute(
                """
                INSERT INTO recipes (id, recipe_code, recipe_name, product_id, version, created_by)
                VALUES ($1, $2, $3, $4, 1, $5)
                """,
                recipe_id, data.recipe_code, data.recipe_name, 
                data.product_id, data.created_by
            )

            # Insert parameters
            for param in data.parameters:
                param_id = str(uuid.uuid4())
                await conn.execute(
                    """
                    INSERT INTO recipe_parameters 
                        (id, recipe_id, param_name, param_type, value_default,
                         value_min, value_max, plc_tag, unit, sort_order)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
                    """,
                    param_id, recipe_id, param.param_name, param.param_type.value,
                    param.value_default, param.value_min, param.value_max,
                    param.plc_tag, param.unit, param.sort_order
                )

            logger.info(f"Created recipe {data.recipe_code} (id: {recipe_id})")
            return await get_recipe_by_id(recipe_id)

    @staticmethod
    async def update_recipe(recipe_id: str, data: RecipeUpdate, user: str = "system") -> Dict[str, Any]:
        """Update recipe - creates new version if parameters change."""
        current = await get_recipe_by_id(recipe_id)
        if not current:
            raise ValueError("Recipe not found")

        # If parameters changed, create new version
        if data.parameters is not None:
            new_id = await create_recipe_version(recipe_id, user)

            # Update new version with new data
            async with db.transaction() as conn:
                if data.recipe_name:
                    await conn.execute(
                        "UPDATE recipes SET recipe_name = $1 WHERE id = $2",
                        data.recipe_name, new_id
                    )

                # Replace parameters
                await conn.execute(
                    "DELETE FROM recipe_parameters WHERE recipe_id = $1", new_id
                )

                for param in data.parameters:
                    param_id = str(uuid.uuid4())
                    await conn.execute(
                        """
                        INSERT INTO recipe_parameters 
                            (id, recipe_id, param_name, param_type, value_default,
                             value_min, value_max, plc_tag, unit, sort_order)
                        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
                        """,
                        param_id, new_id, param.param_name, param.param_type.value,
                        param.value_default, param.value_min, param.value_max,
                        param.plc_tag, param.unit, param.sort_order
                    )

            logger.info(f"Created new version for recipe {current['recipe_code']}")
            return await get_recipe_by_id(new_id)

        # Simple update (name only)
        async with db.acquire() as conn:
            if data.recipe_name:
                await conn.execute(
                    "UPDATE recipes SET recipe_name = $1, updated_at = NOW() WHERE id = $2",
                    data.recipe_name, recipe_id
                )
            if data.is_active is not None:
                await conn.execute(
                    "UPDATE recipes SET is_active = $1, updated_at = NOW() WHERE id = $2",
                    data.is_active, recipe_id
                )

        return await get_recipe_by_id(recipe_id)

    @staticmethod
    async def delete_recipe(recipe_id: str) -> bool:
        """Soft delete recipe."""
        async with db.acquire() as conn:
            result = await conn.execute(
                "UPDATE recipes SET is_active = false WHERE id = $1",
                recipe_id
            )
            return result == "UPDATE 1"

    @staticmethod
    async def validate_recipe_parameters(recipe_id: str) -> Dict[str, Any]:
        """Validate all parameters are within min/max ranges."""
        recipe = await get_recipe_by_id(recipe_id)
        if not recipe:
            raise ValueError("Recipe not found")

        errors = []
        warnings = []

        for param in recipe.get("parameters", []):
            val = param.get("value_default")
            min_val = param.get("value_min")
            max_val = param.get("value_max")

            if val is None:
                warnings.append(f"{param['param_name']}: No default value")
                continue

            try:
                numeric_val = float(val)
                if min_val is not None and numeric_val < min_val:
                    errors.append(
                        f"{param['param_name']}: {numeric_val} < min {min_val}"
                    )
                if max_val is not None and numeric_val > max_val:
                    errors.append(
                        f"{param['param_name']}: {numeric_val} > max {max_val}"
                    )
            except (ValueError, TypeError):
                # Non-numeric type (BOOL, STRING) - skip range check
                pass

            if not param.get("plc_tag"):
                errors.append(f"{param['param_name']}: Missing PLC tag mapping")

        return {
            "recipe_id": recipe_id,
            "recipe_code": recipe["recipe_code"],
            "valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings
        }

    @staticmethod
    async def clone_recipe(recipe_id: str, new_code: str, new_name: str, user: str = "system") -> Dict[str, Any]:
        """Clone an existing recipe to a new recipe with new code and name."""
        from app.core.database import db
        source = await get_recipe_by_id(recipe_id)
        if not source:
            raise ValueError("Source recipe not found")

        # Check new code doesn't exist
        existing = await get_recipe_by_code(new_code)
        if existing:
            raise ValueError(f"Recipe code '{new_code}' already exists")

        async with db.transaction() as conn:
            new_id = str(uuid.uuid4())
            await conn.execute(
                """
                INSERT INTO recipes (id, recipe_code, recipe_name, product_id, version, is_active, created_by)
                VALUES ($1, $2, $3, $4, 1, true, $5)
                """,
                new_id, new_code, new_name,
                source.get("product_id"), user
            )

            # Copy all parameters
            for param in source.get("parameters", []):
                param_id = str(uuid.uuid4())
                await conn.execute(
                    """
                    INSERT INTO recipe_parameters
                        (id, recipe_id, param_name, param_type, value_default,
                         value_min, value_max, plc_tag, unit, sort_order)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
                    """,
                    param_id, new_id, param["param_name"], param["param_type"],
                    param.get("value_default"), param.get("value_min"), param.get("value_max"),
                    param["plc_tag"], param.get("unit"), param.get("sort_order", 0)
                )

        logger.info(f"Cloned recipe {source['recipe_code']} -> {new_code} (id: {new_id})")
        return await get_recipe_by_id(new_id)

    @staticmethod
    async def compare_with_plc(recipe_id: str, plc_id: str, plc_client) -> Dict[str, Any]:
        """Compare recipe parameters with current PLC values."""
        recipe = await get_recipe_by_id(recipe_id)
        if not recipe:
            raise ValueError("Recipe not found")

        # Read current PLC values
        tag_names = [p["plc_tag"] for p in recipe.get("parameters", []) if p.get("plc_tag")]
        plc_results = await plc_client.read_tags(tag_names)

        plc_values = {r.tag_name: r.value for r in plc_results if r.status == "Success"}

        comparisons = []
        for param in recipe.get("parameters", []):
            tag = param.get("plc_tag")
            recipe_val = param.get("value_default")
            plc_val = plc_values.get(tag)

            comparison = {
                "param_name": param["param_name"],
                "plc_tag": tag,
                "recipe_value": recipe_val,
                "plc_value": plc_val,
                "unit": param.get("unit"),
                "match": False
            }

            if recipe_val is not None and plc_val is not None:
                try:
                    comparison["match"] = abs(float(recipe_val) - float(plc_val)) < 0.001
                    comparison["deviation"] = abs(float(recipe_val) - float(plc_val))
                except:
                    comparison["match"] = str(recipe_val) == str(plc_val)

            comparisons.append(comparison)

        return {
            "recipe_id": recipe_id,
            "plc_id": plc_id,
            "matches": sum(1 for c in comparisons if c["match"]),
            "total": len(comparisons),
            "comparisons": comparisons
        }
