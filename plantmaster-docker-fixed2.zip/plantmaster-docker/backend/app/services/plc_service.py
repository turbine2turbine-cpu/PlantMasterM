"""PLC service - download recipes, read/write tags with retry logic and detailed logging."""
import logging
import asyncio
import uuid
import time
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List

from app.core.config import settings
from app.core.database import (
    db, get_recipe_by_id, log_recipe_download, log_process_event,
    insert_tag_values_batch
)
from app.clients.plc_client import get_plc_client, AsyncPyLogixClient
from app.clients.opcua_client import get_opcua_client, OpcuaClient

logger = logging.getLogger(__name__)


class PlcService:
    """Service for PLC operations with retry, transaction safety, and detailed logging."""

    def __init__(self):
        self._download_queue: asyncio.Queue = asyncio.Queue(
            maxsize=settings.DOWNLOAD_QUEUE_MAX_SIZE
        )
        self._download_results: Dict[str, Dict[str, Any]] = {}
        self._running = False

    async def start_worker(self):
        """Start background worker for processing download queue."""
        self._running = True
        asyncio.create_task(self._process_download_queue())
        logger.info("[PLC-SERVICE] Download worker started")

    async def stop_worker(self):
        """Stop background worker."""
        self._running = False
        await self._download_queue.join()
        logger.info("[PLC-SERVICE] Download worker stopped")

    async def _process_download_queue(self):
        """Background worker to process download jobs."""
        logger.info("[PLC-SERVICE|WORKER] Queue processor started")
        while self._running:
            try:
                job = await asyncio.wait_for(
                    self._download_queue.get(), timeout=1.0
                )
                logger.info(f"[PLC-SERVICE|WORKER] Dequeued job: tx_id={job.get('transaction_id')}")
                await self._execute_download(job)
                self._download_queue.task_done()
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"[PLC-SERVICE|WORKER] Error in download worker: {e}", exc_info=True)

    async def _execute_download(self, job: Dict[str, Any]):
        """Execute single download job with full transaction logic and logging."""
        tx_id = job["transaction_id"]
        recipe_id = job["recipe_id"]
        plc_id = job["plc_id"]
        user = job["user"]
        validate = job.get("validate", True)
        backup = job.get("backup_current", True)
        po_number = job.get("po_number")

        start_time = datetime.now(timezone.utc)
        t0 = time.perf_counter()

        logger.info(
            f"[PLC-SERVICE|DOWNLOAD|{tx_id}] START "
            f"recipe_id={recipe_id}, plc_id={plc_id}, user={user}, "
            f"validate={validate}, backup={backup}, po_number={po_number}"
        )

        try:
            # 1. Get recipe from DB
            logger.debug(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 1/9: Fetching recipe from DB...")
            recipe = await get_recipe_by_id(recipe_id)
            if not recipe:
                raise ValueError(f"Recipe {recipe_id} not found")
            logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 1/9: Recipe found: code={recipe.get('recipe_code')}, params={len(recipe.get('parameters', []))}")

            # 2. Validate parameters
            if validate:
                logger.debug(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 2/9: Validating parameters...")
                validation = await self._validate_parameters(recipe)
                if not validation["valid"]:
                    raise ValueError(f"Validation failed: {validation['errors']}")
                logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 2/9: Validation passed")
            else:
                logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 2/9: Validation skipped")

            # 3. Get PLC client
            logger.debug(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 3/9: Getting PLC client for {plc_id}...")
            plc_client = self._get_client_for_plc(plc_id)
            logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 3/9: PLC client ready")

            # 4. Connect to PLC
            logger.debug(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 4/9: Connecting to PLC...")
            connected = await self._connect_with_retry(plc_client)
            if not connected:
                raise ConnectionError(f"Cannot connect to PLC {plc_id} after {settings.PLC_RETRY_ATTEMPTS} attempts")
            logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 4/9: PLC connected")

            try:
                # 5. Backup current recipe on PLC (if enabled)
                if backup:
                    logger.debug(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 5/9: Backing up current PLC values...")
                    await self._backup_current_recipe(plc_client, plc_id, recipe)
                    logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 5/9: Backup complete")
                else:
                    logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 5/9: Backup skipped")

                # 6. Write parameters to PLC
                logger.debug(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 6/9: Writing recipe parameters to PLC...")
                write_results = await self._write_recipe_to_plc(
                    plc_client, recipe, plc_id
                )
                logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 6/9: Wrote {len(write_results)} tags")

                # 7. Write PO Number to PLC if provided
                po_written = False
                if po_number:
                    logger.debug(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 7/9: Writing PO Number '{po_number}' to PLC...")
                    po_result = await plc_client.write_tag("Recipe.PONumber", po_number)
                    if po_result.status == "Success":
                        po_written = True
                        logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 7/9: PO Number written successfully")
                    else:
                        logger.warning(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 7/9: PO Number write FAILED - {po_result.error}")
                else:
                    logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 7/9: No PO Number to write")

                # 8. Verify write (read back)
                logger.debug(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 8/9: Verifying written values...")
                verified = await self._verify_plc_write(plc_client, write_results)
                logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 8/9: Verification {'PASSED' if verified else 'FAILED'}")

                # 9. Log success
                duration_ms = int((time.perf_counter() - t0) * 1000)
                await log_recipe_download(
                    recipe_id=recipe_id,
                    plc_id=plc_id,
                    downloaded_by=user,
                    status="SUCCESS",
                    duration_ms=duration_ms,
                    plc_ack=verified
                )

                if job.get("order_id"):
                    from app.core.database import log_order_execution
                    await log_order_execution(
                        order_id=job["order_id"],
                        po_number=po_number or "",
                        recipe_id=recipe_id,
                        plc_id=plc_id,
                        event_type="download_success",
                        message=f"Recipe downloaded successfully. PO: {po_number or 'N/A'}"
                    )

                await log_process_event(
                    event_type="RECIPE_DOWNLOADED",
                    plc_id=plc_id,
                    recipe_id=recipe_id,
                    severity=1,
                    message=f"Recipe {recipe['recipe_code']} downloaded successfully"
                )

                self._download_results[tx_id] = {
                    "status": "SUCCESS",
                    "message": "Recipe downloaded to PLC successfully",
                    "duration_ms": duration_ms,
                    "verified": verified,
                    "tags_written": len(write_results)
                }

                logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] SUCCESS in {duration_ms}ms, verified={verified}")

            finally:
                logger.debug(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Disconnecting from PLC...")
                await plc_client.disconnect()
                logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] PLC disconnected")

        except Exception as e:
            duration_ms = int((time.perf_counter() - t0) * 1000)
            error_msg = str(e)
            logger.error(
                f"[PLC-SERVICE|DOWNLOAD|{tx_id}] FAILED after {duration_ms}ms - {type(e).__name__}: {error_msg}",
                exc_info=True
            )

            await log_recipe_download(
                recipe_id=recipe_id,
                plc_id=plc_id,
                downloaded_by=user,
                status="FAILED",
                error_message=error_msg,
                duration_ms=duration_ms
            )

            await log_process_event(
                event_type="RECIPE_DOWNLOAD_FAILED",
                plc_id=plc_id,
                recipe_id=recipe_id,
                severity=3,
                message=f"Download failed: {error_msg}"
            )

            self._download_results[tx_id] = {
                "status": "FAILED",
                "message": error_msg,
                "duration_ms": duration_ms
            }

    def _get_client_for_plc(self, plc_id: str):
        """Get appropriate client for PLC (PyLogix or OPC UA)."""
        if settings.OPC_UA_ENDPOINT:
            logger.debug(f"[PLC-SERVICE] Using OPC UA client for {plc_id}")
            return get_opcua_client(
                plc_id=plc_id,
                endpoint=settings.OPC_UA_ENDPOINT,
                username=settings.OPC_UA_USERNAME,
                password=settings.OPC_UA_PASSWORD
            )
        else:
            logger.debug(f"[PLC-SERVICE] Using PyLogix client for {plc_id} (host={settings.PLC_HOST}, slot={settings.PLC_SLOT})")
            return get_plc_client(
                plc_id=plc_id,
                host=settings.PLC_HOST,
                slot=settings.PLC_SLOT,
                timeout=settings.PLC_TIMEOUT
            )

    async def _connect_with_retry(self, client) -> bool:
        """Connect to PLC with retry logic and detailed logging."""
        for attempt in range(settings.PLC_RETRY_ATTEMPTS):
            logger.info(f"[PLC-SERVICE] Connection attempt {attempt + 1}/{settings.PLC_RETRY_ATTEMPTS}...")
            try:
                connected = await client.connect()
                if connected:
                    logger.info(f"[PLC-SERVICE] Connection SUCCESS on attempt {attempt + 1}")
                    return True
                else:
                    logger.warning(f"[PLC-SERVICE] Connection returned False on attempt {attempt + 1}")
            except Exception as e:
                logger.warning(f"[PLC-SERVICE] Connection attempt {attempt + 1} EXCEPTION: {type(e).__name__}: {e}")

            if attempt < settings.PLC_RETRY_ATTEMPTS - 1:
                wait_sec = settings.PLC_RETRY_DELAY * (attempt + 1)
                logger.info(f"[PLC-SERVICE] Waiting {wait_sec}s before retry...")
                await asyncio.sleep(wait_sec)

        logger.error(f"[PLC-SERVICE] All {settings.PLC_RETRY_ATTEMPTS} connection attempts failed")
        return False

    async def _validate_parameters(self, recipe: Dict[str, Any]) -> Dict[str, Any]:
        """Validate recipe parameters before sending to PLC."""
        errors = []
        logger.debug(f"[PLC-SERVICE] Validating {len(recipe.get('parameters', []))} parameters")

        for param in recipe.get("parameters", []):
            val = param.get("value_default")
            min_val = param.get("value_min")
            max_val = param.get("value_max")
            plc_tag = param.get("plc_tag")

            if not plc_tag:
                errors.append(f"{param['param_name']}: Missing PLC tag")
                continue

            if val is None:
                errors.append(f"{param['param_name']}: No value to write")
                continue

            try:
                numeric_val = float(val)
                if min_val is not None and numeric_val < min_val:
                    errors.append(f"{param['param_name']}: {numeric_val} < min {min_val}")
                if max_val is not None and numeric_val > max_val:
                    errors.append(f"{param['param_name']}: {numeric_val} > max {max_val}")
            except (ValueError, TypeError):
                pass

        valid = len(errors) == 0
        if not valid:
            logger.warning(f"[PLC-SERVICE] Validation FAILED: {errors}")
        else:
            logger.debug("[PLC-SERVICE] Validation PASSED")
        return {"valid": valid, "errors": errors}

    async def _backup_current_recipe(self, client, plc_id: str, recipe: Dict[str, Any]):
        """Backup current PLC values before writing new recipe."""
        tag_names = [p["plc_tag"] for p in recipe.get("parameters", []) if p.get("plc_tag")]
        if not tag_names:
            logger.debug("[PLC-SERVICE] No tags to backup")
            return

        logger.info(f"[PLC-SERVICE] Backing up {len(tag_names)} tags from PLC {plc_id}...")
        results = await client.read_tags(tag_names)
        backup_data = []
        for result in results:
            if result.status == "Success":
                backup_data.append({
                    "time": datetime.now(timezone.utc),
                    "plc_id": plc_id,
                    "tag_name": result.tag_name,
                    "tag_value": result.value,
                    "tag_quality": 192,
                    "recipe_id": recipe.get("id")
                })

        if backup_data:
            await insert_tag_values_batch(backup_data)
            logger.info(f"[PLC-SERVICE] Backed up {len(backup_data)} tags")
        else:
            logger.warning("[PLC-SERVICE] Backup: no tags were read successfully")

    async def _write_recipe_to_plc(
        self, client, recipe: Dict[str, Any], plc_id: str
    ) -> List[Dict[str, Any]]:
        """Write recipe parameters to PLC tags."""
        tags_to_write = {}
        for param in recipe.get("parameters", []):
            tag = param.get("plc_tag")
            val = param.get("value_default")
            if tag and val is not None:
                casted_val = self._cast_value(val, param.get("param_type", "REAL"))
                tags_to_write[tag] = casted_val

        if not tags_to_write:
            raise ValueError("No valid tags to write")

        logger.info(f"[PLC-SERVICE] Writing {len(tags_to_write)} tags to PLC {plc_id}...")
        logger.debug(f"[PLC-SERVICE] Tags to write: {tags_to_write}")

        results = await client.write_tags(tags_to_write)

        failed = [r for r in results if r.status != "Success"]
        if failed:
            failed_tags = [f"{r.tag_name}: {r.error}" for r in failed]
            raise RuntimeError(f"Failed to write tags: {', '.join(failed_tags)}")

        return [{"tag": r.tag_name, "value": r.value} for r in results]

    def _cast_value(self, value: Any, param_type: str) -> Any:
        """Cast value to appropriate PLC type."""
        type_map = {
            "BOOL": bool,
            "INT": int,
            "DINT": int,
            "REAL": float,
            "STRING": str
        }
        caster = type_map.get(param_type, float)
        try:
            return caster(value)
        except (ValueError, TypeError):
            logger.warning(f"[PLC-SERVICE] Cast failed for {value!r} to {param_type}, returning as-is")
            return value

    async def _verify_plc_write(self, client, write_results: List[Dict[str, Any]]) -> bool:
        """Verify written values by reading them back."""
        tag_names = [w["tag"] for w in write_results]
        logger.debug(f"[PLC-SERVICE] Verifying {len(tag_names)} tags by read-back...")
        read_results = await client.read_tags(tag_names)

        all_match = True
        mismatches = []
        for write, read in zip(write_results, read_results):
            if read.status != "Success":
                all_match = False
                mismatches.append(f"{read.tag_name}: read failed ({read.error})")
                continue

            try:
                if abs(float(write["value"]) - float(read.value)) > 0.001:
                    all_match = False
                    mismatches.append(f"{read.tag_name}: wrote={write['value']}, read={read.value}")
            except (ValueError, TypeError):
                if str(write["value"]) != str(read.value):
                    all_match = False
                    mismatches.append(f"{read.tag_name}: wrote={write['value']!r}, read={read.value!r}")

        if mismatches:
            logger.warning(f"[PLC-SERVICE] Verification FAILED: {mismatches}")
        else:
            logger.debug("[PLC-SERVICE] Verification PASSED")
        return all_match

    # ─── Public API Methods ───

    async def queue_download(
        self, recipe_id: str, plc_id: str, user: str = "system",
        validate: bool = True, backup_current: bool = True,
        po_number: str = None, order_id: str = None
    ) -> str:
        """Queue a recipe download job."""
        tx_id = str(uuid.uuid4())
        job = {
            "transaction_id": tx_id,
            "recipe_id": recipe_id,
            "plc_id": plc_id,
            "user": user,
            "validate": validate,
            "backup_current": backup_current,
            "po_number": po_number,
            "order_id": order_id,
            "queued_at": datetime.now(timezone.utc).isoformat()
        }

        await self._download_queue.put(job)
        self._download_results[tx_id] = {"status": "PENDING"}

        logger.info(f"[PLC-SERVICE] Download queued: tx_id={tx_id}, recipe_id={recipe_id}, plc_id={plc_id}")
        return tx_id

    async def get_download_status(self, transaction_id: str) -> Dict[str, Any]:
        """Get download job status."""
        result = self._download_results.get(transaction_id, {"status": "NOT_FOUND"})
        logger.debug(f"[PLC-SERVICE] Download status for {transaction_id}: {result['status']}")
        return result

    async def read_plc_tags(self, plc_id: str, tag_names: List[str]) -> Dict[str, Any]:
        """Read tags from PLC directly."""
        logger.info(f"[PLC-SERVICE] read_plc_tags: plc_id={plc_id}, tags={tag_names}")
        client = self._get_client_for_plc(plc_id)

        try:
            connected = await self._connect_with_retry(client)
            if not connected:
                raise ConnectionError(f"Cannot connect to PLC {plc_id}")

            results = await client.read_tags(tag_names)

            # Log to TimescaleDB
            tag_values = []
            for r in results:
                if r.status == "Success":
                    tag_values.append({
                        "time": datetime.now(timezone.utc),
                        "plc_id": plc_id,
                        "tag_name": r.tag_name,
                        "tag_value": r.value,
                        "tag_quality": 192
                    })

            if tag_values:
                await insert_tag_values_batch(tag_values)
                logger.info(f"[PLC-SERVICE] read_plc_tags: Logged {len(tag_values)} tag values to DB")

            success_tags = [r.tag_name for r in results if r.status == "Success"]
            failed_tags = [(r.tag_name, r.error) for r in results if r.status != "Success"]
            logger.info(f"[PLC-SERVICE] read_plc_tags: success={len(success_tags)}, failed={len(failed_tags)}")
            if failed_tags:
                logger.warning(f"[PLC-SERVICE] read_plc_tags failed: {failed_tags}")

            return {
                "plc_id": plc_id,
                "results": [
                    {"tag": r.tag_name, "value": r.value, "status": r.status, "error": r.error}
                    for r in results
                ]
            }
        finally:
            await client.disconnect()

    async def write_plc_tags(
        self, plc_id: str, tags: Dict[str, Any], user: str = "system"
    ) -> Dict[str, Any]:
        """Write tags to PLC directly."""
        logger.info(f"[PLC-SERVICE] write_plc_tags: plc_id={plc_id}, tags={list(tags.keys())}")
        client = self._get_client_for_plc(plc_id)

        try:
            connected = await self._connect_with_retry(client)
            if not connected:
                raise ConnectionError(f"Cannot connect to PLC {plc_id}")

            results = await client.write_tags(tags)

            # Log to TimescaleDB
            tag_values = []
            for r in results:
                if r.status == "Success":
                    tag_values.append({
                        "time": datetime.now(timezone.utc),
                        "plc_id": plc_id,
                        "tag_name": r.tag_name,
                        "tag_value": r.value,
                        "tag_quality": 192
                    })

            if tag_values:
                await insert_tag_values_batch(tag_values)

            success = {r.tag_name: r.value for r in results if r.status == "Success"}
            failed = {r.tag_name: r.error for r in results if r.status != "Success"}

            await log_process_event(
                event_type="PLC_TAGS_WRITTEN" if not failed else "PLC_TAGS_PARTIAL",
                plc_id=plc_id,
                severity=1 if not failed else 2,
                message=f"Wrote {len(success)} tags, failed {len(failed)}"
            )

            logger.info(f"[PLC-SERVICE] write_plc_tags: success={len(success)}, failed={len(failed)}")
            if failed:
                logger.warning(f"[PLC-SERVICE] write_plc_tags failed details: {failed}")

            return {"plc_id": plc_id, "success": success, "failed": failed}
        finally:
            await client.disconnect()


# Global service instance
plc_service = PlcService()


# ─── Batch State Machine ───
from enum import Enum

class BatchStatus(Enum):
    """Roaster batch state machine states."""
    IDLE = 0
    INITIALIZING = 1
    READY = 2
    RUNNING = 3
    HOLDING = 4
    HELD = 5
    ABORTING = 6
    ABORTED = 7
    COMPLETING = 8
    COMPLETED = 9


class BatchControlCommand(Enum):
    """Commands to control batch state."""
    INITIALIZE = "initialize"
    START = "start"
    HOLD = "hold"
    ABORT = "abort"


# State Transition Rules: {current_status: {command: new_status}}
STATE_TRANSITIONS = {
    BatchStatus.IDLE: {BatchControlCommand.INITIALIZE: BatchStatus.INITIALIZING},
    BatchStatus.INITIALIZING: {BatchControlCommand.ABORT: BatchStatus.ABORTING},
    BatchStatus.READY: {BatchControlCommand.START: BatchStatus.RUNNING, BatchControlCommand.ABORT: BatchStatus.ABORTING},
    BatchStatus.RUNNING: {BatchControlCommand.HOLD: BatchStatus.HOLDING, BatchControlCommand.ABORT: BatchStatus.ABORTING},
    BatchStatus.HOLDING: {BatchControlCommand.ABORT: BatchStatus.ABORTING},
    BatchStatus.HELD: {BatchControlCommand.START: BatchStatus.RUNNING, BatchControlCommand.ABORT: BatchStatus.ABORTING},
    BatchStatus.ABORTING: {},
    BatchStatus.ABORTED: {BatchControlCommand.INITIALIZE: BatchStatus.INITIALIZING},
    BatchStatus.COMPLETING: {},
    BatchStatus.COMPLETED: {BatchControlCommand.INITIALIZE: BatchStatus.INITIALIZING},
}

# Allowed commands per state
ALLOWED_COMMANDS = {
    BatchStatus.IDLE: [BatchControlCommand.INITIALIZE],
    BatchStatus.INITIALIZING: [BatchControlCommand.ABORT],
    BatchStatus.READY: [BatchControlCommand.START, BatchControlCommand.ABORT],
    BatchStatus.RUNNING: [BatchControlCommand.HOLD, BatchControlCommand.ABORT],
    BatchStatus.HOLDING: [BatchControlCommand.ABORT],
    BatchStatus.HELD: [BatchControlCommand.START, BatchControlCommand.ABORT],
    BatchStatus.ABORTING: [],
    BatchStatus.ABORTED: [BatchControlCommand.INITIALIZE],
    BatchStatus.COMPLETING: [],
    BatchStatus.COMPLETED: [BatchControlCommand.INITIALIZE],
}

# PLC Tag names for batch control
BATCH_STATUS_TAG = "Roaster.BatchStatus"
CMD_INIT_TAG = "Roaster.CmdInitialize"
CMD_START_TAG = "Roaster.CmdStart"
CMD_HOLD_TAG = "Roaster.CmdHold"
CMD_ABORT_TAG = "Roaster.CmdAbort"
BATCH_ID_TAG = "Roaster.BatchID"
RECIPE_ID_TAG = "Roaster.RecipeID"


async def get_batch_status(plc_id: str) -> Dict[str, Any]:
    """Get detailed batch status with allowed actions."""
    logger.info(f"[BATCH-STATUS] Getting batch status for {plc_id}...")
    client = plc_service._get_client_for_plc(plc_id)
    try:
        connected = await plc_service._connect_with_retry(client)
        if not connected:
            logger.error(f"[BATCH-STATUS] PLC {plc_id} is OFFLINE")
            return {
                "plc_id": plc_id,
                "batch_status": 0,
                "status_name": "OFFLINE",
                "is_online": False,
                "can_initialize": False,
                "can_start": False,
                "can_hold": False,
                "can_abort": False,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        logger.debug(f"[BATCH-STATUS] Reading tags: {[BATCH_STATUS_TAG, BATCH_ID_TAG, RECIPE_ID_TAG]}")
        results = await client.read_tags([BATCH_STATUS_TAG, BATCH_ID_TAG, RECIPE_ID_TAG])
        status_result = next((r for r in results if r.tag_name == BATCH_STATUS_TAG), None)
        batch_id_result = next((r for r in results if r.tag_name == BATCH_ID_TAG), None)
        recipe_id_result = next((r for r in results if r.tag_name == RECIPE_ID_TAG), None)

        raw_status = status_result.value if status_result and status_result.status == "Success" else 0
        logger.debug(f"[BATCH-STATUS] Raw status value: {raw_status!r}")
        try:
            current_status = BatchStatus(int(raw_status))
        except (ValueError, TypeError):
            logger.warning(f"[BATCH-STATUS] Invalid status value: {raw_status!r}, defaulting to IDLE")
            current_status = BatchStatus.IDLE

        allowed = ALLOWED_COMMANDS.get(current_status, [])
        result = {
            "plc_id": plc_id,
            "batch_status": current_status.value,
            "status_name": current_status.name,
            "batch_id": batch_id_result.value if batch_id_result and batch_id_result.status == "Success" else None,
            "recipe_id": recipe_id_result.value if recipe_id_result and recipe_id_result.status == "Success" else None,
            "is_online": True,
            "can_initialize": BatchControlCommand.INITIALIZE in allowed,
            "can_start": BatchControlCommand.START in allowed,
            "can_hold": BatchControlCommand.HOLD in allowed,
            "can_abort": BatchControlCommand.ABORT in allowed,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        logger.info(
            f"[BATCH-STATUS] {plc_id}: status={current_status.name}({current_status.value}), "
            f"allowed={[c.value for c in allowed]}"
        )
        return result
    except Exception as e:
        logger.error(f"[BATCH-STATUS] Error reading batch status for {plc_id}: {type(e).__name__}: {e}", exc_info=True)
        return {
            "plc_id": plc_id,
            "batch_status": 0,
            "status_name": "ERROR",
            "is_online": False,
            "can_initialize": False,
            "can_start": False,
            "can_hold": False,
            "can_abort": False,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    finally:
        await client.disconnect()
        logger.debug(f"[BATCH-STATUS] Disconnected from {plc_id}")


async def control_batch(
    plc_id: str,
    command: str,
    recipe_id: str = None,
    po_number: str = None,
    order_id: str = None
) -> Dict[str, Any]:
    """Execute batch control command with state machine validation."""
    logger.info(f"[BATCH-CONTROL] Request: plc_id={plc_id}, command={command}, recipe_id={recipe_id}, po_number={po_number}")
    client = plc_service._get_client_for_plc(plc_id)
    start_time = datetime.now(timezone.utc)
    t0 = time.perf_counter()

    try:
        # Connect
        logger.debug(f"[BATCH-CONTROL] Connecting to {plc_id}...")
        connected = await plc_service._connect_with_retry(client)
        if not connected:
            raise ConnectionError(f"Cannot connect to PLC {plc_id}")
        logger.info(f"[BATCH-CONTROL] Connected to {plc_id}")

        # Read current status
        logger.debug(f"[BATCH-CONTROL] Reading current batch status from {plc_id}...")
        results = await client.read_tags([BATCH_STATUS_TAG])
        status_result = next((r for r in results if r.tag_name == BATCH_STATUS_TAG), None)
        raw_status = status_result.value if status_result and status_result.status == "Success" else 0
        logger.info(f"[BATCH-CONTROL] Current raw status: {raw_status!r}")
        try:
            previous_status = BatchStatus(int(raw_status))
        except (ValueError, TypeError):
            logger.warning(f"[BATCH-CONTROL] Invalid status {raw_status!r}, assuming IDLE")
            previous_status = BatchStatus.IDLE

        # Parse command
        try:
            cmd = BatchControlCommand(command)
        except ValueError:
            logger.error(f"[BATCH-CONTROL] Unknown command: {command}")
            return {
                "plc_id": plc_id,
                "command": command,
                "previous_status": previous_status.value,
                "current_status": previous_status.value,
                "status_name": previous_status.name,
                "success": False,
                "message": f"Unknown command: {command}",
                "timestamp": start_time.isoformat(),
            }

        # Validate state transition
        allowed = STATE_TRANSITIONS.get(previous_status, {})
        new_status = allowed.get(cmd)
        logger.debug(f"[BATCH-CONTROL] Transition check: {previous_status.name} + {cmd.value} -> {new_status.name if new_status else 'BLOCKED'}")

        if new_status is None:
            allowed_names = [c.value for c in ALLOWED_COMMANDS.get(previous_status, [])]
            logger.warning(f"[BATCH-CONTROL] BLOCKED: Cannot {command} from {previous_status.name}. Allowed: {allowed_names}")
            return {
                "plc_id": plc_id,
                "command": command,
                "previous_status": previous_status.value,
                "current_status": previous_status.value,
                "status_name": previous_status.name,
                "success": False,
                "message": f"Cannot {command} from {previous_status.name}. Allowed: {allowed_names}",
                "timestamp": start_time.isoformat(),
            }

        # ─── Execute command ───
        if cmd == BatchControlCommand.INITIALIZE:
            # Block if currently running
            if previous_status in (BatchStatus.RUNNING, BatchStatus.HOLDING, BatchStatus.HELD):
                logger.warning(f"[BATCH-CONTROL] BLOCKED: Cannot initialize while {previous_status.name}")
                return {
                    "plc_id": plc_id,
                    "command": command,
                    "previous_status": previous_status.value,
                    "current_status": previous_status.value,
                    "status_name": previous_status.name,
                    "success": False,
                    "message": f"Cannot initialize while batch is {previous_status.name}. Please abort first.",
                    "timestamp": start_time.isoformat(),
                }

            # Fetch recipe and write parameters
            if recipe_id:
                logger.info(f"[BATCH-CONTROL] Fetching recipe {recipe_id} from DB...")
                recipe = await get_recipe_by_id(recipe_id)
                if not recipe:
                    raise ValueError(f"Recipe {recipe_id} not found")
                logger.info(f"[BATCH-CONTROL] Recipe found: {recipe.get('recipe_code')}, {len(recipe.get('parameters', []))} params")

                tags_to_write = {}
                for param in recipe.get("parameters", []):
                    tag = param.get("plc_tag")
                    val = param.get("value_default")
                    if tag and val is not None:
                        casted_val = plc_service._cast_value(val, param.get("param_type", "REAL"))
                        tags_to_write[tag] = casted_val

                if tags_to_write:
                    logger.info(f"[BATCH-CONTROL] Writing {len(tags_to_write)} recipe tags to PLC...")
                    write_results = await client.write_tags(tags_to_write)
                    failed = [r for r in write_results if r.status != "Success"]
                    if failed:
                        failed_tags = [f"{r.tag_name}: {r.error}" for r in failed]
                        raise RuntimeError(f"Failed to write recipe tags: {', '.join(failed_tags)}")
                    logger.info(f"[BATCH-CONTROL] Recipe tags written successfully")
                else:
                    logger.warning("[BATCH-CONTROL] No recipe tags to write")

            # Set batch info and trigger initialize
            init_tags = {
                BATCH_STATUS_TAG: new_status.value,
                BATCH_ID_TAG: po_number or "",
                RECIPE_ID_TAG: recipe_id or "",
                CMD_INIT_TAG: True,
            }
            logger.info(f"[BATCH-CONTROL] Writing init tags: {init_tags}")
            await client.write_tags(init_tags)
            logger.debug("[BATCH-CONTROL] Waiting 200ms before clearing pulse...")
            await asyncio.sleep(0.2)
            await client.write_tags({CMD_INIT_TAG: False})
            logger.info("[BATCH-CONTROL] Initialize pulse cleared")

        elif cmd == BatchControlCommand.START:
            start_tags = {
                BATCH_STATUS_TAG: new_status.value,
                CMD_START_TAG: True,
            }
            logger.info(f"[BATCH-CONTROL] Writing start tags: {start_tags}")
            await client.write_tags(start_tags)
            await asyncio.sleep(0.2)
            await client.write_tags({CMD_START_TAG: False})
            logger.info("[BATCH-CONTROL] Start pulse cleared")

        elif cmd == BatchControlCommand.HOLD:
            hold_tags = {
                BATCH_STATUS_TAG: new_status.value,
                CMD_HOLD_TAG: True,
            }
            logger.info(f"[BATCH-CONTROL] Writing hold tags: {hold_tags}")
            await client.write_tags(hold_tags)
            await asyncio.sleep(0.2)
            await client.write_tags({CMD_HOLD_TAG: False})
            logger.info("[BATCH-CONTROL] Hold pulse cleared")

        elif cmd == BatchControlCommand.ABORT:
            abort_tags = {
                BATCH_STATUS_TAG: new_status.value,
                CMD_ABORT_TAG: True,
            }
            logger.info(f"[BATCH-CONTROL] Writing abort tags: {abort_tags}")
            await client.write_tags(abort_tags)
            await asyncio.sleep(0.2)
            await client.write_tags({CMD_ABORT_TAG: False})
            logger.info("[BATCH-CONTROL] Abort pulse cleared")

        # Log event
        duration_ms = int((time.perf_counter() - t0) * 1000)
        await log_process_event(
            event_type=f"BATCH_{cmd.name}",
            plc_id=plc_id,
            recipe_id=recipe_id,
            severity=1,
            message=f"Batch command {cmd.value} executed. {previous_status.name} -> {new_status.name} ({duration_ms}ms)"
        )

        logger.info(
            f"[BATCH-CONTROL] SUCCESS: {plc_id} {previous_status.name} -> {new_status.name} "
            f"in {duration_ms}ms"
        )
        return {
            "plc_id": plc_id,
            "command": command,
            "previous_status": previous_status.value,
            "current_status": new_status.value,
            "status_name": new_status.name,
            "success": True,
            "message": f"Command '{command}' executed. Status changed from {previous_status.name} to {new_status.name}.",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    except Exception as e:
        duration_ms = int((time.perf_counter() - t0) * 1000)
        logger.error(
            f"[BATCH-CONTROL] FAILED after {duration_ms}ms: {type(e).__name__}: {e}",
            exc_info=True
        )
        return {
            "plc_id": plc_id,
            "command": command,
            "previous_status": previous_status.value if 'previous_status' in dir() else 0,
            "current_status": previous_status.value if 'previous_status' in dir() else 0,
            "status_name": previous_status.name if 'previous_status' in dir() else "UNKNOWN",
            "success": False,
            "message": f"Failed to execute {command}: {str(e)}",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    finally:
        logger.debug(f"[BATCH-CONTROL] Disconnecting from {plc_id}...")
        await client.disconnect()
        logger.info(f"[BATCH-CONTROL] Disconnected from {plc_id}")
